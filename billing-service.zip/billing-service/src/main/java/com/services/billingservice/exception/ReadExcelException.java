package com.services.billingservice.exception;

public class ReadExcelException extends RuntimeException {

    public ReadExcelException() {
    }

    public ReadExcelException(String message) {
        super(message);
    }
}
