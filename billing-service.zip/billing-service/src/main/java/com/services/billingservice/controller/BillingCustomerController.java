package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.customer.*;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.service.BillingCustomerService;
import com.services.billingservice.service.CustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.swing.plaf.MenuBarUI;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping(path = "/api/customer")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class BillingCustomerController {

    private static final String MENU_CUSTOMER = "Customer";

    private final BillingCustomerService billingCustomerService;
    private final CustomerService customerService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<CreateCustomerListResponse>> create(@RequestBody CreateCustomerRequest request) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.POST.name())
                .endpoint("/api/customer/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_CUSTOMER)
                .build();
        CreateCustomerListResponse createCustomerListResponse = customerService.createSingleData(request, dataChangeDTO);
        ResponseDTO<CreateCustomerListResponse> response = ResponseDTO.<CreateCustomerListResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(createCustomerListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create-list")
    public ResponseEntity<ResponseDTO<CreateCustomerListResponse>> createList(@RequestBody CreateCustomerListRequest request) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.POST.name())
                .endpoint("/api/customer/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_CUSTOMER)
                .build();
        CreateCustomerListResponse createCustomerListResponse = customerService.createMultipleData(request, dataChangeDTO);
        ResponseDTO<CreateCustomerListResponse> response = ResponseDTO.<CreateCustomerListResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(createCustomerListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create-list/approve")
    public ResponseEntity<ResponseDTO<CreateCustomerListResponse>> createListApprove(@RequestBody CreateCustomerListRequest request) {
        CreateCustomerListResponse createCustomerListResponse = customerService.createMultipleApprove(request);
        ResponseDTO<CreateCustomerListResponse> response = ResponseDTO.<CreateCustomerListResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(createCustomerListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<UpdateCustomerListResponse>> update(@RequestBody UpdateCustomerRequest updateCustomerRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.PUT.name())
                .endpoint("/api/customer/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_CUSTOMER)
                .build();
        UpdateCustomerListResponse updateCustomerListResponse = customerService.updateSingleData(updateCustomerRequest, dataChangeDTO);
        ResponseDTO<UpdateCustomerListResponse> response = ResponseDTO.<UpdateCustomerListResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateCustomerListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update-list")
    public ResponseEntity<ResponseDTO<UpdateCustomerListResponse>> updateList(@RequestBody UpdateCustomerListRequest updateCustomerListRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.PUT.name())
                .endpoint("/api/customer/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_CUSTOMER)
                .build();
        UpdateCustomerListResponse updateCustomerListResponse = customerService.updateMultipleData(updateCustomerListRequest, dataChangeDTO);
        ResponseDTO<UpdateCustomerListResponse> response = ResponseDTO.<UpdateCustomerListResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateCustomerListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<UpdateCustomerListResponse>> updateApprove(@RequestBody UpdateCustomerListRequest updateCustomerListRequest) {
        UpdateCustomerListResponse updateCustomerListResponse = customerService.updateMultipleApprove(updateCustomerListRequest);
        ResponseDTO<UpdateCustomerListResponse> response = ResponseDTO.<UpdateCustomerListResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateCustomerListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete")
    public ResponseEntity<ResponseDTO<DeleteCustomerListResponse>> deleteById(@RequestBody DeleteCustomerRequest deleteCustomerRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint("/api/customer/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .build();
        DeleteCustomerListResponse deleteCustomerListResponse = customerService.deleteSingleData(deleteCustomerRequest, dataChangeDTO);
        ResponseDTO<DeleteCustomerListResponse> response = ResponseDTO.<DeleteCustomerListResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteCustomerListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDTO<DeleteCustomerListResponse>> deleteApprove(@RequestBody DeleteCustomerListRequest deleteCustomerListRequest) {
        DeleteCustomerListResponse deleteCustomerListResponse = customerService.deleteMultipleApprove(deleteCustomerListRequest);
        ResponseDTO<DeleteCustomerListResponse> response = ResponseDTO.<DeleteCustomerListResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteCustomerListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/id")
    public ResponseEntity<ResponseDTO<BillingCustomerDTO>> getById(@RequestParam(name = "id") String id) {
        BillingCustomerDTO billingCustomerDTO = billingCustomerService.getById(id);
        ResponseDTO<BillingCustomerDTO> response = ResponseDTO.<BillingCustomerDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(billingCustomerDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/code")
    public ResponseEntity<ResponseDTO<BillingCustomerDTO>> getByCustomerCode(@RequestParam(name = "code") String code) {
        BillingCustomerDTO billingCustomerDTO = billingCustomerService.getByCustomerCode(code);
        ResponseDTO<BillingCustomerDTO> response = ResponseDTO.<BillingCustomerDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(billingCustomerDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BillingCustomerDTO>>> getAll() {
        List<BillingCustomerDTO> billingCustomerDTOList = billingCustomerService.getAll();
        ResponseDTO<List<BillingCustomerDTO>> response = ResponseDTO.<List<BillingCustomerDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(billingCustomerDTOList)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/updateById")
    public ResponseEntity<ResponseDTO<BillingCustomerDTO>> updateById(
            @RequestParam(name = "id") String id,
            @RequestBody CreateCustomerRequest request) {

        BillingCustomerDTO billingCustomerDTO = billingCustomerService.updateById(id, request);
        ResponseDTO<BillingCustomerDTO> response = ResponseDTO.<BillingCustomerDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(billingCustomerDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity<ResponseDTO<String>> deleteById(@PathVariable("id") String id) {
        String status = billingCustomerService.deleteById(id);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

}
