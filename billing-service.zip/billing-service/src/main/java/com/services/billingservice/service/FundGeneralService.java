package com.services.billingservice.service;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.fund.BillingFundDTO;
import com.services.billingservice.dto.fund.UpdateApprovalStatusBillingFundRequest;
import com.services.billingservice.dto.fund.UpdateBillingFundRequest;

import java.util.List;

public interface FundGeneralService {

    String updateApprovalStatus(UpdateApprovalStatusBillingFundRequest request);

    String deleteByCategoryAndTypeAndMonthYear(CoreCalculateRequest request);

    List<BillingFundDTO> updateAll(List<UpdateBillingFundRequest> requestList);

}
