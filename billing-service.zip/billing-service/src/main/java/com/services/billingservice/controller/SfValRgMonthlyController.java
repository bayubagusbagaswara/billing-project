package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.rgmonthly.CreateRGMonthlyRequest;
import com.services.billingservice.model.SfValRgMonthly;
import com.services.billingservice.service.SfValRgMonthlyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RestController
@RequestMapping(path = "/api/sfval-rg-monthly")
public class SfValRgMonthlyController {

    @Value("${file.path.bill-monthly}")
    private String filePath;

    private final SfValRgMonthlyService sfValRgMonthlyService;

    public SfValRgMonthlyController(SfValRgMonthlyService sfValRgMonthlyService) {
        this.sfValRgMonthlyService = sfValRgMonthlyService;
    }

    @GetMapping(path = "/read-insert")
    public ResponseEntity<ResponseDTO<String>> readAndInsert() {
        log.info("File Path : {}", filePath);

        String status = sfValRgMonthlyService.readFileAndInsertToDB(filePath);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<SfValRgMonthly>>> getAll() {
        List<SfValRgMonthly> sfValRgMonthlyList = sfValRgMonthlyService.getAll();

        ResponseDTO<List<SfValRgMonthly>> response = ResponseDTO.<List<SfValRgMonthly>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgMonthlyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid")
    public ResponseEntity<ResponseDTO<List<SfValRgMonthly>>> getAllByAid(@RequestParam("aid") String aid) {
        List<SfValRgMonthly> sfValRgMonthlyList = sfValRgMonthlyService.getAllByAid(aid);

        ResponseDTO<List<SfValRgMonthly>> response = ResponseDTO.<List<SfValRgMonthly>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgMonthlyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/period")
    public ResponseEntity<ResponseDTO<List<SfValRgMonthly>>> getAllByAidAndPeriod(@RequestParam("aid") String aid,
                                                                                  @RequestParam("month") String month,
                                                                                  @RequestParam("year") Integer year) {
        List<SfValRgMonthly> sfvalRgMonthlyList = sfValRgMonthlyService.findByAidAndMonthAndYearOrderByAidAscSecurityNameAscDateAsc(aid, month, year);

        ResponseDTO<List<SfValRgMonthly>> response = ResponseDTO.<List<SfValRgMonthly>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfvalRgMonthlyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/security-name")
    public ResponseEntity<ResponseDTO<List<SfValRgMonthly>>> getAllByAidAndSecurityName(
            @RequestParam("aid") String aid,
            @RequestParam("securityName") String securityName) {

        List<SfValRgMonthly> sfValRgMonthlyList = sfValRgMonthlyService.getAllByAidAndSecurityName(aid, securityName);

        ResponseDTO<List<SfValRgMonthly>> response = ResponseDTO.<List<SfValRgMonthly>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgMonthlyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<List<SfValRgMonthly>>> create(@RequestBody List<CreateRGMonthlyRequest> requestList) {

        List<SfValRgMonthly> sfValRgMonthlyList = sfValRgMonthlyService.createList(requestList);

        ResponseDTO<List<SfValRgMonthly>> response = ResponseDTO.<List<SfValRgMonthly>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgMonthlyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping(path = "/all")
    public ResponseEntity<ResponseDTO<String>> deleteAll() {
        String status = sfValRgMonthlyService.deleteAll();

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }
}
