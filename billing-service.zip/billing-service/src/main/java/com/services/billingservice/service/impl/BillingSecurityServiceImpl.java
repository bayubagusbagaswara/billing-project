package com.services.billingservice.service.impl;

import com.services.billingservice.dto.BillingSecurityDTO;
import com.services.billingservice.dto.request.BillingSecurityRequest;
import com.services.billingservice.model.BillingSecurity;
import com.services.billingservice.repository.BillingSecurityRepository;
import com.services.billingservice.service.BillingSecurityService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor

public class BillingSecurityServiceImpl implements BillingSecurityService {

    private final BillingSecurityRepository billingSecurityRepository;

    @Override
    public BillingSecurityDTO create(BillingSecurityRequest request) {
        String code = request.getCode();
        String group = request.getGroup();
        String currency = request.getCurrency();
        String issuerName = request.getIssuerName();
        String name = request.getName();

        BillingSecurity billingSecurity = BillingSecurity.builder()
                .code(code)
                .group(group)
                .currency(currency)
                .issuerName(issuerName)
                .name(name)
                .build();

        BillingSecurity dataSaved = billingSecurityRepository.save(billingSecurity);
        return mapToDTO(dataSaved);

    }

    @Override
    public BillingSecurityDTO getByCode(String code) {
        return null;
    }

    @Override
    public List<BillingSecurityDTO> getAll() {
        return null;
    }

    @Override
    public BillingSecurityDTO updateByCode(String code, BillingSecurityRequest request) {
        return null;
    }

    @Override
    public List<BillingSecurityDTO> upload(List<BillingSecurityRequest> request) {
        List<BillingSecurity> billingSecurities = mapToBillingSecurityList(request);
        List<BillingSecurity> billingSecurities1 = billingSecurityRepository.saveAll(billingSecurities);
        return mapToBillingSecurityDTOList(billingSecurities1);
    }

    @Override
    public List<BillingSecurityDTO> updateUploadByCode(List<BillingSecurityRequest> request) {
        return null;
    }

    private BillingSecurityDTO mapToDTO(BillingSecurity billingSecurity){
        return BillingSecurityDTO.builder().build().builder()
                .id(String.valueOf(billingSecurity.getId()))
                .code(billingSecurity.getCode())
                .group(billingSecurity.getGroup())
                .issuerName((billingSecurity.getIssuerName()))
                .name((billingSecurity.getName()))
                .build();
    }

    private List<BillingSecurity> mapToBillingSecurityList(List<BillingSecurityRequest> billingSecurityList){
        return billingSecurityList.stream()
                .map(this::mapToBillingSecurity)
                .collect(Collectors.toList());
    }

    private BillingSecurityDTO maptoBillingSecurityDTO(BillingSecurity billingSecurity){
        return BillingSecurityDTO.builder()
                .id(String.valueOf(billingSecurity.getId()))
                .code(billingSecurity.getCode())
                .group(billingSecurity.getGroup())
                .issuerName(billingSecurity.getIssuerName())
                .name(billingSecurity.getName())
                .build();
    }



    private BillingSecurity mapToBillingSecurity(BillingSecurityRequest request) {
        return BillingSecurity.builder()
                .code(request.getCode())
                .group(request.getGroup())
                .issuerName(request.getIssuerName())
                .name(request.getName())
                .build();
    }

    private List<BillingSecurityDTO> mapToBillingSecurityDTOList(List<BillingSecurity> feeParamList) {
        return feeParamList.stream()
                .map(this::maptoBillingSecurityDTO)
                .collect(Collectors.toList());
    }

}
