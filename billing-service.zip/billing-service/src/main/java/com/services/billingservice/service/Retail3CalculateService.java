package com.services.billingservice.service;

import com.services.billingservice.dto.retail.RetailCalculateRequest;

public interface Retail3CalculateService {

    String calculate(RetailCalculateRequest retailCalculateRequest);

}
