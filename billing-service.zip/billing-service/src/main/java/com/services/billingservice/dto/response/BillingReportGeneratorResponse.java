package com.services.billingservice.dto.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BillingReportGeneratorResponse {

    private String customerCode;

    private String customerName;

    private String type;

    private String fileName;

    private String filePath;

    private String period;

    private String status;

    private String desc;
}
