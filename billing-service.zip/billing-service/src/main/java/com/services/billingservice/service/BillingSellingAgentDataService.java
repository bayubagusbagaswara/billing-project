package com.services.billingservice.service;

import com.services.billingservice.dto.BillingSellingAgentDataDTO;
import com.services.billingservice.dto.request.BillingSellingAgentDataRequest;

import java.util.List;

public interface BillingSellingAgentDataService {

    boolean isCodeAlreadyExists(String sellingAgentCode);

    //single maintenance
    BillingSellingAgentDataDTO create(BillingSellingAgentDataRequest request);

    BillingSellingAgentDataDTO getByCode(String id);

    List<BillingSellingAgentDataDTO>getAll();

    BillingSellingAgentDataDTO updateById(String id, BillingSellingAgentDataRequest request);

    String delete(String id);

}
