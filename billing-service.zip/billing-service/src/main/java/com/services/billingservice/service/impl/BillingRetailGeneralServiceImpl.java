package com.services.billingservice.service.impl;

import com.services.billingservice.dto.retail.BillingRetailListProcessDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.exception.ConnectionDatabaseException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.service.BillingNumberService;
import com.services.billingservice.service.BillingRetailGeneralService;
import com.services.billingservice.utils.BeanUtil;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingRetailGeneralServiceImpl implements BillingRetailGeneralService {

    private final BillingRetailRepository billingRetailRepository;
    private final BillingNumberService billingNumberService;

    @Override
    public List<BillingRetail> getAll() {
        return billingRetailRepository.findAll();
    }

    @Override
    public void checkingExistingBillingRetail(String customerCode, String currency, String monthName, Integer year) {

        Optional<BillingRetail> billingRetailOptional = billingRetailRepository.findByCustomerCodeAndCurrencyAndMonthAndYear(customerCode, currency, monthName, year);

        if (billingRetailOptional.isPresent()) {
            BillingRetail billingRetail = billingRetailOptional.get();
            String billingNumber = billingRetail.getBillingNumber();
            billingRetailRepository.delete(billingRetail);
            billingNumberService.deleteByBillingNumber(billingNumber);
        }
    }

    @Override
    public String deleteAll() {
        try {
            billingRetailRepository.deleteAll();
            return "Successfully deleted all Billing Retail";
        } catch (Exception e) {
            log.error("Error when delete all Billing Retail: " + e.getMessage(), e);
            throw new ConnectionDatabaseException("Error when delete all Billing Retail: " + e.getMessage());
        }
    }

    @Override
    public String deleteByCategoryAndTypeAndMonthYear(RetailCalculateRequest request) {
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            List<BillingRetail> billingRetailList = billingRetailRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYear(categoryUpperCase, typeUpperCase, monthName, year);

            for (BillingRetail billingRetail : billingRetailList) {
                billingRetailRepository.delete(billingRetail);
            }

            return "Successfully delete Billing Retail with total : " + billingRetailList.size();
        } catch (Exception e) {
            throw new ConnectionDatabaseException("Error when delete Billing Retail : " + e.getMessage());
        }
    }

    @Override
    public List<BillingRetailListProcessDTO> getAllListPendingApprove() {
        List<BillingRetailListProcessDTO> result = new ArrayList<>();
        billingRetailRepository.getAllListPendingApprove().stream()
                .forEach(f -> {
                    BillingRetailListProcessDTO temp = new BillingRetailListProcessDTO();
                    BeanUtil.copyAllProperties(f, temp);
                    temp.setApprovalStatus(f.getApprovalStatus().getStatus());
                    temp.setBillingStatus(f.getBillingStatus().getStatus());
                    result.add(temp);
                });
        return result;
    }

    @Override
    public List<BillingRetailListProcessDTO> getAllListProcess() {
        List<BillingRetailListProcessDTO> result = new ArrayList<>();
        billingRetailRepository.getAllListProcess().stream()
                .forEach(f -> {
                    BillingRetailListProcessDTO temp = new BillingRetailListProcessDTO();
                    BeanUtil.copyAllProperties(f, temp);
                    temp.setApprovalStatus(f.getApprovalStatus().getStatus());
                    temp.setBillingStatus(f.getBillingStatus().getStatus());
                    result.add(temp);
                });
        return result;
    }

    @Override
    public List<BillingRetail> findByMonthAndYearAndBillingCategoryAndBillingTypeAndCurrency(String month, Integer year, String category, String type, String currency) {
        return Optional.ofNullable(billingRetailRepository.findByMonthAndYearAndBillingCategoryAndBillingTypeAndCurrency(month, year, category, type, currency))
                .orElse(new ArrayList<>());
    }
}
