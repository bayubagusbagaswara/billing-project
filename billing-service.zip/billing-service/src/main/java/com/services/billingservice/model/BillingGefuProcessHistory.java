package com.services.billingservice.model;

import com.services.billingservice.enums.BillingCategory;
import com.services.billingservice.enums.BillingType;
import com.services.billingservice.model.base.Approvable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.util.Date;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "billing_gefu_process_history")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingGefuProcessHistory extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(nullable = false)
    private String fileName;

    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    private Date processDate;

    @Column(nullable = false)
    boolean gefuGenerated = false;

    @Column(nullable = false)
    private boolean sent;

    @Temporal(TemporalType.DATE)
    private Date sentDate;

    @Column(nullable = false)
    private String category;

    @Column(nullable = false)
    private String type;

    private String template;

    private long idBilling;

    private String currency;

}
