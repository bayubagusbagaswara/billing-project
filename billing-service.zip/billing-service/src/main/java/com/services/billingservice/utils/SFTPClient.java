package com.services.billingservice.utils;

import com.jcraft.jsch.*;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class SFTPClient {

	private static final String SFTP = "sftp";
	private static final int SFTP_PORT = 22;
	private static Logger logger = LogManager.getLogger(SFTPClient.class);

	private Session session;
	private ChannelSftp sftp;

	public SFTPClient(String host, String userID, String privateKey)
			throws JSchException {
		this(host, SFTP_PORT, userID, privateKey);
	}

	public SFTPClient(String host, String userID, String privateKey,
                      String passphrase) throws JSchException {
		this(host, SFTP_PORT, userID, privateKey, passphrase);
	}

	public SFTPClient(String host, int port, String userID, String privateKey)
			throws JSchException {
		this(host, port, userID, privateKey, null);
	}

	public SFTPClient(String host, int port, String userID, String privateKey,
                      String passphrase) throws JSchException {
		JSch.setConfig("StrictHostKeyChecking", "no");

		JSch jsch = new JSch();
		if (passphrase == null || passphrase.isEmpty()) {
			jsch.addIdentity(privateKey);
		} else {
			jsch.addIdentity(privateKey, passphrase);
		}

		session = jsch.getSession(userID, host, port);
		logger.debug("Session created.");

		connect();
	}

	public SFTPClient(String host, int port, String userID, String passphrase,
                      boolean using) throws JSchException {
		JSch.setConfig("StrictHostKeyChecking", "no");

		JSch jsch = new JSch();
		session = jsch.getSession(userID, host, port);
		session.setConfig("StrictHostKeyChecking", "no");
		session.setPassword(passphrase);

		logger.debug("Session created.");

		connect();
	}

	private void connect() throws JSchException {
		session.connect();
		logger.debug("Session connected.");

		sftp = (ChannelSftp) session.openChannel(SFTP);
		sftp.connect();
		logger.debug("Channel open.");
	}

	public void reconnect() throws JSchException {
		if (!sftp.isConnected()) {
			if (!session.isConnected()) {
				session.connect();
				logger.debug("Session connected.");
				sftp = (ChannelSftp) session.openChannel(SFTP);
			}
			sftp.connect();
			logger.debug("Channel open.");
		}
	}

	public void close() {
		if (sftp.isConnected()) {
			sftp.disconnect();
		}
		if (session.isConnected()) {
			session.disconnect();
		}
		logger.debug("Connection closed");
	}

	public void changeDirectory(String path) throws SftpException {
		sftp.cd(path);
	}

	public void changeLocalDirectory(String path) throws SftpException {
		sftp.lcd(path);
	}

	@SuppressWarnings("unchecked")
	public List<String> getFileNames(String path) throws SftpException {
		List<String> fileNames = new ArrayList<String>();
		Vector<LsEntry> entries = sftp.ls(path);
		for (LsEntry lsEntry : entries) {
			String filename = lsEntry.getFilename();
			if (!filename.equals(".") && !filename.equals("..")) {
				fileNames.add(lsEntry.getFilename());
			}
		}
		return fileNames;
	}

	public boolean getFile(String remoteFile, String localFile) {
		boolean success = false;
		try {
			sftp.get(remoteFile, localFile);
			success = true;
		} catch (SftpException e) {
			e.printStackTrace();
		}
		return success;
	}

	public byte[] getFileContent(String remoteFile) throws SftpException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		sftp.get(remoteFile, baos);
		return baos.toByteArray();
	}

	public void sendFile(File file, String destination) throws SftpException,
			IOException {
		FileInputStream in = new FileInputStream(file);
		sftp.put(in, destination);
		in.close();
	}

	public boolean delete(String filename) {
		boolean success = false;
		try {
			sftp.rm(filename);
			success = true;
		} catch (SftpException e) {
			e.printStackTrace();
		}
		return success;
	}

}
