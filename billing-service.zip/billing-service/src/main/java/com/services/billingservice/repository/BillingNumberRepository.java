package com.services.billingservice.repository;

import com.services.billingservice.model.BillingNumber;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BillingNumberRepository extends JpaRepository<BillingNumber, Long> {

    @Query(nativeQuery = true, value = "SELECT " +
            "MAX(sequence_number) AS latest_sequence_number " +
            "FROM billing_number " +
            "WHERE month = :month AND year = :year")
    Integer getMaxSequenceNumberByMonthAndYear(@Param("month") String month, @Param("year") int year);

    @Query(value = "SELECT * FROM billing_number " +
            "WHERE number = :billingNumber", nativeQuery = true)
    Optional<BillingNumber> findByNumber(@Param("billingNumber") String billingNumber);

}
