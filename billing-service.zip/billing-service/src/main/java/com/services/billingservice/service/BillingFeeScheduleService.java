package com.services.billingservice.service;

import com.services.billingservice.dto.BillingFeeParamDTO;
import com.services.billingservice.dto.BillingFeeScheduleDTO;
import com.services.billingservice.dto.customer.UpdateBillingCustomerListRequest;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeSchedule.*;
import com.services.billingservice.dto.request.BillingFeeParamRequest;
import com.services.billingservice.dto.request.BillingFeeScheduleRequest;
import com.services.billingservice.model.BillingFeeSchedule;

import java.util.List;

public interface BillingFeeScheduleService {

    CreateFeeScheduleListResponse create(BillingFeeScheduleRequest request, BillingDataChangeDTO dataChangeDTO);
    CreateFeeScheduleListResponse createListApprove(CreateFeeScheduleListRequest billingFeeScheduleRequest);

    UpdateFeeScheduleListResponse updateById(BillingFeeScheduleRequest request, BillingDataChangeDTO dataChangeDTO);
    UpdateFeeScheduleListResponse updateListApprove(UpdateFeeScheduleListRequest investmentManagementListRequest);

    DeleteFeeScheduleListResponse deleteById(DeleteFeeScheduleListRequest request, BillingDataChangeDTO dataChangeDTO);
//    DeleteFeeScheduleListResponse deleteListApprove(DeleteFeeScheduleListRequest request);


    BillingFeeScheduleDTO getByCode(String id);
    List<BillingFeeScheduleDTO>getAll();
    BillingFeeScheduleDTO updateById(String id, BillingFeeScheduleRequest request);
    String delete(String id);

}
