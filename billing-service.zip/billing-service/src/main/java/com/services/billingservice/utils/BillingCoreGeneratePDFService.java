package com.services.billingservice.utils;

import com.services.billingservice.dto.core.BillingCoreDTO;
import com.services.billingservice.enums.BillingType;
import com.services.billingservice.enums.ReportGeneratorStatus;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingReportGenerator;
import com.services.billingservice.service.BillingReportGeneratorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.services.billingservice.constant.CoreConstant.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingCoreGeneratePDFService {

    @Value("${base.path.billing.core}")
    private String basePathBillingCore;

    @Value("${base.path.billing.image}")
    private String folderPathImage;


    private final SpringTemplateEngine templateEngine;
    private final PdfGenerator pdfGenerator;
    private final BillingReportGeneratorService billingReportGeneratorService;

    public void generateAndSavePdfStatements(List<BillingCore> billingCoreList) {
        log.info("Start generate and save pdf statements Billing Core");

        List<BillingReportGenerator> billingReportGeneratorList = new ArrayList<>();
        BillingReportGenerator billingReportGenerator = new BillingReportGenerator();
        Instant dateNow = Instant.now();

        List<BillingCoreDTO> billingCoreDTOList = mapToDTOList(billingCoreList);

        for (BillingCoreDTO billingCoreDTO : billingCoreDTOList) {
            log.info("Start generate PDF Billing Core type '{}' and AID '{}'", billingCoreDTO.getBillingType(), billingCoreDTO.getCustomerCode());

            String investmentManagementName = billingCoreDTO.getInvestmentManagementName();
            String investmentManagementEmail = billingCoreDTO.getInvestmentManagementEmail();
            String customerCode = billingCoreDTO.getCustomerCode();
            String customerName = billingCoreDTO.getCustomerName();
            String billingCategory = billingCoreDTO.getBillingCategory();
            String billingType = billingCoreDTO.getBillingType();
            String billingTemplate = billingCoreDTO.getBillingTemplate();
            String billingPeriod = billingCoreDTO.getBillingPeriod();

            Map<String, String> monthYearMap;
            String yearMonthFormat;
            String htmlContent;
            byte[] pdfBytes;
            String fileName = null;
            String filePath;
            String folderPath;
            String outputPath;

            if (billingType.equalsIgnoreCase(BillingType.TYPE_7.getValue())) {
                String[] split = billingPeriod.split(" - ");

                monthYearMap = ConvertDateUtil.extractMonthYearInformation(split[1]);
                yearMonthFormat = monthYearMap.get("year") + monthYearMap.get("monthValue");
            } else {
                monthYearMap = ConvertDateUtil.extractMonthYearInformation(billingPeriod);
                yearMonthFormat = monthYearMap.get("year") + monthYearMap.get("monthValue");
            }

            if (billingType.equalsIgnoreCase(BillingType.TYPE_4.getValue())) {
                if (billingTemplate.equalsIgnoreCase("TEMPLATE_5")) {
                    fileName = generateFileNameEB(customerCode, billingCategory, billingType, yearMonthFormat);
                } else if (billingTemplate.equalsIgnoreCase("TEMPLATE_3")) {
                    fileName = generateFileNameITAMA(customerCode, billingCategory, billingType, yearMonthFormat);
                } else {
                    log.info("Bukan Type 4 dan template 5 atau 3");
                }

            } else if (billingType.equalsIgnoreCase(BillingType.TYPE_7.getValue())) {
                fileName = generateFileNameMUFG(billingCategory, billingType, billingPeriod);
            } else {
                fileName = generateFileName(customerCode, billingCategory, billingType, yearMonthFormat);
            }

            int year = Integer.parseInt(monthYearMap.get("year"));
            String monthName = monthYearMap.get("monthName");

            folderPath = basePathBillingCore + yearMonthFormat + "/" + investmentManagementName;

            filePath = folderPath + "/" + fileName;

            savePdfToFileUtil(billingReportGeneratorList, billingReportGenerator, dateNow, billingCoreDTO, investmentManagementName, investmentManagementEmail, customerCode, customerName, billingCategory, billingType, billingPeriod, fileName, filePath, folderPath, year, monthName);
        }
    }

    private void savePdfToFileUtil(List<BillingReportGenerator> billingReportGeneratorList, BillingReportGenerator billingReportGenerator, Instant dateNow, BillingCoreDTO billingCoreDTO, String investmentManagementName, String investmentManagementEmail, String customerCode, String customerName, String billingCategory, String billingType, String billingPeriod, String fileName, String filePath, String folderPath, int year, String monthName) {
        String htmlContent;
        byte[] pdfBytes;
        String outputPath;

        try {
            htmlContent = renderThymeleafTemplate(billingCoreDTO);
            pdfBytes = pdfGenerator.generatePdfFromHtml(htmlContent);

            Path folderPathObj = Paths.get(folderPath);
            Files.createDirectories(folderPathObj);

            Path outputPathObj = folderPathObj.resolve(fileName);
            outputPath = outputPathObj.toString();

            pdfGenerator.savePdfToFile(pdfBytes, outputPath);

            billingReportGenerator.setCreatedAt(dateNow);
            billingReportGenerator.setInvestmentManagementName(investmentManagementName);
            billingReportGenerator.setInvestmentManagementEmail(investmentManagementEmail);
            billingReportGenerator.setCustomerCode(customerCode);
            billingReportGenerator.setCustomerName(customerName);
            billingReportGenerator.setType(billingType);
            billingReportGenerator.setCategory(billingCategory);
            billingReportGenerator.setPeriod(billingPeriod);
            billingReportGenerator.setMonth(monthName);
            billingReportGenerator.setYear(year);
            billingReportGenerator.setFileName(fileName);
            billingReportGenerator.setFilePath(filePath);
            billingReportGenerator.setStatus(ReportGeneratorStatus.SUCCESS.getStatus());
            billingReportGenerator.setDesc("Success generate and save PDF statements");

            billingReportGeneratorList.add(billingReportGenerator);
        } catch (Exception e) {
            log.error("Error creating folder or saving PDF : " + e.getMessage(), e);
            billingReportGenerator.setCreatedAt(dateNow);
            billingReportGenerator.setInvestmentManagementName(investmentManagementName);
            billingReportGenerator.setInvestmentManagementEmail(investmentManagementEmail);
            billingReportGenerator.setCustomerCode(customerCode);
            billingReportGenerator.setCustomerName(customerName);
            billingReportGenerator.setCategory(billingCategory);
            billingReportGenerator.setType(billingType);
            billingReportGenerator.setPeriod(billingPeriod);
            billingReportGenerator.setMonth(monthName);
            billingReportGenerator.setYear(year);
            billingReportGenerator.setFileName(fileName);
            billingReportGenerator.setFilePath(folderPath);
            billingReportGenerator.setStatus(ReportGeneratorStatus.FAILED.getStatus());
            billingReportGenerator.setDesc(e.getMessage());

            billingReportGeneratorList.add(billingReportGenerator);

            // throw new GeneratePDFBillingException("Error creating folder or saving PDF : " + e.getMessage());
        }
        // save report generator
        List<BillingReportGenerator> billingReportGeneratorListSaved = billingReportGeneratorService.saveAll(billingReportGeneratorList);
        log.info("Save billing report generator list saved '{}'", billingReportGeneratorListSaved.size());
    }

    private String renderThymeleafTemplate(BillingCoreDTO billingCoreDTO) {
        Context context = new Context();

        context.setVariable(BILLING_NUMBER, billingCoreDTO.getBillingNumber());
        context.setVariable(BILLING_PERIOD, billingCoreDTO.getBillingPeriod());
        context.setVariable(BILLING_STATEMENT_DATE, billingCoreDTO.getBillingStatementDate());
        context.setVariable(BILLING_PAYMENT_DUE_DATE, billingCoreDTO.getBillingPaymentDueDate());
        context.setVariable(BILLING_CATEGORY, billingCoreDTO.getBillingCategory());
        context.setVariable(BILLING_TYPE, billingCoreDTO.getBillingType());
        context.setVariable(BILLING_TEMPLATE, billingCoreDTO.getBillingTemplate());
        context.setVariable(INVESTMENT_MANAGEMENT_NAME, billingCoreDTO.getInvestmentManagementName());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_1, billingCoreDTO.getInvestmentManagementAddress1());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_2, billingCoreDTO.getInvestmentManagementAddress2());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_3, billingCoreDTO.getInvestmentManagementAddress3());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_4, billingCoreDTO.getInvestmentManagementAddress4());
        context.setVariable(ACCOUNT_NAME, billingCoreDTO.getAccountName());
        context.setVariable(ACCOUNT_NUMBER, billingCoreDTO.getAccountNumber());
        context.setVariable(ACCOUNT_BANK, billingCoreDTO.getAccountBank());
        context.setVariable(SWIFT_CODE, billingCoreDTO.getSwiftCode());

        context.setVariable(TRANSACTION_HANDLING_VALUE_FREQUENCY, billingCoreDTO.getTransactionHandlingValueFrequency());
        context.setVariable(TRANSACTION_HANDLING_FEE, billingCoreDTO.getTransactionHandlingFee());
        context.setVariable(TRANSACTION_HANDLING_AMOUNT_DUE, billingCoreDTO.getTransactionHandlingAmountDue());
        context.setVariable(SAFEKEEPING_VALUE_FREQUENCY, billingCoreDTO.getSafekeepingValueFrequency());
        context.setVariable(SAFEKEEPING_FEE, billingCoreDTO.getSafekeepingFee());
        context.setVariable(SAFEKEEPING_AMOUNT_DUE, billingCoreDTO.getSafekeepingAmountDue());
        context.setVariable(SUB_TOTAL, billingCoreDTO.getSubTotal());
        context.setVariable(VAT_FEE, billingCoreDTO.getVatFee());
        context.setVariable(VAT_AMOUNT_DUE, billingCoreDTO.getVatAmountDue());
        context.setVariable(TOTAL_AMOUNT_DUE, billingCoreDTO.getTotalAmountDue());

        context.setVariable(JOURNAL_CREDIT_TO, billingCoreDTO.getJournalCreditTo());
        context.setVariable(KSEI_SAFEKEEPING_AMOUNT_DUE, billingCoreDTO.getKseiSafekeepingAmountDue());
        context.setVariable(KSEI_TRANSACTION_VALUE_FREQUENCY, billingCoreDTO.getKseiTransactionValueFrequency());
        context.setVariable(KSEI_TRANSACTION_FEE, billingCoreDTO.getKseiTransactionFee());
        context.setVariable(KSEI_TRANSACTION_AMOUNT_DUE, billingCoreDTO.getKseiTransactionAmountDue());
        context.setVariable(BIS4_TRANSACTION_VALUE_FREQUENCY, billingCoreDTO.getBis4TransactionValueFrequency());
        context.setVariable(BIS4_TRANSACTION_FEE, billingCoreDTO.getBis4TransactionFee());
        context.setVariable(BIS4_TRANSACTION_AMOUNT_DUE, billingCoreDTO.getBis4TransactionAmountDue());

        context.setVariable(SAFEKEEPING_FEE_JOURNAL, billingCoreDTO.getSafekeepingFeeJournal());
        context.setVariable(TRANSACTION_HANDLING_JOURNAL, billingCoreDTO.getTransactionHandlingJournal());
        context.setVariable(CORR_BANK, billingCoreDTO.getCorrBank());
        context.setVariable(ACCOUNT_NUMBER_CBEST, billingCoreDTO.getAccNumberCBEST());

        context.setVariable(ADMINISTRATION_SET_UP_ITEM, billingCoreDTO.getAdministrationSetUpItem());
        context.setVariable(ADMINISTRATION_SET_UP_FEE, billingCoreDTO.getAdministrationSetUpFee());
        context.setVariable(ADMINISTRATION_SET_UP_AMOUNT_DUE, billingCoreDTO.getAdministrationSetUpAmountDue());
        context.setVariable(SIGNING_REPRESENTATION_ITEM, billingCoreDTO.getSigningRepresentationItem());
        context.setVariable(SIGNING_REPRESENTATION_FEE, billingCoreDTO.getSigningRepresentationFee());
        context.setVariable(SIGNING_REPRESENTATION_AMOUNT_DUE, billingCoreDTO.getSigningRepresentationAmountDue());
        context.setVariable(SECURITY_AGENT_ITEM, billingCoreDTO.getSecurityAgentItem());
        context.setVariable(SECURITY_AGENT_FEE, billingCoreDTO.getSecurityAgentFee());
        context.setVariable(SECURITY_AGENT_AMOUNT_DUE, billingCoreDTO.getSecurityAgentAmountDue());
        context.setVariable(TRANSACTION_HANDLING_ITEM, billingCoreDTO.getTransactionHandlingItem());
        context.setVariable(SAFEKEEPING_ITEM, billingCoreDTO.getSafekeepingItem());
        context.setVariable(OTHER_ITEM, billingCoreDTO.getOtherItem());
        context.setVariable(OTHER_FEE, billingCoreDTO.getOtherFee());
        context.setVariable(OTHER_AMOUNT_DUE, billingCoreDTO.getOtherAmountDue());

        context.setVariable(SAFEKEEPING_FEE_PERIOD, billingCoreDTO.getBillingPeriod());

        // tambahkan Image URL
        String imageUrlHeader = "file:///" + folderPathImage + "/logo.png";
        String imageUrlFooter = "file:///" + folderPathImage + "/footer.png";
        context.setVariable("imageUrlHeader", imageUrlHeader);
        context.setVariable("imageUrlFooter", imageUrlFooter);

        String billingTemplate = billingCoreDTO.getBillingCategory() +  "_" + billingCoreDTO.getBillingTemplate();
        log.info("Billing Template '{}'", billingTemplate);
        return templateEngine.process(billingTemplate, context);
    }

    private String generateFileName(String aid, String billingCategory, String billingType, String yearMonthFormat) {
        return aid + "_" + billingCategory + "_" + billingType + "_" + yearMonthFormat + ".pdf";
    }

    private String generateFileNameEB(String aid, String billingCategory, String billingType, String yearMonthFormat) {
        return aid + "_" + "EB" + "_" + billingCategory + "_" + billingType + "_" + yearMonthFormat + ".pdf";
    }

    private String generateFileNameITAMA(String aid, String billingCategory, String billingType, String yearMonthFormat) {
        return aid + "_" + "Itama" + "_" + billingCategory + "_" + billingType + "_" + yearMonthFormat + ".pdf";
    }

    private String generateFileNameMUFG(String billingCategory, String billingType, String billingPeriod) {
        // Billing Period = Aug 2023 - Oct 2023
        String[] split = billingPeriod.split(" - ");
        String[] s = split[0].split(" ");

        String monthString1 = s[0]; // OCTOBER
        String s2 = s[1]; // 2023

        Month month1 = MonthConverterUtil.getMonth(monthString1.toUpperCase());
        int monthValue1 = month1.getValue();

        String formattedMonth1 = (monthValue1 < 10) ? "0" + monthValue1 : String.valueOf(monthValue1);

        String[] s3 = split[1].split(" ");
        String monthString2 = s3[0]; // AUGUST

        String s5 = s3[1]; // 2023

        Month month2 = MonthConverterUtil.getMonth(monthString2.toUpperCase());

        int monthValue2 = month2.getValue();
        String formattedMonth2 = (monthValue2 < 10) ? "0" + monthValue2 : String.valueOf(monthValue2);

        return "MUFG_" + billingCategory + "_" + billingType + "_" + formattedMonth1 + s2 + "-" + formattedMonth2 + s5 + ".pdf";
    }

    private BillingCoreDTO mapToDTO(BillingCore billingCore) {
        return BillingCoreDTO.builder()
                .createdAt(billingCore.getCreatedAt())
                .updatedAt(billingCore.getUpdatedAt())
                .approvalStatus(billingCore.getApprovalStatus().getStatus())
                .billingStatus(billingCore.getBillingStatus().getStatus())
                .customerCode(billingCore.getCustomerCode())
                .customerName(billingCore.getCustomerName())
                .month(billingCore.getMonth())
                .year(String.valueOf(billingCore.getYear()))
                .billingNumber(billingCore.getBillingNumber())
                .billingPeriod(billingCore.getBillingPeriod())
                .billingStatementDate(billingCore.getBillingStatementDate())
                .billingPaymentDueDate(billingCore.getBillingPaymentDueDate())
                .billingCategory(billingCore.getBillingCategory())
                .billingType(billingCore.getBillingType())
                .billingTemplate(billingCore.getBillingTemplate())
                .investmentManagementName(billingCore.getInvestmentManagementName())
                .investmentManagementAddress1(billingCore.getInvestmentManagementAddress1())
                .investmentManagementAddress2(billingCore.getInvestmentManagementAddress2())
                .investmentManagementAddress3(billingCore.getInvestmentManagementAddress3())
                .investmentManagementAddress4(billingCore.getInvestmentManagementAddress4())
                .investmentManagementEmail(billingCore.getInvestmentManagementEmail())
                .accountName(billingCore.getAccountName())
                .accountNumber(billingCore.getAccountNumber())
                .accountBank(billingCore.getAccountBank())
                .swiftCode(billingCore.getSwiftCode())
                .currency(billingCore.getCurrency())
                .transactionHandlingValueFrequency(String.valueOf(billingCore.getTransactionHandlingValueFrequency()))
                .transactionHandlingFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getTransactionHandlingFee()))
                .transactionHandlingAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getTransactionHandlingAmountDue()))
                .safekeepingValueFrequency(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSafekeepingValueFrequency()))
                .safekeepingFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSafekeepingFee()))
                .safekeepingAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSafekeepingAmountDue()))
                .subTotal(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSubTotal()))
                .vatFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getVatFee()))
                .vatAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getVatAmountDue()))
                .totalAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getTotalAmountDue()))
                .journalCreditTo(billingCore.getSafekeepingJournal())
                .kseiSafekeepingAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getKseiSafekeepingAmountDue()))
                .kseiTransactionValueFrequency(String.valueOf(billingCore.getKseiTransactionValueFrequency()))
                .kseiTransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getKseiTransactionFee()))
                .kseiTransactionAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getKseiTransactionAmountDue()))
                .bis4TransactionValueFrequency(String.valueOf(billingCore.getBis4TransactionValueFrequency()))
                .bis4TransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getBis4TransactionFee()))
                .bis4TransactionAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getBis4TransactionAmountDue()))
                .safekeepingFeeJournal(billingCore.getSafekeepingJournal())
                .transactionHandlingJournal(billingCore.getTransactionHandlingJournal())
                .accNumberCBEST(billingCore.getAccountNumberCBEST())
                .administrationSetUpItem(String.valueOf(billingCore.getAdministrationSetUpItem()))
                .administrationSetUpFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getAdministrationSetUpFee()))
                .administrationSetUpAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getAdministrationSetUpAmountDue()))
                .signingRepresentationItem(String.valueOf(billingCore.getSigningRepresentationItem()))
                .signingRepresentationFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSigningRepresentationFee()))
                .signingRepresentationAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSigningRepresentationAmountDue()))
                .securityAgentItem(String.valueOf(billingCore.getSecurityAgentItem()))
                .securityAgentFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSecurityAgentFee()))
                .securityAgentAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSecurityAgentAmountDue()))
                .transactionHandlingItem(String.valueOf(billingCore.getTransactionHandlingItem()))
                .safekeepingItem(String.valueOf(billingCore.getSafekeepingItem()))
                .otherItem(String.valueOf(billingCore.getOtherItem()))
                .otherFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getOtherFee()))
                .otherAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getOtherAmountDue()))
                .build();
    }

    private List<BillingCoreDTO> mapToDTOList(List<BillingCore> billingCoreList) {
        return billingCoreList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

}
