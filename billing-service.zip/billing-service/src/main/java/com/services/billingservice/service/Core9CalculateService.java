package com.services.billingservice.service;

import com.services.billingservice.dto.core.CoreCalculateRequest;

public interface Core9CalculateService {

    String calculate(CoreCalculateRequest request);

}
