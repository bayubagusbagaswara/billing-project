package com.services.billingservice.service;

import com.services.billingservice.model.SfValCrowdFunding;

import java.util.List;

public interface SfValCrowdFundingService {

    String readAndInsertToDB(String filePath);

    List<SfValCrowdFunding> getAll();

    List<SfValCrowdFunding> getAllByClientCode(String clientCode);

    List<SfValCrowdFunding> getAllByClientCodeAndMonthAndYear(String clientCode, String monthName, Integer year);

    String deleteAll();

}
