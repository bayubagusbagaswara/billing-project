package com.services.billingservice.controller;

import com.services.billingservice.dto.BillingFeeParamDTO;
import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.request.BillingFeeParamRequest;
import com.services.billingservice.dto.request.BillingFeeParamUploadRequest;
import com.services.billingservice.model.BillingFeeParam;
import com.services.billingservice.service.BillingFeeParamService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.xml.ws.Response;
import java.util.List;

@RestController
@RequestMapping(path = "/feeParam")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class BillingFeeParamController {

    private final BillingFeeParamService billingFeeParamService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<String>>
    create(@RequestBody BillingFeeParamRequest request) {

        BillingFeeParamDTO billingFeeParamDTO = billingFeeParamService.create(request);

        ResponseDTO<String> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload("Successfully create Fee Param with id :" + billingFeeParamDTO.getId());

        return new ResponseEntity<>(response, HttpStatus.CREATED);

    }

    @PostMapping(path = "/upload")
    public ResponseEntity<ResponseDTO<List<BillingFeeParamDTO>>> upload(
            @RequestBody List<BillingFeeParamUploadRequest> billingFeeParamList) {
        List<BillingFeeParamDTO> billingFeeParamDTO = billingFeeParamService.upload(billingFeeParamList);

        ResponseDTO<List<BillingFeeParamDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.getReasonPhrase());
        response.setPayload(billingFeeParamDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);

    }

    @PutMapping(path = "/updateById")
    public ResponseEntity<ResponseDTO<BillingFeeParamDTO>> updateById(@RequestParam(name = "id") String id,
                                                                        @RequestBody BillingFeeParamRequest request) {
        BillingFeeParamDTO billingFeeParamDTO = billingFeeParamService.updateById(id, request);
        ResponseDTO<BillingFeeParamDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingFeeParamDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(path = "/updateByCode")
    public ResponseEntity<ResponseDTO<BillingFeeParamDTO>> updateByCode(@RequestParam(name = "code") String code,
                                                                           @RequestBody BillingFeeParamRequest request) {
        BillingFeeParamDTO billingFeeParamDTO = billingFeeParamService.updateByCode(code, request);
        ResponseDTO<BillingFeeParamDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingFeeParamDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<List<BillingFeeParamDTO>>> update(
            @RequestBody List<BillingFeeParamUploadRequest> billingFeeParamList) {
        List<BillingFeeParamDTO> billingFeeParamDTO = billingFeeParamService.updateUploadByCode(billingFeeParamList );

        ResponseDTO<List<BillingFeeParamDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.getReasonPhrase());
        response.setPayload(billingFeeParamDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);

    }

    @GetMapping(path = "/getByCode")
    public ResponseEntity<ResponseDTO<BillingFeeParamDTO>> getByCode(@RequestParam(name = "code") String code) {
        BillingFeeParamDTO billingFeeParamDTO = billingFeeParamService.getByCode(code);

        ResponseDTO<BillingFeeParamDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingFeeParamDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BillingFeeParamDTO>>> getAll() {
        List<BillingFeeParamDTO> billingFeeParamDTOList = billingFeeParamService.getAll();

        ResponseDTO<List<BillingFeeParamDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingFeeParamDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/getById")
    public ResponseEntity<ResponseDTO<BillingFeeParamDTO>> getById(@RequestParam(name = "id") String id) {
        BillingFeeParamDTO billingFeeParamDTO = billingFeeParamService.getById(id);

        ResponseDTO<BillingFeeParamDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingFeeParamDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping(path = "/delete")
    public ResponseEntity<ResponseDTO<String>> deleteByCode(@RequestParam("id") String id) {
        String deleteById = billingFeeParamService.deleteById(id);

        ResponseDTO<String> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(deleteById);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
