package com.services.billingservice.repository;

import com.services.billingservice.dto.fund.BillingFundListProcess;
import com.services.billingservice.model.BillingFund;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillingFundRepository extends JpaRepository<BillingFund, Long> {

    //TODO for payment
    @Query(value = "SELECT * FROM billing_fund " +
            "WHERE bill_category = :billingCategory " +
            "AND month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus", nativeQuery = true)
    List<BillingFund> findAllByBillingCategoryAndMonthAndYearAndApprovalStatus(
            @Param("billingCategory") String billingCategory,
            @Param("month") String month,
            @Param("year") int year,
            @Param("approvalStatus") String approvalStatus
    );

    @Query(value = "SELECT * FROM billing_fund " +
            "WHERE customer_code = :custCode " +
            "AND month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus", nativeQuery = true)
    BillingFund findByCustomerCodeAndMonthAndYearAndApprovalStatus(
            @Param("custCode") String custCode,
            @Param("month") String month,
            @Param("year") int year,
            @Param("approvalStatus") String approvalStatus
    );

    @Query(value = "SELECT * FROM billing_fund " +
            "WHERE bill_category = :billingCategory " +
            "AND bill_type = :billingType " +
            "AND month = :month " +
            "AND year = :year", nativeQuery = true)
    List<BillingFund> findAllByBillingCategoryAndBillingTypeAndMonthAndYear(
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("month") String month,
            @Param("year") Integer year
    );

    @Query(value = "SELECT * FROM billing_fund " +
            "WHERE customer_code = :customerCode " +
            "AND bill_category = :billingCategory " +
            "AND bill_type = :billingType " +
            "AND month = :month " +
            "AND year = :year", nativeQuery = true)
    Optional<BillingFund> findByCustomerCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
            @Param("customerCode") String customerCode,
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("month") String monthName,
            @Param("year") int year
    );

    List<BillingFund> findByMonthAndYear(String month, Integer year);

    List<BillingFund> findByMonthAndYearAndBillingCategoryAndBillingType(String month, Integer year, String category, String type);

    @Query(value = "SELECT DISTINCT NEW com.services.billingservice.dto.fund.BillingFundListProcess " +
            "(f.month, f.year, MAX(f.createdAt), f.approvalStatus, f.billingStatus) " +
            "FROM BillingFund f " +
            "GROUP BY f.month, f.year, f.approvalStatus, f.billingStatus " +
            "ORDER BY f.year DESC, month DESC")
    List<BillingFundListProcess> getAllListProcess();

    @Query(value = "SELECT DISTINCT NEW com.services.billingservice.dto.fund.BillingFundListProcess " +
            "(f.month, f.year, MAX(f.createdAt), f.approvalStatus, f.billingStatus) " +
            "FROM BillingFund f " +
            "WHERE upper(f.approvalStatus) = 'PENDING' " +
            "   AND upper(f.billingStatus) = 'REVIEWED' " +
            "GROUP BY f.month, f.year, f.approvalStatus, f.billingStatus " +
            "ORDER BY f.year DESC, month DESC")
    List<BillingFundListProcess> getAllListPendingApprove();
}
