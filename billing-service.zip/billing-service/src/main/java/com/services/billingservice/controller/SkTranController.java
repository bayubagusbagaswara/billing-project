package com.services.billingservice.controller;

import com.opencsv.exceptions.CsvException;
import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.service.SkTranService;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

@Slf4j
@RestController
@RequestMapping(path = "/api/sk-tran")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class SkTranController {

    @Value("${file.path.sk-tran}")
    private String filePath;

    private final SkTranService skTranService;

    public SkTranController(SkTranService skTranService) {
        this.skTranService = skTranService;
    }

    @GetMapping(path = "/read-insert")
    public ResponseEntity<ResponseDTO<String>> readAndInsert() throws IOException, CsvException {
        log.info("File Path : {}", filePath);

        String status = skTranService.readFileAndInsertToDB(filePath);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<SkTransaction>>> getAll() {
        List<SkTransaction> skTransactionList = skTranService.getAll();

        ResponseDTO<List<SkTransaction>> response = ResponseDTO.<List<SkTransaction>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(skTransactionList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/portfolio-code")
    public ResponseEntity<ResponseDTO<List<SkTransaction>>> getAllByPortfolioCode(@RequestParam("portfolioCode") String portfolioCode) {
        List<SkTransaction> skTransactionList = skTranService.getAllByPortfolioCode(portfolioCode);

        ResponseDTO<List<SkTransaction>> response = ResponseDTO.<List<SkTransaction>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(skTransactionList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/portfolio-code/system")
    public ResponseEntity<ResponseDTO<List<SkTransaction>>> getAllByPortfolioCodeAndSystem(
            @RequestParam("portfolioCode") String portfolioCode,
            @RequestParam("system") String system) {

        List<SkTransaction> skTransactionList = skTranService.getAllByPortfolioCodeAndSystem(portfolioCode, system);

        ResponseDTO<List<SkTransaction>> response = ResponseDTO.<List<SkTransaction>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(skTransactionList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping
    public ResponseEntity<ResponseDTO<String>> deleteAll() {
        String status = skTranService.deleteAll();

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/period")
    public ResponseEntity<ResponseDTO<List<SkTransaction>>> getAllByAidAndPeriod(@RequestParam("aid") String aid,
                                                                                           @RequestParam("month") String month,
                                                                                           @RequestParam("year") Integer year) {
        List<SkTransaction> skTransactionList = skTranService.getAllByAidAndMonthAndYear(aid, month, year);

        ResponseDTO<List<SkTransaction>> response = ResponseDTO.<List<SkTransaction>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(skTransactionList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/retail/aid/period")
    public ResponseEntity<ResponseDTO<List<SkTransaction>>> getAllRetailByAidAndPeriod(@RequestParam("aid") String aid,
                                                                                       @RequestParam("month") String month,
                                                                                       @RequestParam("year") Integer year) {
        String monthYearFormat = month + " " + year;
        LocalDate date = ConvertDateUtil.getFirstDateOfMonthYear(monthYearFormat);

        List<SkTransaction> skTransactionList = skTranService.getAllRetailByAidAndPeriod(aid, date);

        ResponseDTO<List<SkTransaction>> response = ResponseDTO.<List<SkTransaction>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(skTransactionList)
                .build();

        return ResponseEntity.ok().body(response);
    }

}
