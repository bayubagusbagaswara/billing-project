package com.services.billingservice.utils;

import com.services.billingservice.model.BillingFund;
import com.services.billingservice.repository.BillingFundRepository;
import com.services.billingservice.service.BillingReportGeneratorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.spring5.SpringTemplateEngine;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingFundGeneratePDFService {

    @Value("${base.path.billing.fund}")
    private String basePathBillingFund;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private final SpringTemplateEngine templateEngine;
    private final PdfGenerator pdfGenerator;
    private final BillingReportGeneratorService billingReportGeneratorService;

    public void generateAndSavePdfStatements(List<BillingFund> billingFundList) {
        log.info("Start generate and save PDF statements");

    }
}
