package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.*;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.ConnectionDatabaseException;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.BillingCoreGeneralService;
import com.services.billingservice.service.BillingNumberService;
import com.services.billingservice.utils.BeanUtil;
import com.services.billingservice.utils.ConvertBigDecimalUtil;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingCoreGeneralServiceImpl implements BillingCoreGeneralService {

    private final BillingCoreRepository billingCoreRepository;
    private final BillingNumberService billingNumberService;

    @Override
    public void checkingExistingBillingCore(String monthName, Integer year, String aid, String billingCategory, String billingType) {

        List<BillingCore> existingBillingCores = billingCoreRepository.findAllByCustomerCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(aid, billingCategory, billingType, monthName, year);

        log.info("Existing Billing Core type '{}' is size '{}'", billingType, existingBillingCores.size());

        for (BillingCore existingBillingCore : existingBillingCores) {
            String billingNumber = existingBillingCore.getBillingNumber();
            billingCoreRepository.delete(existingBillingCore);
            billingNumberService.deleteByBillingNumber(billingNumber);
        }
    }

    @Override
    public String deleteAll() {
        try {
            billingCoreRepository.deleteAll();
            return "Successfully deleted all Billing Core";
        } catch (Exception e) {
            log.error("Error when delete all Billing Core : " + e.getMessage(), e);
            throw new ConnectionDatabaseException("Error when delete all Billing Core: " + e.getMessage());
        }
    }

    @Override
    public List<BillingCoreDTO> getAll(String categoryUpperCase, String typeUpperCase, String monthName, Integer year) {
        List<BillingCore> billingCoreList = billingCoreRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYear(
                categoryUpperCase, typeUpperCase, monthName, year
        );

        return mapToDTOList(billingCoreList);
    }

    @Override
    public List<BillingCore> findByMonthAndYear(String month, Integer year) {
        return billingCoreRepository.findByMonthAndYear(month, year);
    }

    @Override
    public List<BillingCoreListProcessDTO> getAllListPendingApprove() {
        List<BillingCoreListProcessDTO> result = new ArrayList<>();
        billingCoreRepository.getAllListPendingApprove().stream()
                .forEach(f -> {
                    BillingCoreListProcessDTO temp = new BillingCoreListProcessDTO();
                    BeanUtil.copyAllProperties(f, temp);
                    temp.setApprovalStatus(f.getApprovalStatus().getStatus());
                    temp.setBillingStatus(f.getBillingStatus().getStatus());
                    result.add(temp);
                });
        return result;
    }

    @Override
    public List<BillingCoreListProcessDTO> getAllListProcess() {
        List<BillingCoreListProcessDTO> result = new ArrayList<>();
        billingCoreRepository.getAllListProcess().stream()
                .forEach(f -> {
                    BillingCoreListProcessDTO temp = new BillingCoreListProcessDTO();
                    BeanUtil.copyAllProperties(f, temp);
                    temp.setApprovalStatus(f.getApprovalStatus().getStatus());
                    temp.setBillingStatus(f.getBillingStatus().getStatus());
                    result.add(temp);
                });
        return result;
    }

    @Override
    public String deleteByCategoryAndTypeAndMonthYear(CoreCalculateRequest request) {
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            List<BillingCore> billingCoreList = billingCoreRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYear(categoryUpperCase, typeUpperCase, monthName, year);

            for (BillingCore billingCore : billingCoreList) {
                billingCoreRepository.delete(billingCore);
            }

            return "Successfully delete Billing Core with total : " + billingCoreList.size();
        } catch (Exception e) {
            throw new ConnectionDatabaseException("Error when delete Billing Core : " + e.getMessage());
        }
    }

    @Override
    public List<BillingCoreDTO> updateAll(List<UpdateBillingCoreRequest> requestList) {
        List<BillingCore> billingCoreList = new ArrayList<>();

        // looping request list
        for (UpdateBillingCoreRequest request : requestList) {
            Long id = request.getId();

            BillingCore billingCore = billingCoreRepository.findById(id)
                    .orElseThrow(() -> new DataNotFoundException("Billing Core with id '" + id + "is not found"));

            BeanUtil.copyNotNullProperties(request, billingCore);

            billingCore.setUpdatedAt(Instant.now());

            billingCoreList.add(billingCore);
        }

        List<BillingCore> billingCoreListSaved = billingCoreRepository.saveAll(billingCoreList);

        return mapToDTOList(billingCoreListSaved);
    }

    @Override
    public String updateApprovalStatus(UpdateApprovalStatusBillingCoreRequest request) {
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

            String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            ApprovalStatus approvalStatus;
            BillingStatus billingStatus;

            if (request.getApprovalStatus().equalsIgnoreCase(ApprovalStatus.Approved.getStatus())) {
                approvalStatus = ApprovalStatus.Approved;
            } else if (request.getApprovalStatus().equalsIgnoreCase(ApprovalStatus.Rejected.getStatus())) {
                approvalStatus = ApprovalStatus.Rejected;
            } else {
                approvalStatus = ApprovalStatus.Pending;
            }

            if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Reviewed.getStatus())) {
                billingStatus = BillingStatus.Reviewed;
            } else if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Approved.getStatus())) {
                billingStatus = BillingStatus.Approved;
            } else if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Rejected.getStatus())) {
                billingStatus = BillingStatus.Rejected;
            } else {
                billingStatus = BillingStatus.Generated;
            }

            List<BillingCore> billingCoreList = billingCoreRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYear(categoryUpperCase, typeUpperCase, monthName, year);

            for (BillingCore billingCore : billingCoreList) {
                billingCore.setApprovalStatus(approvalStatus);
                billingCore.setBillingStatus(billingStatus);
            }

            List<BillingCore> billingCoreListSaved = billingCoreRepository.saveAll(billingCoreList);

            return "Successfully update Billing Core with approval status '" + approvalStatus + "' and billing status '" + billingStatus + " total: '" + billingCoreListSaved.size() + "'";
        } catch (Exception e) {
            throw new ConnectionDatabaseException("Error when update approval status Billing Fund : " + e.getMessage());
        }
    }

    private BillingCoreDTO mapToDTO(BillingCore billingCore) {
        return BillingCoreDTO.builder()
                .createdAt(billingCore.getCreatedAt())
                .updatedAt(billingCore.getUpdatedAt())
                .approvalStatus(billingCore.getApprovalStatus().getStatus())
                .billingStatus(billingCore.getBillingStatus().getStatus())
                .customerCode(billingCore.getCustomerCode())
                .customerName(billingCore.getCustomerName())
                .month(billingCore.getMonth())
                .year(String.valueOf(billingCore.getYear()))
                .billingNumber(billingCore.getBillingNumber())
                .billingPeriod(billingCore.getBillingPeriod())
                .billingStatementDate(billingCore.getBillingStatementDate())
                .billingPaymentDueDate(billingCore.getBillingPaymentDueDate())
                .billingCategory(billingCore.getBillingCategory())
                .billingType(billingCore.getBillingType())
                .billingTemplate(billingCore.getBillingTemplate())
                .investmentManagementName(billingCore.getInvestmentManagementName())
                .investmentManagementAddress1(billingCore.getInvestmentManagementAddress1())
                .investmentManagementAddress2(billingCore.getInvestmentManagementAddress2())
                .investmentManagementAddress3(billingCore.getInvestmentManagementAddress3())
                .investmentManagementAddress4(billingCore.getInvestmentManagementAddress4())
                .accountName(billingCore.getAccountName())
                .accountNumber(billingCore.getAccountNumber())
                .accountBank(billingCore.getAccountBank())
                .swiftCode(billingCore.getSwiftCode())
                .transactionHandlingValueFrequency(String.valueOf(billingCore.getTransactionHandlingValueFrequency()))
                .transactionHandlingFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getTransactionHandlingFee()))
                .transactionHandlingAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getTransactionHandlingAmountDue()))
                .safekeepingValueFrequency(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSafekeepingValueFrequency()))
                .safekeepingFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSafekeepingFee()))
                .safekeepingAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSafekeepingAmountDue()))
                .subTotal(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSubTotal()))
                .vatFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getVatFee()))
                .vatAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getVatAmountDue()))
                .totalAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getTotalAmountDue()))
                .journalCreditTo(billingCore.getSafekeepingJournal())
                .kseiSafekeepingAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getKseiSafekeepingAmountDue()))
                .kseiTransactionValueFrequency(String.valueOf(billingCore.getKseiTransactionValueFrequency()))
                .kseiTransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getKseiTransactionFee()))
                .kseiTransactionAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getKseiTransactionAmountDue()))
                .bis4TransactionValueFrequency(String.valueOf(billingCore.getBis4TransactionValueFrequency()))
                .bis4TransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getBis4TransactionFee()))
                .bis4TransactionAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getBis4TransactionAmountDue()))
                .safekeepingFeeJournal(billingCore.getSafekeepingJournal())
                .transactionHandlingJournal(billingCore.getTransactionHandlingJournal())
                .accNumberCBEST(billingCore.getAccountNumberCBEST())
                .administrationSetUpItem(String.valueOf(billingCore.getAdministrationSetUpItem()))
                .administrationSetUpFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getAdministrationSetUpFee()))
                .administrationSetUpAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getAdministrationSetUpAmountDue()))
                .signingRepresentationItem(String.valueOf(billingCore.getSigningRepresentationItem()))
                .signingRepresentationFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSigningRepresentationFee()))
                .signingRepresentationAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSigningRepresentationAmountDue()))
                .securityAgentItem(String.valueOf(billingCore.getSecurityAgentItem()))
                .securityAgentFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSecurityAgentFee()))
                .securityAgentAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSecurityAgentAmountDue()))
                .transactionHandlingItem(String.valueOf(billingCore.getTransactionHandlingItem()))
                .safekeepingItem(String.valueOf(billingCore.getSafekeepingItem()))
                .otherItem(String.valueOf(billingCore.getOtherItem()))
                .otherFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getOtherFee()))
                .otherAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getOtherAmountDue()))
                .build();
    }

    private List<BillingCoreDTO> mapToDTOList(List<BillingCore> billingCoreList) {
        return billingCoreList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }
}
