package com.services.billingservice.enums;

public enum GefuTransactionType {
    Credit, Debit
}
