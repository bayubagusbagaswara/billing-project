package com.services.billingservice.service;

import com.services.billingservice.dto.customer.*;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;

public interface CustomerService {

    boolean isCodeAlreadyExists(String code);

    CreateCustomerListResponse createSingleData(CreateCustomerRequest request, BillingDataChangeDTO dataChangeDTO);

    CreateCustomerListResponse createMultipleData(CreateCustomerListRequest request, BillingDataChangeDTO dataChangeDTO);

    CreateCustomerListResponse createMultipleApprove(CreateCustomerListRequest request);

    UpdateCustomerListResponse updateSingleData(UpdateCustomerRequest updateCustomerRequest, BillingDataChangeDTO dataChangeDTO);

    UpdateCustomerListResponse updateMultipleData(UpdateCustomerListRequest updateCustomerListRequest, BillingDataChangeDTO dataChangeDTO);

    UpdateCustomerListResponse updateMultipleApprove(UpdateCustomerListRequest updateCustomerListRequest);

    DeleteCustomerListResponse deleteSingleData(DeleteCustomerRequest deleteCustomerRequest, BillingDataChangeDTO dataChangeDTO);

    DeleteCustomerListResponse deleteMultipleApprove(DeleteCustomerListRequest deleteCustomerListRequest);
}
