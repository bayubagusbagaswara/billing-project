package com.services.billingservice.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class BillingSellingAgentDataDTO {
    private Long id;

    private String billingSellingAgentCode;

    private String billingSellingAgentName;

    private String billingSellingAgentGl;

    private String billingSellingAgentGlname;

    private String billingSellingAgentAccount;

    private String billingSellingAgentAccountName;

    private String billingSellingAgentEmail;

    private String billingSellingAgentAlamat;

    private String billingSellingAgentDesc;
}
