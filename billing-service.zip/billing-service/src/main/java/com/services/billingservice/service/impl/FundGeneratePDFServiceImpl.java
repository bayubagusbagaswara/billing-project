package com.services.billingservice.service.impl;

import com.services.billingservice.dto.fund.BillingFundDTO;
import com.services.billingservice.dto.fund.BillingFundListProcessDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.ReportGeneratorStatus;
import com.services.billingservice.exception.ConnectionDatabaseException;
import com.services.billingservice.exception.GeneratePDFBillingException;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.model.BillingReportGenerator;
import com.services.billingservice.repository.BillingFundRepository;
import com.services.billingservice.service.BillingReportGeneratorService;
import com.services.billingservice.service.FundGeneratePDFService;
import com.services.billingservice.utils.BeanUtil;
import com.services.billingservice.utils.ConvertBigDecimalUtil;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.PdfGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.services.billingservice.constant.FundConstant.*;
import static com.services.billingservice.enums.BillingTemplate.FUND_TEMPLATE;

@Slf4j
@Service
@RequiredArgsConstructor
public class FundGeneratePDFServiceImpl implements FundGeneratePDFService {

    @Value("${base.path.billing.fund}")
    private String basePathBillingFund;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private final BillingFundRepository billingFundRepository;
    private final SpringTemplateEngine templateEngine;
    private final PdfGenerator pdfGenerator;
    private final BillingReportGeneratorService billingReportGeneratorService;

    @Override
    public List<BillingFundDTO> getAll() {
        List<BillingFund> billingFundList = billingFundRepository.findAll();
        return mapToDTOList(billingFundList);
    }

    @Override
    public List<BillingFundListProcessDTO> getAllListProcess() {
        List<BillingFundListProcessDTO> result = new ArrayList<>();
        billingFundRepository.getAllListProcess().stream()
                .forEach(f -> {
                    BillingFundListProcessDTO temp = new BillingFundListProcessDTO();
                    BeanUtil.copyAllProperties(f, temp);
                    temp.setApprovalStatus(f.getApprovalStatus().getStatus());
                    temp.setBillingStatus(f.getBillingStatus().getStatus());
                    result.add(temp);
                });
        return result;
    }

    @Override
    public List<BillingFundListProcessDTO> getAllListPendingApprove() {
        List<BillingFundListProcessDTO> result = new ArrayList<>();
        billingFundRepository.getAllListPendingApprove().stream()
                .forEach(f -> {
                    BillingFundListProcessDTO temp = new BillingFundListProcessDTO();
                    BeanUtil.copyAllProperties(f, temp);
                    temp.setApprovalStatus(f.getApprovalStatus().getStatus());
                    temp.setBillingStatus(f.getBillingStatus().getStatus());
                    result.add(temp);
                });
        return result;
    }

    @Override
    public List<BillingFundDTO> findByMonthAndYear(String month, Integer year) {
        List<BillingFund> billingFundList = billingFundRepository.findByMonthAndYear(month, year);
        return mapToDTOList(billingFundList);
    }

    @Override
    public List<BillingFundDTO> findByMonthAndYearAndBillingCategoryAndBillingType(String month, Integer year, String category, String type) {
        List<BillingFund> billingFundList = billingFundRepository.findByMonthAndYearAndBillingCategoryAndBillingType(month, year, category, type);
        return mapToDTOList(billingFundList);
    }

    @Override
    public String generatePDF(String category, String monthYear) {
        log.info("Start generate PDF Billing Fund with month year '{}'", monthYear);
        try {
            String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(monthYear);
            String month = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            // TODO: Update status Approval Status to Approved
            String approvalStatus = ApprovalStatus.Pending.getStatus();

            List<BillingFund> billingFundList = billingFundRepository.findAllByBillingCategoryAndMonthAndYearAndApprovalStatus(
                    category, month, year, approvalStatus
            );

            // masukkan ke class util BillingFundGeneratePDFService
            List<BillingFundDTO> fundDTOList = mapToDTOList(billingFundList);

            generateAndSavePDFStatements(fundDTOList);

            log.info("Finished generate PDF file for Billing Fund");
            return "Successfully created a PDF file for Billing Fund";
        } catch (Exception e) {
            log.error("Error when generate PDF Billing Fund : " + e.getMessage(), e);
            throw new GeneratePDFBillingException("Error when generate PDF Billing Fund : " + e.getMessage());
        }
    }

    @Override
    public String deleteAll() {
        try {
            billingFundRepository.deleteAll();
            return "Successfully delete all Billing Fund";
        } catch (Exception e) {
            log.error("Error when delete all Billing Funds : " + e.getMessage(), e);
            throw new ConnectionDatabaseException("Error when delete all Billing Funds : " + e.getMessage());
        }
    }

    private void generateAndSavePDFStatements(List<BillingFundDTO> fundDTOList) {
        log.info("Start generate and save pdf statements Billing Fund");

        List<BillingReportGenerator> billingReportGeneratorList = new ArrayList<>();
        BillingReportGenerator billingReportGenerator = new BillingReportGenerator();
        Instant dateNow = Instant.now();

        for (BillingFundDTO fundDTO : fundDTOList) {
            log.info("Start generate PDF Billing Fund type '{}' and customer code '{}'", fundDTO.getBillingType(), fundDTO.getCustomerCode());

            String investmentManagementName = fundDTO.getInvestmentManagementName();
            String investmentManagementEmail = fundDTO.getInvestmentManagementEmail();
            String customerCode = fundDTO.getCustomerCode();
            String customerName = fundDTO.getCustomerName();
            String billingCategory = fundDTO.getBillingCategory();
            String billingType = fundDTO.getBillingType();
            String billingPeriod = fundDTO.getBillingPeriod();
            String currency = fundDTO.getCurrency();

            Map<String, String> monthYearMap;
            String yearMonthFormat;
            String htmlContent;
            byte[] pdfBytes;
            String fileName;
            String filePath;
            String folderPath;
            String outputPath;

            monthYearMap = ConvertDateUtil.extractMonthYearInformation(fundDTO.getBillingPeriod());

            int year = Integer.parseInt(monthYearMap.get("year"));
            String monthName = monthYearMap.get("monthName");

            yearMonthFormat =  year + monthYearMap.get("monthValue");

            fileName = generateFileName(customerCode, yearMonthFormat);

            folderPath = basePathBillingFund + yearMonthFormat + "/" +  investmentManagementName;

            filePath = folderPath + "/" + fileName;

            try {
                htmlContent = renderThymeleafTemplate(fundDTO);
                pdfBytes = pdfGenerator.generatePdfFromHtml(htmlContent);

                Path folderPathObj = Paths.get(folderPath);
                Files.createDirectories(folderPathObj);

                Path outputPathObj = folderPathObj.resolve(fileName);
                outputPath = outputPathObj.toString();

                pdfGenerator.savePdfToFile(pdfBytes, outputPath);

                billingReportGeneratorService.checkingExistingBillingReportGenerator(
                        customerCode, billingCategory, billingType, currency, billingPeriod
                );

                billingReportGenerator.setCreatedAt(dateNow);
                billingReportGenerator.setInvestmentManagementName(investmentManagementName);
                billingReportGenerator.setInvestmentManagementEmail(investmentManagementEmail);
                billingReportGenerator.setCustomerCode(customerCode);
                billingReportGenerator.setCustomerName(customerName);
                billingReportGenerator.setType(billingType);
                billingReportGenerator.setCategory(billingCategory);
                billingReportGenerator.setPeriod(billingPeriod);
                billingReportGenerator.setMonth(monthName);
                billingReportGenerator.setYear(year);
                billingReportGenerator.setCurrency(currency);
                billingReportGenerator.setFileName(fileName);
                billingReportGenerator.setFilePath(filePath);
                billingReportGenerator.setStatus(ReportGeneratorStatus.SUCCESS.getStatus());
                billingReportGenerator.setDesc("Success generate and save PDF statements");

                billingReportGeneratorList.add(billingReportGenerator);
            } catch (Exception e) {
                log.error("Error creating folder or saving PDF : " + e.getMessage(), e);
                billingReportGenerator.setCreatedAt(dateNow);
                billingReportGenerator.setInvestmentManagementName(investmentManagementName);
                billingReportGenerator.setInvestmentManagementEmail(investmentManagementEmail);
                billingReportGenerator.setCustomerCode(customerCode);
                billingReportGenerator.setCustomerName(customerName);
                billingReportGenerator.setCategory(billingCategory);
                billingReportGenerator.setType(billingType);
                billingReportGenerator.setPeriod(billingPeriod);
                billingReportGenerator.setCurrency(currency);
                billingReportGenerator.setFileName(fileName);
                billingReportGenerator.setFilePath(folderPath);
                billingReportGenerator.setStatus(ReportGeneratorStatus.FAILED.getStatus());
                billingReportGenerator.setDesc(e.getMessage());

                billingReportGeneratorList.add(billingReportGenerator);
            }
        }

        // save report generator
        List<BillingReportGenerator> billingReportGeneratorListSaved = billingReportGeneratorService.saveAll(billingReportGeneratorList);
        log.info("Save billing report generator list saved: " + billingReportGeneratorListSaved.size());
    }


    private String renderThymeleafTemplate(BillingFundDTO fundDTO) {
        Context context = new Context();

        context.setVariable(BILLING_NUMBER, fundDTO.getBillingNumber());
        context.setVariable(BILLING_PERIOD, fundDTO.getBillingPeriod());
        context.setVariable(BILLING_STATEMENT_DATE, fundDTO.getBillingStatementDate());
        context.setVariable(BILLING_PAYMENT_DUE_DATE, fundDTO.getBillingPaymentDueDate());
        context.setVariable(BILLING_CATEGORY, fundDTO.getBillingCategory());
        context.setVariable(BILLING_TYPE, fundDTO.getBillingType());
        context.setVariable(BILLING_TEMPLATE, fundDTO.getBillingTemplate());
        context.setVariable(INVESTMENT_MANAGEMENT_NAME, fundDTO.getInvestmentManagementName());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_1, fundDTO.getInvestmentManagementAddress1());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_2, fundDTO.getInvestmentManagementAddress2());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_3, fundDTO.getInvestmentManagementAddress3());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_4, fundDTO.getInvestmentManagementAddress4());
        context.setVariable(PRODUCT_NAME, fundDTO.getProductName());
        context.setVariable(ACCOUNT_NAME, fundDTO.getAccountName());
        context.setVariable(ACCOUNT_NUMBER, fundDTO.getAccountNumber());
        context.setVariable(ACCOUNT_BANK, fundDTO.getAccountBank());
        context.setVariable(CUSTOMER_FEE, fundDTO.getCustomerFee());
        context.setVariable(ACCRUAL_CUSTODIAL_FEE, fundDTO.getAccrualCustodialFee());
        context.setVariable(BI_SSSS_TRANSACTION_VALUE_FREQUENCY, fundDTO.getBis4TransactionValueFrequency());
        context.setVariable(BI_SSSS_TRANSACTION_FEE, fundDTO.getBis4TransactionFee());
        context.setVariable(BI_SSSS_TRANSACTION_AMOUNT_DUE, fundDTO.getBis4TransactionAmountDue());
        context.setVariable(SUB_TOTAL, fundDTO.getSubTotal());
        context.setVariable(VAT_FEE, fundDTO.getVatFee());
        context.setVariable(VAT_AMOUNT_DUE, fundDTO.getVatAmountDue());
        context.setVariable(KSEI_TRANSACTION_VALUE_FREQUENCY, fundDTO.getKseiTransactionValueFrequency());
        context.setVariable(KSEI_TRANSACTION_FEE, fundDTO.getKseiTransactionFee());
        context.setVariable(KSEI_TRANSACTION_AMOUNT_DUE, fundDTO.getKseiTransactionAmountDue());
        context.setVariable(TOTAL_AMOUNT_DUE, fundDTO.getTotalAmountDue());

        // tambahkan Image URL
        String imageUrlHeader = "file:///" + folderPathImage + "/logo.png";
        String imageUrlFooter = "file:///" + folderPathImage + "/footer.png";
        context.setVariable("imageUrlHeader", imageUrlHeader);
        context.setVariable("imageUrlFooter", imageUrlFooter);

        return templateEngine.process(FUND_TEMPLATE.getValue(), context);
    }

    private String generateFileName(String aid, String yearMonth) {
        return aid + "_" + yearMonth + ".pdf";
    }


    private static BillingFundDTO mapToDTO(BillingFund billingFund) {
        return BillingFundDTO.builder()
                .id(billingFund.getId())
                .createdAt(billingFund.getCreatedAt())
                .updatedAt(billingFund.getUpdatedAt())
                .billingStatus(billingFund.getBillingStatus().getStatus())
                .approvalStatus(billingFund.getApprovalStatus().getStatus())
                .customerCode(billingFund.getCustomerCode())
                .customerName(billingFund.getCustomerName())
                .month(billingFund.getMonth())
                .year(String.valueOf(billingFund.getYear()))
                .billingNumber(billingFund.getBillingNumber())
                .billingPeriod(billingFund.getBillingPeriod())
                .billingStatementDate(billingFund.getBillingStatementDate())
                .billingPaymentDueDate(billingFund.getBillingPaymentDueDate())
                .billingCategory(billingFund.getBillingCategory())
                .billingType(billingFund.getBillingType())
                .billingTemplate(billingFund.getBillingTemplate())
                .investmentManagementName(billingFund.getInvestmentManagementName())
                .investmentManagementAddress1(billingFund.getInvestmentManagementAddress1())
                .investmentManagementAddress2(billingFund.getInvestmentManagementAddress2())
                .investmentManagementAddress3(billingFund.getInvestmentManagementAddress3())
                .investmentManagementAddress4(billingFund.getInvestmentManagementAddress4())
                .investmentManagementEmail(billingFund.getInvestmentManagementEmail())
                .productName(billingFund.getAccountName())
                .accountName(billingFund.getAccountName())
                .accountNumber(billingFund.getAccountNumber())
                .currency(billingFund.getCurrency())
                .customerFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getCustomerFee()))
                .accrualCustodialFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getAccrualCustodialFee()))
                .bis4TransactionValueFrequency(String.valueOf(billingFund.getBis4TransactionValueFrequency()))
                .bis4TransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getBis4TransactionFee()))
                .bis4TransactionAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getBis4TransactionAmountDue()))
                .subTotal(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getSubTotal()))
                .vatFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getVatFee()))
                .vatAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getVatAmountDue()))
                .kseiTransactionValueFrequency(String.valueOf(billingFund.getKseiTransactionValueFrequency()))
                .kseiTransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getKseiTransactionFee()))
                .kseiTransactionAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getKseiTransactionAmountDue()))
                .totalAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getTotalAmountDue()))
                .build();
    }

    private static List<BillingFundDTO> mapToDTOList(List<BillingFund> billingFundList) {
        return billingFundList.stream()
                .map(FundGeneratePDFServiceImpl::mapToDTO)
                .collect(Collectors.toList());
    }

}
