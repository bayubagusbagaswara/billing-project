package com.services.billingservice.repository;

import com.services.billingservice.model.SfValCrowdFunding;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SfValCrowdFundingRepository extends JpaRepository<SfValCrowdFunding, Long> {

    @Query(value = "SELECT * FROM bill_sfval_crowd_funding " +
            "WHERE client_code = :clientCode", nativeQuery = true)
    List<SfValCrowdFunding> findAllByClientCode(@Param("clientCode") String clientCode);

    @Query(value = "SELECT * FROM bill_sfval_crowd_funding " +
            "WHERE client_code = :clientCode " +
            "AND month = :month " +
            "AND year = :year", nativeQuery = true)
    List<SfValCrowdFunding> findAllByClientCodeAndMonthAndYear(
            @Param("clientCode") String clientCode,
            @Param("month") String month,
            @Param("year") Integer year
    );

}
