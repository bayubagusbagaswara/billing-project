package com.services.billingservice.model;

import com.services.billingservice.enums.BillingCategory;
import com.services.billingservice.model.base.Approvable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.util.Date;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "billing_scheduler")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingScheduler extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(length = 500)
    private String className;

    @Column(length = 30)
    private String cronPattern;

    @Column
    private boolean enable = false;

}
