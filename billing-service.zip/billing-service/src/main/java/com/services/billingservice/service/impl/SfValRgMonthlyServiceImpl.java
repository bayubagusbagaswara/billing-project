package com.services.billingservice.service.impl;

import com.opencsv.exceptions.CsvException;
import com.services.billingservice.dto.rgmonthly.CreateRGMonthlyRequest;
import com.services.billingservice.model.SfValRgMonthly;
import com.services.billingservice.repository.SfValRgMonthlyRepository;
import com.services.billingservice.service.SfValRgMonthlyService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.CsvDataMapper;
import com.services.billingservice.utils.CsvReaderUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class SfValRgMonthlyServiceImpl implements SfValRgMonthlyService {

    private final SfValRgMonthlyRepository sfValRgMonthlyRepository;

    @Override
    public String readFileAndInsertToDB(String filePath) {
        log.info("Start read and insert SfVal RG Monthly to the database : {}", filePath);

        try {
            List<String[]> rows = CsvReaderUtil.readCsvFile(filePath);

            List<SfValRgMonthly> rgMonthlyList = CsvDataMapper.mapCsvSfValRgMonthly(rows);

            sfValRgMonthlyRepository.saveAll(rgMonthlyList);

            return "[SfVal RG Monthly] CSV data processed and saved successfully";
        } catch (IOException | CsvException e) {
            return "[SfVal RG Monthly] Failed to process CSV File : " + e.getMessage();
        }
    }

    @Override
    public List<SfValRgMonthly> getAll() {
        return sfValRgMonthlyRepository.findAll();
    }

    @Override
    public List<SfValRgMonthly> getAllByAid(String aid) {
        log.info("Start get all SfVal RG Monthly with Aid '{}'", aid);
        return sfValRgMonthlyRepository.findAllByAid(aid);
    }

    @Override
    public List<SfValRgMonthly> findByAidAndMonthAndYearOrderByAidAscSecurityNameAscDateAsc(String aid, String month, Integer year) {
        log.info("Start get all SfVal RG Monthly with Aid '{}' And Month '{}' And Year '{}'", aid, month, year);
        return sfValRgMonthlyRepository.findByAidAndMonthAndYearOrderByAidAscSecurityNameAscDateAsc(aid, month, year);
    }

    @Override
    public List<SfValRgMonthly> getAllByAidAndSecurityName(String aid, String securityName) {
        log.info("Start get all SfVal RG Monthly with Aid '{}' and Security Name '{}'", aid, securityName);
        return sfValRgMonthlyRepository.findAllByAidAndSecurityName(aid, securityName);
    }

    @Override
    public List<SfValRgMonthly> getAllByAidAndMonthAndYear(String aid, String monthName, int year) {
        return sfValRgMonthlyRepository.findAllByAidAndMonthAndYear(aid, monthName, year);
    }

    @Override
    public List<SfValRgMonthly> createList(List<CreateRGMonthlyRequest> requestList) {

        List<SfValRgMonthly> sfValRgMonthlyList = new ArrayList<>();

        for (CreateRGMonthlyRequest request : requestList) {

            String batch = request.getBatch();
            String date = request.getDate(); // 2023/11/01

            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
            LocalDate localDate = LocalDate.parse(date, dateTimeFormatter);
            String monthName = localDate.getMonth().getDisplayName(TextStyle.FULL, ConvertDateUtil.getLocaleEN());
            int year = localDate.getYear();

            String aid = request.getAid().isEmpty() ? "" : request.getAid();
            String securityName = request.getSecurityName().isEmpty() ? "" : request.getSecurityName();

            BigDecimal faceValue = request.getFaceValue().isEmpty() ? BigDecimal.ZERO : new BigDecimal(request.getFaceValue());
            String marketPrice = request.getMarketPrice().isEmpty() ? "" : request.getMarketPrice();
            BigDecimal marketValue = request.getMarketValue().isEmpty() ? BigDecimal.ZERO : new BigDecimal(request.getMarketValue());
            BigDecimal estimationSafekeepingFee = request.getEstimationSafekeepingFee().isEmpty() ? BigDecimal.ZERO : new BigDecimal(request.getEstimationSafekeepingFee());

            // Create object SfValRGMonthly
            SfValRgMonthly sfValRgMonthly = SfValRgMonthly.builder()
                    .batch(Integer.parseInt(batch))
                    .date(localDate)
                    .month(monthName)
                    .year(year)
                    .aid(aid)
                    .securityName(securityName)
                    .faceValue(faceValue)
                    .marketPrice(marketPrice)
                    .marketValue(marketValue)
                    .estimationSafekeepingFee(estimationSafekeepingFee)
                    .build();

            sfValRgMonthlyList.add(sfValRgMonthly);
        }
        // save all to the database
        return sfValRgMonthlyRepository.saveAll(sfValRgMonthlyList);
    }

    @Override
    public String deleteAll() {
        try {
            sfValRgMonthlyRepository.deleteAll();
            return "Successfully deleted all SfVal RG Monthly";
        } catch (Exception e) {
            log.error("Error when delete all SfVal RG Monthly : " + e.getMessage(), e);
            throw new RuntimeException("Error when delete all SfVal RG Monthly");
        }
    }
}
