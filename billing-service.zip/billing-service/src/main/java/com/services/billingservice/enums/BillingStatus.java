package com.services.billingservice.enums;

public enum BillingStatus {

    Generated("Generated"),
    Reviewed("Reviewed"),
    Approved("Approved"),
    Rejected("Rejected");

    private final String status;

    BillingStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
