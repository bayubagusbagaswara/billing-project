package com.services.billingservice.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillingTemplateDTO {

    private String id;

    private String templateName;

    private String templateType;

    private String templateCategory;

    private String desc;
}
