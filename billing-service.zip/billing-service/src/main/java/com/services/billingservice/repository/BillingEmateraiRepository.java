package com.services.billingservice.repository;

import com.services.billingservice.model.BillingEmaterai;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface BillingEmateraiRepository extends JpaRepository<BillingEmaterai, Long> {
    @Query(value = "SELECT * FROM billing_fee_schedule WHERE id = :id", nativeQuery = true)
    Optional<BillingEmaterai> findById(@Param("id") String id);

    @Query(value = "SELECT * FROM bill_billing where nominal > 5000000", nativeQuery = true)
    List<BillingEmaterai> findBycategory(@Param("category") String category);

}

