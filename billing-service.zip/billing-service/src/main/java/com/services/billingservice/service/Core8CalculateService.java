package com.services.billingservice.service;

import com.services.billingservice.dto.core.CoreCalculateRequest;

public interface Core8CalculateService {

    String calculate(CoreCalculateRequest request);
}
