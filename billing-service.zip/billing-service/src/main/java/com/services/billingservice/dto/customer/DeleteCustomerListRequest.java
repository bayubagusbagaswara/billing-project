package com.services.billingservice.dto.customer;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DeleteCustomerListRequest {

    private String approveId;
    private String approveIPAddress;

    private List<CustomerDTO> customerDTOList; // just a use id and dataChangeId


}
