package com.services.billingservice.utils;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@Slf4j
@Component
@RequiredArgsConstructor
public class PdfGenerator {

    private final SpringTemplateEngine templateEngine;


    public byte[] generatePdfFromHtml(String htmlContent) throws Exception {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            ITextRenderer renderer = new ITextRenderer();
            renderer.setDocumentFromString(htmlContent);
            renderer.layout();
            renderer.createPDF(baos, false);
            renderer.finishPDF();
            return baos.toByteArray();
        }
    }

    public void savePdfToFile(byte[] pdfBytes, String outputPath) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(new File(outputPath))) {
            fos.write(pdfBytes);
            fos.flush();
        }
    }

//    public void savePdfToFileUtil(List<BillingReportGenerator> billingReportGeneratorList, BillingReportGenerator billingReportGenerator, Instant dateNow, BillingCoreDTO billingCoreDTO, String investmentManagementName, String customerCode, String customerName, String billingCategory, String billingType, String billingPeriod, String fileName, String filePath, String folderPath, int year, String monthName) {
//        String htmlContent;
//        byte[] pdfBytes;
//        String outputPath;
//        try {
//            billingReportGenerator.setCreatedAt(dateNow);
//            billingReportGenerator.setInvestmentManagementName(investmentManagementName);
//            billingReportGenerator.setCustomerCode(customerCode);
//            billingReportGenerator.setCustomerName(customerName);
//            billingReportGenerator.setType(billingType);
//            billingReportGenerator.setCategory(billingCategory);
//            billingReportGenerator.setPeriod(billingPeriod);
//            billingReportGenerator.setMonth(monthName);
//            billingReportGenerator.setYear(year);
//            billingReportGenerator.setFileName(fileName);
//            billingReportGenerator.setFilePath(filePath);
//            billingReportGenerator.setStatus(ReportGeneratorStatus.SUCCESS.getStatus());
//            billingReportGenerator.setDesc("Success generate and save PDF statements");
//
//            billingReportGeneratorList.add(billingReportGenerator);
//
//            htmlContent = renderThymeleafTemplate(billingCoreDTO);
//            pdfBytes = generatePdfFromHtml(htmlContent);
//
//            Path folderPathObj = Paths.get(folderPath);
//            Files.createDirectories(folderPathObj);
//
//            Path outputPathObj = folderPathObj.resolve(fileName);
//            outputPath = outputPathObj.toString();
//
//            savePdfToFile(pdfBytes, outputPath);
//        } catch (Exception e) {
//            log.error("Error creating folder or saving PDF : " + e.getMessage(), e);
//            billingReportGenerator.setCreatedAt(dateNow);
//            billingReportGenerator.setInvestmentManagementName(investmentManagementName);
//            billingReportGenerator.setCustomerCode(customerCode);
//            billingReportGenerator.setCustomerName(customerName);
//            billingReportGenerator.setCategory(billingCategory);
//            billingReportGenerator.setType(billingType);
//            billingReportGenerator.setPeriod(billingPeriod);
//            billingReportGenerator.setFileName(fileName);
//            billingReportGenerator.setFilePath(folderPath);
//            billingReportGenerator.setStatus(ReportGeneratorStatus.FAILED.getStatus());
//            billingReportGenerator.setDesc(e.getMessage());
//
//            billingReportGeneratorList.add(billingReportGenerator);
//
//            // throw new GeneratePDFBillingException("Error creating folder or saving PDF : " + e.getMessage());
//        }
//    }

}
