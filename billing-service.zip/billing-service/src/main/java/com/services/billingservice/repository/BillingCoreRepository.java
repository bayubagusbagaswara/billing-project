package com.services.billingservice.repository;

import com.services.billingservice.dto.core.BillingCoreListProcess;
import com.services.billingservice.model.BillingCore;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BillingCoreRepository extends JpaRepository<BillingCore, Long> {

    //TODO for payment
    @Query(value = "SELECT * FROM billing_core " +
            "WHERE month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus", nativeQuery = true)
    List<BillingCore> findAllByMonthAndYearAndApprovalStatus(
            @Param("month") String month,
            @Param("year") int year,
            @Param("approvalStatus") String approvalStatus
    );

    @Query(value = "SELECT * FROM billing_core " +
            "WHERE customer_code=:custCode AND month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus", nativeQuery = true)
    BillingCore findByCustomerCodeAndMonthAndYearAndApprovalStatus(
            @Param("month") String month,
            @Param("year") int year,
            @Param("custCode") String custCode,
            @Param("approvalStatus") String approvalStatus
    );

    //TODO for payment
    @Query(value = "SELECT * FROM billing_core " +
            "WHERE bill_type = :billingType " +
            "AND month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus", nativeQuery = true)
    List<BillingCore> findAllByBillingTypeAndMonthAndYearAndApprovalStatus(
            @Param("billingType") String billingType,
            @Param("month") String month,
            @Param("year") int year,
            @Param("approvalStatus") String approvalStatus
    );

    @Query(value = "SELECT * FROM billing_core " +
            "WHERE bill_category = :billingCategory " +
            "AND bill_type = :billingType " +
            "AND month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus", nativeQuery = true)
    List<BillingCore> findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndApprovalStatus(
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("month") String month,
            @Param("year") int year,
            @Param("approvalStatus") String approvalStatus
    );

    @Query(value = "SELECT * FROM billing_core " +
            "WHERE bill_category = :billingCategory " +
            "AND bill_type = :billingType " +
            "AND month = :month " +
            "AND year = :year", nativeQuery = true)
    List<BillingCore> findAllByBillingCategoryAndBillingTypeAndMonthAndYear(
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("month") String month,
            @Param("year") Integer year
    );

    @Query(value = "SELECT * FROM billing_core " +
            "WHERE customer_code = :customerCode " +
            "AND bill_category = :billingCategory " +
            "AND bill_type = :billingType " +
            "AND month = :month " +
            "AND year = :year", nativeQuery = true)
    List<BillingCore> findAllByCustomerCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
            @Param("customerCode") String customerCode,
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("month") String monthName,
            @Param("year") int year);

    @Query(value = "SELECT DISTINCT NEW com.services.billingservice.dto.core.BillingCoreListProcess " +
            "(f.month, f.year, MAX(f.createdAt), f.approvalStatus, f.billingStatus) " +
            "FROM BillingCore f " +
            "GROUP BY f.month, f.year, f.approvalStatus, f.billingStatus " +
            "ORDER BY f.year DESC, month DESC")
    List<BillingCoreListProcess> getAllListProcess();

    @Query(value = "SELECT DISTINCT NEW com.services.billingservice.dto.core.BillingCoreListProcess " +
            "(f.month, f.year, MAX(f.createdAt), f.approvalStatus, f.billingStatus) " +
            "FROM BillingCore f " +
            "WHERE upper(f.approvalStatus) = 'PENDING' " +
            "   AND upper(f.billingStatus) = 'REVIEWED' " +
            "GROUP BY f.month, f.year, f.approvalStatus, f.billingStatus " +
            "ORDER BY f.year DESC, month DESC")
    List<BillingCoreListProcess> getAllListPendingApprove();

    List<BillingCore> findByMonthAndYear(String month, Integer year);
}
