package com.services.billingservice.utils;

import com.services.billingservice.enums.BillingCategory;
import com.services.billingservice.enums.BillingTemplate;
import com.services.billingservice.enums.BillingType;
import com.services.billingservice.enums.Currency;
import lombok.experimental.UtilityClass;

import java.util.Arrays;

@UtilityClass
public class EnumValidator {

    private static <T extends Enum<T>> boolean validateEnum(Class<T> enumClass, String value) {
        return Arrays.stream(enumClass.getEnumConstants())
                .anyMatch(enumConstant -> enumConstant.name().equalsIgnoreCase(value));
    }

    public static boolean validateEnumBillingCategory(String billingCategory) {
        return validateEnum(BillingCategory.class, billingCategory);
    }

    public static boolean validateEnumBillingType(String billingType) {
        return validateEnum(BillingType.class, billingType);
    }

    public static boolean validateEnumBillingTemplate(String billingTemplate) {
        return validateEnum(BillingTemplate.class, billingTemplate);
    }

    public static boolean validateEnumCurrency(String currency) {
        return validateEnum(Currency.class, currency);
    }

}
