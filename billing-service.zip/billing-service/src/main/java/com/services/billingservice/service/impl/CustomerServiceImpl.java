package com.services.billingservice.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.ErrorMessageDTO;
import com.services.billingservice.dto.customer.*;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.exception.DataChangeException;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingMI;
import com.services.billingservice.repository.BillingCustomerRepository;
import com.services.billingservice.service.BillingDataChangeService;
import com.services.billingservice.service.BillingMIService;
import com.services.billingservice.service.BillingSellingAgentDataService;
import com.services.billingservice.service.CustomerService;
import com.services.billingservice.utils.BeanUtil;
import com.services.billingservice.utils.EnumValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class CustomerServiceImpl implements CustomerService {

    private final BillingCustomerRepository customerRepository;
    private final BillingDataChangeService dataChangeService;
    private final BillingMIService investmentManagementService;
    private final BillingSellingAgentDataService sellingAgentDataService;
    private final Validator validator;
    private final ObjectMapper objectMapper;

    private static final String ID_NOT_FOUND = "Billing Customer not found with id: ";
    private static final String CODE_NOT_FOUND = "Billing Customer not found with code: ";

    @Override
    public boolean isCodeAlreadyExists(String code) {
        return customerRepository.existsByCustomerCode(code);
    }

    @Override
    public CreateCustomerListResponse createSingleData(CreateCustomerRequest request, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create single data billing customer with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        CustomerDTO customerDTO = CustomerDTO.builder()
                .customerCode(request.getCustomerCode())
                .customerName(request.getCustomerName())
                .investmentManagementCode(request.getMiCode())
                .billingCategory(request.getBillingCategory())
                .billingType(request.getBillingType())
                .billingTemplate(request.getBillingTemplate())
                .sellingAgentCode(request.getSellingAgentCode())
                .currency(request.getCurrency())
                .build();
        try {
            List<String> validationErrors = new ArrayList<>();
            validateCustomerCodeAlreadyExists(customerDTO.getCustomerCode(), validationErrors);
            dataChangeDTO.setInputerId(request.getInputId());
            dataChangeDTO.setInputerIPAddress(request.getInputIPAddress());
            dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(customerDTO));
            if (validationErrors.isEmpty()) {

                dataChangeService.createChangeActionADD(dataChangeDTO, BillingCustomer.class);
                totalDataSuccess++;
            } else {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(customerDTO.getCustomerCode(), validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            }
        } catch (JsonProcessingException e) {
            handleJsonProcessingException(e);
        } catch (Exception e) {
            handleGeneralError(e);
        }
        return new CreateCustomerListResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public CreateCustomerListResponse createMultipleData(CreateCustomerListRequest request, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create multiple data billing customer with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (CustomerDTO customerDTO : request.getCustomerDTOList()) {
            try {
                List<String> validationErrors = new ArrayList<>();
                validateCustomerCodeAlreadyExists(customerDTO.getCustomerCode(), validationErrors);
                dataChangeDTO.setInputerId(request.getInputId());
                dataChangeDTO.setInputerIPAddress(request.getInputIPAddress());
                dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(customerDTO));

                if (validationErrors.isEmpty()) {
                    dataChangeService.createChangeActionADD(dataChangeDTO, BillingCustomer.class);
                    totalDataSuccess++;
                } else {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(customerDTO.getCustomerCode(), validationErrors);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                }
            } catch (JsonProcessingException e) {
                handleJsonProcessingException(e);
            } catch (Exception e) {
                handleGeneralError(e);
            }
        }
        return new CreateCustomerListResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public CreateCustomerListResponse createMultipleApprove(CreateCustomerListRequest request) {
        log.info("Approve multiple for create billing customer with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        boolean allIdsExists = validateDataChangeIds(request.getCustomerDTOList());
        if (!allIdsExists) {
            log.error("Not all Data Change ids exist in the database");
            throw new DataChangeException("Not all Data Change ids exists in the database");
        }

        // Process each CustomerDTO
        for (CustomerDTO customerDTO : request.getCustomerDTOList()) {
            try {
                List<String> validationErrors = new ArrayList<>();

                // Validate CustomerDTO using validator
                Errors errors = validateCustomerUsingValidator(customerDTO);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                // Additional custom validations
                validateBillingEnums(customerDTO, validationErrors);
                validateCustomerCodeAlreadyExists(customerDTO.getCustomerCode(), validationErrors);
                validateSellingAgentCodeAlreadyExists(customerDTO.getSellingAgentCode(), validationErrors);

                // Retrieve and set InvestmentManagement
                InvestmentManagementDTO investmentManagement = investmentManagementService.getByCode(customerDTO.getInvestmentManagementCode());
                customerDTO.setInvestmentManagementName(investmentManagement.getName());

                // Retrieve and set Billing DataChange
                BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(customerDTO.getDataChangeId());

                if (!validationErrors.isEmpty()) {
                    dataChangeDTO.setApproverId(request.getApproveId());
                    dataChangeDTO.setApproverIPAddress(request.getApproveIPAddress());
                    dataChangeDTO.setApproveDate(new Date());
                    dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(customerDTO));

                    dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                    totalDataFailed++;
                } else {
                    dataChangeDTO.setApproverId(request.getApproveId());
                    dataChangeDTO.setApproverIPAddress(request.getApproveIPAddress());
                    dataChangeDTO.setApproveDate(new Date());
                    dataChangeDTO.setDescription("Successfully approve data for create billing customer entity");

                    // Create and save Customer entity
                    BillingCustomer billingCustomer = createEntity(customerDTO, dataChangeDTO);

                    // save to update
                    BillingCustomer billingCustomerSaved = customerRepository.save(billingCustomer);
                    dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(billingCustomerSaved)); // data after save

                    // send to service data change APPROVED
                    dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                    totalDataSuccess++;
                }
            } catch (DataNotFoundException e) {
                handleDataNotFoundException(customerDTO, errorMessageDTOList);
                totalDataFailed++;
            } catch (JsonProcessingException e) {
                handleJsonProcessingException(e);
                totalDataFailed++;
            } catch (Exception e) {
                handleGeneralError(e);
                totalDataFailed++;
            }
        }
        // Return response with total success, total failed, and error messages
        return new CreateCustomerListResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public UpdateCustomerListResponse updateSingleData(UpdateCustomerRequest request, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update single data billing customer with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        CustomerDTO customerDTO = CustomerDTO.builder()
                .id(request.getId())
                .investmentManagementCode(request.getInvestmentManagementCode())
                .billingCategory(request.getBillingCategory())
                .billingType(request.getBillingType())
                .billingTemplate(request.getBillingTemplate())
                .build();

        try {
            // TODO: hanya dilakukan cek apakah datanya ada atau tidak di database
            BillingCustomer billingCustomer = customerRepository.findById(customerDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException("Billing Customer not found with id"));

            dataChangeDTO.setInputerId(request.getInputId());
            dataChangeDTO.setInputerIPAddress(request.getInputIPAddress());
            dataChangeDTO.setJsonDataBefore(objectMapper.writeValueAsString(billingCustomer));
            dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(customerDTO));

            dataChangeService.createChangeActionEDIT(dataChangeDTO, BillingCustomer.class);
            totalDataSuccess++;

        } catch (DataNotFoundException e) {
            handleDataNotFoundException(customerDTO, errorMessageDTOList);
            totalDataFailed++;
        } catch (JsonProcessingException e) {
            handleJsonProcessingException(e);
        } catch (Exception e) {
            handleGeneralError(e);
        }
        return new UpdateCustomerListResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public UpdateCustomerListResponse updateMultipleData(UpdateCustomerListRequest request, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update multiple billing customer data with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (CustomerDTO customerDTO : request.getCustomerDTOList()) {
            try {
                BillingCustomer billingCustomer = customerRepository.findByCode(customerDTO.getCustomerCode())
                        .orElseThrow(() -> new DataNotFoundException(CODE_NOT_FOUND + customerDTO.getCustomerCode()));

                dataChangeDTO.setInputerId(request.getInputId());
                dataChangeDTO.setInputerIPAddress(request.getInputIPAddress());
                dataChangeDTO.setJsonDataBefore(objectMapper.writeValueAsString(billingCustomer));
                dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(customerDTO));

                dataChangeService.createChangeActionEDIT(dataChangeDTO, BillingCustomer.class);
                totalDataSuccess++;
            } catch (DataNotFoundException e) {
                log.error("Customer not found with code: {}", customerDTO.getCustomerCode());
                handleDataNotFoundException(customerDTO, errorMessageDTOList);
                totalDataFailed++;
            } catch (JsonProcessingException e) {
                handleJsonProcessingException(e);
            } catch (Exception e) {
                handleGeneralError(e);
            }
        }
        return new UpdateCustomerListResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public UpdateCustomerListResponse updateMultipleApprove(UpdateCustomerListRequest request) {
        // karena pada saat Approve, tidak ada proses menampilkan popup gagal, tapi ketika ada gagal maka disimpan ke database
        log.info("Approve multiple for update billing customer with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        boolean allIdsExists = validateDataChangeIds(request.getCustomerDTOList());
        if (!allIdsExists) {
            log.error("Not all Data Change ids exist in the database");
            throw new DataChangeException("Not all Data Change ids exists in the database");
        }

        for (CustomerDTO customerDTO : request.getCustomerDTOList()) {
            try {
                // TODO: pada proses ini tidak muncul pop up error. Ketika terjadi error, maka akan dimasukann kedalam data change
                List<String> validationErrors = new ArrayList<>();

                // 1. Validasi data Customer DTO (not empty, not null, not blank, etc)
                Errors errors = validateCustomerUsingValidator(customerDTO);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                // 2. Validasi data enum
                validateBillingEnums(customerDTO, validationErrors);
                validateSellingAgentCodeAlreadyExists(customerDTO.getSellingAgentCode(), validationErrors);

                // 3. Validasi MI Code is existing (otomatis jika dia tidak ada, maka akan lempar data not found)
                InvestmentManagementDTO investmentManagement = investmentManagementService.getByCode(customerDTO.getInvestmentManagementCode());
                customerDTO.setInvestmentManagementName(investmentManagement.getName());

                // 4. Get customer by code
                BillingCustomer billingCustomer = customerRepository.findByCode(customerDTO.getCustomerCode()).orElseThrow(() -> new DataNotFoundException("Billing Customer not found with code: " + customerDTO.getCustomerCode()));

                // 5. Get data change by id
                // Retrieve and set Billing DataChange
                BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(customerDTO.getDataChangeId());
                dataChangeDTO.setApproverId(request.getApproveId());
                dataChangeDTO.setApproveDate(new Date());
                dataChangeDTO.setApproverIPAddress(request.getApproveIPAddress());

                // 6. do update billingCustomer (save to entity) and update data change
                if (!validationErrors.isEmpty()) {
                    dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(customerDTO));

                    dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                    totalDataFailed++;
                } else {
                    dataChangeDTO.setDescription("Successfully approve data for create billing customer entity");

                    // TODO: Do Update
                    BeanUtil.copyNotNullProperties(customerDTO, billingCustomer); // pastikan yg lolos adalah data yang bukan null
                    BillingCustomer billingCustomerSaved = customerRepository.save(billingCustomer);

                    dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(billingCustomerSaved)); // data after save

                    dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                    totalDataSuccess++;
                }
            } catch (JsonProcessingException e) {
                handleJsonProcessingException(e);
            } catch (DataNotFoundException e) {
                handleDataNotFoundException(customerDTO, errorMessageDTOList);
                totalDataFailed++;
            } catch (Exception e) {
                handleGeneralError(e);
            }
        }
        return new UpdateCustomerListResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public DeleteCustomerListResponse deleteSingleData(DeleteCustomerRequest request, BillingDataChangeDTO dataChangeDTO) {
        // ketika terjadi error exception akan di bikin format seperti totalDataSuccess, totalDataFailed, description
        log.info("Delete single data billing customer with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        CustomerDTO customerDTO = CustomerDTO.builder()
                .id(request.getId())
                .build();

        try {
            // TODO: cek id apakah ada atau tidak, jika tidak maka lempar error not found
            // nanti errornya akan dimasukkan ke dalam description
            Long id = request.getId();
            BillingCustomer billingCustomer = customerRepository.findById(id)
                    .orElseThrow(() -> new DataNotFoundException("Billing Customer not found with id: " + id));

            dataChangeDTO.setInputerId(request.getInputId());
            dataChangeDTO.setInputerIPAddress(request.getInputIPAddress());
            dataChangeDTO.setJsonDataBefore(objectMapper.writeValueAsString(billingCustomer));
            dataChangeDTO.setJsonDataAfter("");
            dataChangeDTO.setEntityId(billingCustomer.getId().toString());

            dataChangeService.createChangeActionDELETE(dataChangeDTO, BillingCustomer.class);
            totalDataSuccess++;
        } catch (DataNotFoundException e) {
             handleDataNotFoundException(customerDTO, errorMessageDTOList);
             totalDataFailed++;
        } catch (JsonProcessingException e) {
            handleJsonProcessingException(e);
        } catch (Exception e) {
            handleGeneralError(e);
        }
        return new DeleteCustomerListResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public DeleteCustomerListResponse deleteMultipleApprove(DeleteCustomerListRequest request) {
        log.info("Approve multiple for delete billing customer with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        boolean allIdsExists = validateDataChangeIds(request.getCustomerDTOList());
        if(!allIdsExists) {
            log.error("Not all Data Change ids exist in the database");
            throw new DataChangeException("Not all Data Change ids exists in the database");
        }

        for (CustomerDTO customerDTO : request.getCustomerDTOList()) {
            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(customerDTO.getDataChangeId());
            try {
                BillingCustomer billingCustomer = customerRepository.findById(customerDTO.getId())
                        .orElseThrow(() -> new DataNotFoundException("Billing Customer not found with id: " + customerDTO.getId()));

                dataChangeDTO.setApproverId(request.getApproveId());
                dataChangeDTO.setApproverIPAddress(request.getApproveIPAddress());
                dataChangeDTO.setApproveDate(new Date());
                dataChangeDTO.setJsonDataBefore(objectMapper.writeValueAsString(billingCustomer));

                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            } catch (DataNotFoundException e) {
                handleDataNotFoundException(customerDTO, errorMessageDTOList);
                dataChangeDTO.setApproverId(request.getApproveId());
                dataChangeDTO.setApproverIPAddress(request.getApproveIPAddress());
                dataChangeDTO.setApproveDate(new Date());

                List<String> validationErrors = new ArrayList<>();
                validationErrors.add("Billing customer not found with id: " + customerDTO.getId());

                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } catch (Exception e) {
                handleGeneralError(e);
            }
        }
        return new DeleteCustomerListResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    private void validateCustomerCodeAlreadyExists(String customerCode, List<String> validationErrors) {
        if (isCodeAlreadyExists(customerCode)) {
            validationErrors.add("Billing Customer already taken with customer code: " + customerCode);
        }
    }

    private void validateSellingAgentCodeAlreadyExists(String sellingAgentCode, List<String> validationErrors) {
        boolean codeAlreadyExists = sellingAgentDataService.isCodeAlreadyExists(sellingAgentCode);
        if (!codeAlreadyExists) {
            validationErrors.add("Selling Agent not found with code: " + sellingAgentCode);
        }
    }

    public Errors validateCustomerUsingValidator(CustomerDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "customerDTO");
        validator.validate(dto, errors);
        return errors;
    }

    private void handleDataChangeException(DataChangeException e) {
        log.error("Data Change exception occurred: {}", e.getMessage());
        throw new DataChangeException("Data Change exception occurred: " + e.getMessage());
    }

    private void handleJsonProcessingException(JsonProcessingException e) {
        log.error("Error processing JSON during data change logging: {}", e.getMessage(), e);
        throw new DataChangeException("Error processing JSON during data change logging", e);
    }

    private void handleGeneralError(Exception e) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        throw new DataChangeException("An unexpected error occurred: " + e.getMessage());
    }

    private void validateBillingEnums(CustomerDTO customerDTO, List<String> validationErrors) {
        if (!EnumValidator.validateEnumBillingCategory(customerDTO.getBillingCategory())) {
            validationErrors.add("Billing Category enum not found with value: " + customerDTO.getBillingCategory());
        }
        if (!EnumValidator.validateEnumBillingType(customerDTO.getBillingType())) {
            validationErrors.add("Billing Type enum not found with value: " + customerDTO.getBillingType());
        }
        if (!EnumValidator.validateEnumBillingTemplate(customerDTO.getBillingTemplate())) {
            validationErrors.add("Billing Template enum not found with value '" + customerDTO.getBillingTemplate());
        }
    }

    private void handleDataNotFoundException(CustomerDTO customerDTO, List<ErrorMessageDTO> errorMessageList) {
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add("Investment Management not found with code: " + (customerDTO != null ? customerDTO.getInvestmentManagementCode() : "unknown"));
        errorMessageList.add(new ErrorMessageDTO(customerDTO != null ? customerDTO.getCustomerCode() : "unknown", validationErrors));
    }

    private boolean validateDataChangeIds(List<CustomerDTO> customerDTOList) {
        List<Long> idDataChangeList = customerDTOList.stream()
                .map(CustomerDTO::getDataChangeId)
                .collect(Collectors.toList());
        return dataChangeService.areAllIdsExistInDatabase(idDataChangeList);
    }

    private static BillingCustomer createEntity(CustomerDTO customerDTO, BillingDataChangeDTO dataChangeDTO) {
        return BillingCustomer.builder()
                .approvalStatus(dataChangeDTO.getApprovalStatus())
                .approveDate(dataChangeDTO.getApproveDate())
                .customerCode(customerDTO.getCustomerCode())
                .customerName(customerDTO.getCustomerName())
                .customerSafekeepingFee(customerDTO.getCustomerSafekeepingFee())
                .customerMinimumFee(customerDTO.getCustomerMinimumFee())
                .billingCategory(customerDTO.getBillingCategory())
                .billingType(customerDTO.getBillingType())
                .billingTemplate(customerDTO.getBillingTemplate())
                .currency(customerDTO.getCurrency())
                .sellingAgent(customerDTO.getSellingAgentCode())
                .build();
    }

    private void updateCustomer(BillingCustomer customerExisting, CustomerDTO customerDto) {
        if (!customerDto.getCustomerName().isEmpty()) {
            customerExisting.setCustomerName(customerDto.getCustomerName());
        }

        if (customerDto.getCustomerMinimumFee() != null) {
            customerExisting.setCustomerMinimumFee(customerDto.getCustomerMinimumFee());
        }

        // etc...
    }
}
