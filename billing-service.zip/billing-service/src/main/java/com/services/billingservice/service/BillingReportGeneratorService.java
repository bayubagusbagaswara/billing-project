package com.services.billingservice.service;

import com.services.billingservice.dto.BillingReportGeneratorDTO;
import com.services.billingservice.model.BillingReportGenerator;

import java.util.List;

public interface BillingReportGeneratorService {

    BillingReportGeneratorDTO getById(String id);

    List<BillingReportGeneratorDTO> getAll();

    List<BillingReportGenerator> saveAll(List<BillingReportGenerator> billingReportGeneratorList);

    String deleteAll();

    List<BillingReportGeneratorDTO> getAllByPeriod(String period);

    void checkingExistingBillingReportGenerator(
            String customerCode, String category, String type,
            String currency, String period);
}
