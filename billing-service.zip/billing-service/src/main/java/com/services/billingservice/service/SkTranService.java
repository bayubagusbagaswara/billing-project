package com.services.billingservice.service;

import com.opencsv.exceptions.CsvException;
import com.services.billingservice.model.SkTransaction;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

public interface SkTranService {

    String readFileAndInsertToDB(String filePath) throws IOException, CsvException;

    List<SkTransaction> getAll();

    List<SkTransaction> getAllByPortfolioCode(String portfolioCode);

    List<SkTransaction> getAllByPortfolioCodeAndSystem(String portfolioCode, String system);

    List<SkTransaction> getAllByAidAndMonthAndYear(String aid, String month, Integer year);

    List<SkTransaction> getAllRetailByAidAndPeriod(String aid, LocalDate date);

    String deleteAll();

    int[] filterTransactionsType(List<SkTransaction> transactionList);
}
