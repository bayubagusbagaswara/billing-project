package com.services.billingservice.service.impl;

import com.services.billingservice.dto.BillingMIDTO;
import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.customer.BillingCustomerDTO;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.SfValRgDaily;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.BillingTemplate.CORE_TEMPLATE_3;
import static com.services.billingservice.enums.Currency.IDR;
import static com.services.billingservice.enums.FeeParameter.TRANSACTION_HANDLING_IDR;
import static com.services.billingservice.enums.FeeParameter.VAT;

@Slf4j
@Service
@RequiredArgsConstructor
public class Core1CalculateServiceImpl implements Core1CalculateService {

    private final BillingCustomerService billingCustomerService;
    private final BillingFeeParamService feeParamService;
    private final SkTranService skTranService;
    private final SfValRgDailyService sfValRgDailyService;
    private final BillingCoreRepository billingCoreRepository;
    private final BillingNumberService billingNumberService;
    private final BillingCoreGeneralService billingCoreGeneralService;
    private final BillingMIService billingMIService;

    @Override
    public String calculate(CoreCalculateRequest request) {
        log.info("Start calculate Billing Core type 1 with request : {}", request);
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());
            String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            // Initialization variable
            int transactionHandlingValueFrequency;
            BigDecimal transactionHandlingAmountDue;
            BigDecimal safekeepingValueFrequency;
            BigDecimal safekeepingAmountDue;
            BigDecimal subTotal;
            BigDecimal vatAmountDue;
            BigDecimal totalAmountDue;
            List<BillingCore> billingCoreList = new ArrayList<>();
            Instant dateNow = Instant.now();

            // Get data Fee Parameter
            List<String> feeParamList = new ArrayList<>();
            feeParamList.add(TRANSACTION_HANDLING_IDR.getValue());
            feeParamList.add(VAT.getValue());

            Map<String, BigDecimal> feeParamMap = feeParamService.getValueByNameList(feeParamList);
            BigDecimal transactionHandlingFee = feeParamMap.get(TRANSACTION_HANDLING_IDR.getValue());
            BigDecimal vatFee = feeParamMap.get(VAT.getValue());

            List<BillingCustomerDTO> billingCustomerDTOList = billingCustomerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            // Process calculate Billing
            for (BillingCustomerDTO billingCustomerDTO : billingCustomerDTOList) {
                String aid = billingCustomerDTO.getCustomerCode();
                BigDecimal customerMinimumFee = billingCustomerDTO.getCustomerMinimumFee();
                BigDecimal customerSafekeepingFee = billingCustomerDTO.getCustomerSafekeepingFee();
                String billingCategory = billingCustomerDTO.getBillingCategory();
                String billingType = billingCustomerDTO.getBillingType();
                String billingTemplate = billingCustomerDTO.getBillingTemplate();
                String formatBillingTemplate = billingCategory + "_" + billingTemplate;
                String miCode = billingCustomerDTO.getMiCode();

                // call MI Service by miCode
                InvestmentManagementDTO billingMIDTO = billingMIService.getByCode(miCode);

                if (CORE_TEMPLATE_3.getValue().equalsIgnoreCase(formatBillingTemplate)) {
                    List<SkTransaction> skTransactionList = skTranService.getAllByAidAndMonthAndYear(aid, monthName, year);

                    List<SfValRgDaily> sfValRgDailyList = sfValRgDailyService.getAllByAidAndMonthAndYear(aid, monthName, year);

                    transactionHandlingValueFrequency = calculateTransactionHandlingValueFrequency(aid, skTransactionList);

                    transactionHandlingAmountDue = calculateTransactionHandlingAmountDue(aid, transactionHandlingFee, transactionHandlingValueFrequency);

                    safekeepingValueFrequency = calculateSafekeepingValueFrequency(aid, sfValRgDailyList);

                    safekeepingAmountDue = calculateSafekeepingAmountDue(aid, sfValRgDailyList);

                    subTotal = calculateSubTotalAmountDue(aid, transactionHandlingAmountDue, safekeepingAmountDue);

                    vatAmountDue = calculateVATAmountDue(aid, subTotal, vatFee);

                    totalAmountDue = calculateTotalAmountDue(aid, subTotal, vatAmountDue);

                    billingCoreGeneralService.checkingExistingBillingCore(monthName, year, aid, billingCategory, billingType);

                    BillingCore billingCore = BillingCore.builder()
                            .createdAt(dateNow)
                            .updatedAt(dateNow)
                            .approvalStatus(ApprovalStatus.Pending)
                            .billingStatus(BillingStatus.Generated)
                            .customerCode(billingCustomerDTO.getCustomerCode())
                            .customerName(billingCustomerDTO.getCustomerName())
                            .month(monthName)
                            .year(year)
                            .billingPeriod(monthName + " " + year)
                            .billingStatementDate(ConvertDateUtil.convertInstantToString(dateNow))
                            .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(dateNow))
                            .billingCategory(billingCustomerDTO.getBillingCategory())
                            .billingType(billingCustomerDTO.getBillingType())
                            .billingTemplate(billingCustomerDTO.getBillingTemplate())
                            .investmentManagementName(billingMIDTO.getName())
                            .investmentManagementAddress1(billingMIDTO.getAddress1())
                            .investmentManagementAddress2(billingMIDTO.getAddress2())
                            .investmentManagementAddress3(billingMIDTO.getAddress3())
                            .investmentManagementAddress4(billingMIDTO.getAddress4())
                            .investmentManagementEmail(billingMIDTO.getEmail())

                            .customerMinimumFee(customerMinimumFee)
                            .customerSafekeepingFee(customerSafekeepingFee)

                            .accountName(billingCustomerDTO.getAccountName())
                            .accountNumber(billingCustomerDTO.getAccount())
                            .accountBank(billingCustomerDTO.getAccountBank())
                            .costCenter(billingCustomerDTO.getCostCenter())
                            .currency(IDR.getValue())

                            .transactionHandlingValueFrequency(transactionHandlingValueFrequency)
                            .transactionHandlingFee(transactionHandlingFee)
                            .transactionHandlingAmountDue(transactionHandlingAmountDue)
                            .safekeepingValueFrequency(safekeepingValueFrequency)
                            .safekeepingFee(customerSafekeepingFee)
                            .safekeepingAmountDue(safekeepingAmountDue)
                            .subTotal(subTotal)
                            .vatFee(vatFee)
                            .vatAmountDue(vatAmountDue)
                            .totalAmountDue(totalAmountDue)
                            .build();

                    billingCoreList.add(billingCore);
                } else {
                    log.info("Is not template");
                }
            }

            int billingCoreListSize = billingCoreList.size();
            List<String> numberList = billingNumberService.generateNumberList(billingCoreListSize, monthName, year);

            for (int i = 0; i < billingCoreListSize; i++) {
                BillingCore billingCore = billingCoreList.get(i);
                String billingNumber = numberList.get(i);
                billingCore.setBillingNumber(billingNumber);
            }

            List<BillingCore> billingCoreListSaved = billingCoreRepository.saveAll(billingCoreList);
            billingNumberService.saveAll(numberList);

            log.info("Finished calculate Billing Core type 1 with month '{}' and year '{}'", monthName, year);
            return "Successfully calculated Billing Core type 1 with a total : " + billingCoreListSaved.size();
        } catch (Exception e) {
            log.error("Error when calculate Billing Core type 1 : " + e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Core type 1 : " + e.getMessage());
        }
    }

    private static int calculateTransactionHandlingValueFrequency(String aid, List<SkTransaction> skTransactionList) {
        int totalTransactionHandling = skTransactionList.size();
        log.info("[Core Type 1] Total transaction handling Aid '{}' is '{}'", aid, totalTransactionHandling);
        return totalTransactionHandling;
    }

    private static BigDecimal calculateTransactionHandlingAmountDue(String aid, BigDecimal transactionHandlingFee, int transactionHandlingValueFrequency) {
        BigDecimal transactionHandlingAmountDue = transactionHandlingFee.multiply(new BigDecimal(transactionHandlingValueFrequency).setScale(0, RoundingMode.HALF_UP));
        log.info("[Core Type 1] Transaction handling amount due Aid '{}' is '{}'", aid, transactionHandlingAmountDue);
        return transactionHandlingAmountDue;
    }

    private static BigDecimal calculateSafekeepingValueFrequency(String aid, List<SfValRgDaily> sfValRgDailyList) {
        List<SfValRgDaily> latestEntries = sfValRgDailyList.stream()
                .filter(entry -> entry.getDate().equals(sfValRgDailyList.stream()
                        .map(SfValRgDaily::getDate)
                        .max(Comparator.naturalOrder())
                        .orElse(null)))
                .collect(Collectors.toList());

        for (SfValRgDaily latestEntry : latestEntries) {
            log.info("Date '{}', Security Name '{}'", latestEntry.getDate(), latestEntry.getSecurityName());
        }


        BigDecimal safekeepingValueFrequency = latestEntries.stream()
                .map(SfValRgDaily::getMarketValue)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 1] Safekeeping value frequency Aid '{}' is '{}'", aid, safekeepingValueFrequency);
        return safekeepingValueFrequency;
    }

    private static BigDecimal calculateSafekeepingAmountDue(String aid, List<SfValRgDaily> sfValRgDailyList) {
        BigDecimal safekeepingAmountDue = sfValRgDailyList.stream()
                .map(SfValRgDaily::getEstimationSafekeepingFee)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 1] Safekeeping amount due Aid '{}' is '{}'", aid, safekeepingAmountDue);
        return safekeepingAmountDue;
    }

    private static BigDecimal calculateSubTotalAmountDue(String aid, BigDecimal transactionHandlingAmountDue, BigDecimal safekeepingAmountDue) {
        BigDecimal subTotalAmountDue = transactionHandlingAmountDue.add(safekeepingAmountDue).setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 1] Sub total amount due Aid '{}' is '{}'", aid, subTotalAmountDue);
        return subTotalAmountDue;
    }

    private static BigDecimal calculateVATAmountDue(String aid, BigDecimal subTotalAmountDue, BigDecimal vatFee) {
        BigDecimal vatAmountDue = subTotalAmountDue
                .multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 1] VAT amount due Aid '{}' is '{}'", aid, vatAmountDue);
        return vatAmountDue;
    }

    private static BigDecimal calculateTotalAmountDue(String aid, BigDecimal subTotalAmountDue, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDue = subTotalAmountDue.add(vatAmountDue).setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 1] Total amount due Aid '{}' is '{}'", aid, totalAmountDue);
        return totalAmountDue;
    }

}
