package com.services.billingservice.service;

import com.services.billingservice.dto.customer.*;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;

import java.util.List;

public interface BillingCustomerService {

    // Create as single or upload list data
    BillingCustomerDTO createBillingCustomer(CreateCustomerRequest request);
    UploadBillingCustomerListResponse uploadBillingCustomerList(UploadBillingCustomerRequest request);
    UploadBillingCustomerListResponse uploadBillingCustomerListApprove(UploadBillingCustomerRequest request);

    // Update as single data (by code and by id)
    BillingCustomerDTO updateByCustomerCode(String customerCode, CreateCustomerRequest request);
    BillingCustomerDTO updateById(String id, CreateCustomerRequest request);

    // Update as list data
    UpdateBillingCustomerListResponse updateBillingCustomerList(UpdateBillingCustomerRequest request);
    UpdateBillingCustomerListResponse updateBillingCustomerListApprove(UpdateBillingCustomerRequest request);

    // Get Data (get by id, get by customer code, get all)
    BillingCustomerDTO getById(String id);
    BillingCustomerDTO getByCustomerCode(String customerCode);
    List<BillingCustomerDTO> getAll();


    List<BillingCustomerDTO> getAllByBillingCategoryAndBillingType(String billingCategory, String billingType);
    List<BillingCustomerDTO> getAllByBillingCategoryAndBillingTypeAndCurrency(String billingCategory, String billingType, String currency);

    String deleteById(String id);

    CreateCustomerListResponse createList(CreateCustomerListRequest request, BillingDataChangeDTO dataChangeDTO);

}
