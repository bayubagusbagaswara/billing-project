package com.services.billingservice.enums;

public enum GefuTransactionStatus {
    Pending,Success, Failure
}
