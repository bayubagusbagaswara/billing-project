package com.services.billingservice.dto.fund;

import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.time.Instant;

@Data
@SuperBuilder
@NoArgsConstructor
public class BillingFundListProcessDTO {
    private String month;
    private Integer year;
    private Instant createdAt;
    private String billingStatus;
    private String approvalStatus;
}
