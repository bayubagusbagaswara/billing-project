package com.services.billingservice.service;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.exchangerate.CreateExchangeRateRequest;
import com.services.billingservice.dto.exchangerate.ExchangeRateDTO;
import com.services.billingservice.dto.exchangerate.UpdateExchangeRateRequest;
import com.services.billingservice.dto.exchangerate.UpdateExchangeRateResponse;

import java.util.List;

public interface ExchangeRateService {

    ExchangeRateDTO create(CreateExchangeRateRequest request);

    List<ExchangeRateDTO> getAll();

    ExchangeRateDTO getLatestDataByCurrency(String currency);

    ExchangeRateDTO getLatestData();

    ExchangeRateDTO getByCurrency(String currency);

    ExchangeRateDTO updateById(String id, CreateExchangeRateRequest request);

    ExchangeRateDTO getById(String id);

    String deleteByCurrency(String currency);

    // add data change to process Edit
    // jadi ketika mau update akan di record pada data change juga

    // ada 2 method service baru
    // 1. edit (insert to data change)
    UpdateExchangeRateResponse update(UpdateExchangeRateRequest request, BillingDataChangeDTO dataChangeDTO);

    // 2. edit approve (insert to database)
}
