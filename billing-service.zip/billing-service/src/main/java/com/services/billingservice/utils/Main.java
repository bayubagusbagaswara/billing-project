package com.services.billingservice.utils;

import java.time.Month;

public class Main {

    public static void main(String[] args) {
        // Billing Period = Aug 2023 - Oct 2023

        String billingPeriod = "October 2023 - August 2023";
        String billingCategory = "CORE";

        String[] split = billingPeriod.split(" - ");
        String[] s = split[0].split(" ");

        System.out.println("S0 " + s[0]);
        System.out.println("S1 " + s[1]);
        String monthString1 = s[0]; // OCTOBER
        String s2 = s[1]; // 2023

        Month month1 = Month.valueOf(monthString1.toUpperCase());
        System.out.println("Month 1 " + month1);
        int monthValue1 = month1.getValue();
        System.out.println("Month Value 1 " + monthValue1);

        String formattedMonth1 = (monthValue1 < 10) ? "0" + monthValue1 : String.valueOf(monthValue1);
        System.out.println("Formatted Month 1 " + formattedMonth1);

        String[] s3 = split[1].split(" ");
        System.out.println("S3 " + s3);
        String monthString2 = s3[0]; // AUGUST
        System.out.println("S3 [0] " + s3[0]);

        String s5 = s3[1]; // 2023

        Month month2 = Month.valueOf(monthString2.toUpperCase());
        int monthValue2 = month2.getValue();
        String formattedMonth2 = (monthValue2 < 10) ? "0" + monthValue2 : String.valueOf(monthValue2);


        System.out.println("MUFG_" + billingCategory + "_" + formattedMonth2 + s5 + "-" + formattedMonth1 + s2);
    }


}
