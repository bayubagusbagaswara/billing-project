package com.services.billingservice.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.ErrorMessageDTO;
import com.services.billingservice.dto.customer.CustomerDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.mi.*;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.exception.*;
import com.services.billingservice.model.BillingMI;
import com.services.billingservice.repository.BillingMIRepository;
import com.services.billingservice.service.BillingDataChangeService;
import com.services.billingservice.service.BillingMIService;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingMIServiceImpl implements BillingMIService {

    private final BillingMIRepository investmentManagementRepository;
    private final BillingDataChangeService dataChangeService;
    private final Validator validator;
    private final ObjectMapper objectMapper;

    @Override
    public boolean isCodeAlreadyExists(String code) {
        return investmentManagementRepository.existsByCode(code);
    }

    @Override
    public CreateInvestmentManagementListResponse createSingleData(CreateInvestmentManagementRequest request, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create single data investment management with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed= 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        InvestmentManagementDTO investmentManagementDTO = InvestmentManagementDTO.builder()
                .code(request.getCode())
                .name(request.getName())
                .email(request.getEmail())
                .address1(request.getAddress1())
                .address2(request.getAddress2())
                .address3(request.getAddress3())
                .address4(request.getAddress4())
                .build();

        try {
            List<String> validationErrors = new ArrayList<>();
            validationCodeAlreadyExists(investmentManagementDTO.getCode(), validationErrors);

            if (validationErrors.isEmpty()) {
                dataChangeDTO.setInputerId(request.getInputId());
                dataChangeDTO.setInputerIPAddress(request.getInputIPAddress());
                dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(investmentManagementDTO));
                dataChangeService.createChangeActionADD(dataChangeDTO, BillingMI.class);
                totalDataSuccess++;
            } else {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(investmentManagementDTO.getCode(), validationErrors);
                errorMessageList.add(errorMessageDTO);
                totalDataFailed++;
            }
        } catch (JsonProcessingException e) {
            handleJsonProcessingException(e);
        } catch (Exception e) {
            handleGeneralError(e);
        }
        return new CreateInvestmentManagementListResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public CreateInvestmentManagementListResponse createList(CreateInvestmentManagementListRequest request, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create multiple data investment management with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed= 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        for (InvestmentManagementDTO investmentManagementDTO : request.getInvestmentManagementDTOList()) {
            try {
                List<String> validationErrors = new ArrayList<>();
                validationCodeAlreadyExists(investmentManagementDTO.getCode(), validationErrors);

                dataChangeDTO.setInputerId(request.getInputId());
                dataChangeDTO.setInputerIPAddress(request.getApproveIPAddress());
                dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(investmentManagementDTO));

                if (validationErrors.isEmpty()) {
                    dataChangeService.createChangeActionADD(dataChangeDTO, BillingMI.class);
                    totalDataSuccess++;
                } else {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(investmentManagementDTO.getCode(), validationErrors);
                    errorMessageList.add(errorMessageDTO);
                    totalDataFailed++;
                }
            } catch (JsonProcessingException e) {
                handleJsonProcessingException(e);
            } catch (Exception e) {
                handleGeneralError(e);
            }
        }
        return new CreateInvestmentManagementListResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public CreateInvestmentManagementListResponse createListApprove(CreateInvestmentManagementListRequest request) {
        log.info("Approve for create investment management with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        if (!validateDataChangeIds(request.getInvestmentManagementDTOList())) {
            log.error("Not all Data Change ids exist in the database");
            throw new DataChangeException("Not all Data Change ids exists in the database");
        }

        for (InvestmentManagementDTO investmentManagementDTO : request.getInvestmentManagementDTOList()) {
            try {
                List<String> errorMessages = new ArrayList<>();
                Errors errors = validateInvestmentManagementUsingValidator(investmentManagementDTO);

                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(objectError -> errorMessages.add(objectError.getDefaultMessage()));
                }

                BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(investmentManagementDTO.getDataChangeId());

                if (!errorMessages.isEmpty()) {
                    dataChangeDTO.setApprovalStatus(ApprovalStatus.Rejected);
                    dataChangeDTO.setApproverId(request.getApproveId());
                    dataChangeDTO.setApproverIPAddress(request.getApproveIPAddress());
                    dataChangeDTO.setApproveDate(new Date());
                    dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(investmentManagementDTO));
                    dataChangeDTO.setDescription(StringUtil.joinStrings(errorMessages));
                    dataChangeService.update(dataChangeDTO);
                } else {
                    dataChangeDTO.setApprovalStatus(ApprovalStatus.Approved);
                    dataChangeDTO.setApproverId(request.getApproveId());
                    dataChangeDTO.setApproverIPAddress(request.getApproveIPAddress());
                    dataChangeDTO.setApproveDate(new Date());
                    dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(investmentManagementDTO));
                    dataChangeDTO.setDescription("Successfully approve data change and save data investment management");

                    BillingMI investmentManagement = createInvestmentManagement(investmentManagementDTO, dataChangeDTO);
                    investmentManagementRepository.save(investmentManagement);

                    dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                    totalDataSuccess++;
                }
            } catch (DataNotFoundException e) {
                handleDataNotFoundException(investmentManagementDTO, e, errorMessageList);
                totalDataFailed++;
            } catch (JsonProcessingException e) {
                handleJsonProcessingException(e);
            } catch (Exception e) {
                handleGeneralError(e);
            }
        }
        return new CreateInvestmentManagementListResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }


    @Override
    public UpdateInvestmentManagementListResponse updateSingleData(UpdateInvestmentManagementRequest request, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update investment management single data with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();
        // mapping to do
        InvestmentManagementDTO investmentManagementDTO = InvestmentManagementDTO.builder()
                .dataChangeId(request.getDataChangeId())
                .id(request.getId())
                .code(request.getCode())
                .name(request.getName())
                .email(request.getEmail())
                .address1(request.getAddress1())
                .address2(request.getAddress2())
                .address3(request.getAddress3())
                .address4(request.getAddress4())
                .build();
        try {
            BillingMI investmentManagement = investmentManagementRepository.findByCode(investmentManagementDTO.getCode())
                    .orElseThrow(() -> new DataNotFoundException("Investment Management not found with code: " + investmentManagementDTO.getCode()));

            // create data change
            dataChangeDTO.setInputerId(request.getInputId());
            dataChangeDTO.setInputerIPAddress(request.getInputIPAddress());
            dataChangeDTO.setJsonDataBefore(objectMapper.writeValueAsString(investmentManagement));
            dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(investmentManagementDTO));

            dataChangeService.createChangeActionEDIT(dataChangeDTO, BillingMI.class);
            totalDataSuccess++;
        } catch (DataNotFoundException e) {
            handleDataNotFoundException(investmentManagementDTO,e, errorMessageList);
            totalDataFailed++;
        } catch (JsonProcessingException e) {
            // jadi hanya data-data yg gagal akan dimasukkan kedalam response
            totalDataFailed = getTotalDataFailedJsonProcessingException(e, errorMessageList, totalDataFailed);
            totalDataFailed++;
        } catch (Exception e) {
            handleGeneralError(e);
        }
        return new UpdateInvestmentManagementListResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public UpdateInvestmentManagementListResponse updateList(UpdateInvestmentManagementListRequest request, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update investment management list with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        for (InvestmentManagementDTO investmentManagementDTO : request.getInvestmentManagementDTOList()) {
            try {
                BillingMI investmentManagement = investmentManagementRepository.findByCode(investmentManagementDTO.getCode())
                        .orElseThrow(() -> new DataNotFoundException("Investment Management not found with code: " + investmentManagementDTO.getCode()));

                dataChangeDTO.setInputerId(request.getInputId());
                dataChangeDTO.setInputerId(request.getInputIPAddress());
                dataChangeDTO.setEntityId(investmentManagement.getId().toString());
                dataChangeDTO.setJsonDataBefore(objectMapper.writeValueAsString(investmentManagement));
                dataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(investmentManagementDTO));
                dataChangeService.createChangeActionEDIT(dataChangeDTO, BillingMI.class);
                totalDataSuccess++;
            } catch (JsonProcessingException e) {
                totalDataFailed = getTotalDataFailedJsonProcessingException(e, errorMessageList, totalDataFailed);
                totalDataFailed++;
            } catch (DataNotFoundException e) {
                totalDataFailed = getTotalDataFailedDataNotFoundException(e, errorMessageList, totalDataFailed);
                totalDataFailed++;
            } catch (Exception e) {
                handleGeneralError(e);
            }
        }
        return new UpdateInvestmentManagementListResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public UpdateInvestmentManagementListResponse updateListApprove(UpdateInvestmentManagementListRequest request) {
        log.info("Approve for updating investment management with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        try {
            validateDataChangeIds(request.getInvestmentManagementDTOList());
            for (InvestmentManagementDTO investmentManagementDTO : request.getInvestmentManagementDTOList()) {
                try {
                    List<String> errorMessages = new ArrayList<>();
                    Errors errors = validateInvestmentManagementDTO(investmentManagementDTO);

                    if (errors.hasErrors()) {
                        errors.getAllErrors().forEach(error -> errorMessages.add(error.getDefaultMessage()));
                    }

                    BillingMI investmentManagement = investmentManagementRepository.findByCode(investmentManagementDTO.getCode())
                            .orElseThrow(() -> new DataNotFoundException("Investment Management not found with code: " + investmentManagementDTO.getCode()));

                    if (errorMessages.isEmpty()) {
                        updateInvestmentManagement(investmentManagement, investmentManagementDTO);
                        BillingMI investmentManagementSaved = investmentManagementRepository.save(investmentManagement);
                        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                                .id(investmentManagementDTO.getDataChangeId())
                                .approverId(request.getApproveId())
                                .approverIPAddress(request.getApproveIPAddress())
                                .jsonDataBefore(objectMapper.writeValueAsString(investmentManagement))
                                .jsonDataAfter(objectMapper.writeValueAsString(investmentManagementSaved))
                                .description("Successfully approved for updating investment management")
                                .build();
                        dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                        totalDataSuccess++;
                    } else {
                        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                                .id(investmentManagementDTO.getDataChangeId())
                                .approverId(request.getApproveId())
                                .approverIPAddress(request.getApproveIPAddress())
                                .jsonDataBefore(objectMapper.writeValueAsString(investmentManagement))
                                .jsonDataAfter(objectMapper.writeValueAsString(investmentManagementDTO))
                                .build();
                        dataChangeService.approvalStatusIsRejected(dataChangeDTO, errorMessages);
                        totalDataFailed++;
                    }
                } catch (JsonProcessingException e) {
                    totalDataFailed = getTotalDataFailedJsonProcessingException(e, errorMessageList, totalDataFailed);
                    totalDataFailed++;
                }
            }
            return new UpdateInvestmentManagementListResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        } catch (DataChangeException e) {
            handleDataChangeException(e);
        } catch (Exception e) {
            handleGeneralError(e);
        }
        return new UpdateInvestmentManagementListResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public InvestmentManagementDTO getByCode(String code) {
        BillingMI billingMI = investmentManagementRepository.findByCode(code)
                .orElseThrow(() -> new DataNotFoundException("Investment Management not found with code: " + code));
        return mapToDTO(billingMI);
    }

    @Override
    public List<InvestmentManagementDTO> getAll() {
        List<BillingMI> billingMI = investmentManagementRepository.findAll();
        return mapToDTOList(billingMI);
    }

    @Override
    public DeleteInvestmentManagementListResponse deleteSingleData(DeleteInvestmentManagementRequest request, BillingDataChangeDTO dataChangeDTO) {
        log.info("Delete single investment management data with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        try {
            BillingMI investmentManagement = investmentManagementRepository.findById(request.getId())
                    .orElseThrow(() -> new DataNotFoundException("Investment Management not found with id: " + request.getId()));

            dataChangeDTO.setInputerId(request.getInputId());
            dataChangeDTO.setInputerIPAddress(request.getInputIPAddress());
            dataChangeDTO.setJsonDataBefore(objectMapper.writeValueAsString(investmentManagement));
            dataChangeDTO.setJsonDataAfter("");

            dataChangeService.createChangeActionDELETE(dataChangeDTO, BillingMI.class);
            totalDataSuccess++;

            return new DeleteInvestmentManagementListResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        } catch (JsonProcessingException e) {
            totalDataFailed = getTotalDataFailedJsonProcessingException(e, errorMessageList, totalDataFailed);
            totalDataFailed++;
        } catch (DataNotFoundException e) {
            totalDataFailed = getTotalDataFailedDataNotFoundException(e, errorMessageList, totalDataFailed);
            totalDataFailed++;
        } catch (Exception e) {
            handleGeneralError(e);
        }
        return new DeleteInvestmentManagementListResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public DeleteInvestmentManagementListResponse deleteListApprove(DeleteInvestmentManagementListRequest request) {
        log.info("Approve delete investment management list with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        try {
            validateDataChangeIds(request.getInvestmentManagementDTOList());
            for (InvestmentManagementDTO investmentManagementDTO : request.getInvestmentManagementDTOList()) {
                try {
                    BillingMI investmentManagement = investmentManagementRepository.findById(investmentManagementDTO.getId())
                            .orElseThrow(() -> new DataNotFoundException("Investment Management not found with id: " + investmentManagementDTO.getId()));

                    BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(investmentManagementDTO.getDataChangeId());

                    dataChangeDTO.setApproverId(request.getApproveId());
                    dataChangeDTO.setApproverIPAddress(request.getApproveIPAddress());
                    dataChangeDTO.setJsonDataBefore(objectMapper.writeValueAsString(investmentManagement));
                    dataChangeDTO.setJsonDataAfter("");

                    dataChangeService.update(dataChangeDTO);
                    totalDataSuccess++;
                } catch (DataNotFoundException e) {
                    totalDataFailed = getTotalDataFailedDataNotFoundException(e, errorMessageList, totalDataFailed);
                    totalDataFailed++;
                } catch (JsonProcessingException e) {
                    totalDataFailed = getTotalDataFailedJsonProcessingException(e, errorMessageList, totalDataFailed);
                    totalDataFailed++;
                }
            }
            return new DeleteInvestmentManagementListResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        } catch (DataChangeException e) {
            handleDataChangeException(e);
        } catch (Exception e) {
            handleGeneralError(e);
        }
        return new DeleteInvestmentManagementListResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public String deleteAll() {
        investmentManagementRepository.deleteAll();
        return "Successfully delete all investment management";
    }

    private Errors validateInvestmentManagementDTO(InvestmentManagementDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "investmentManagementDTO");
        validator.validate(dto, errors);
        return errors;
    }

    private void validationCodeAlreadyExists(String code, List<String> errorMessages) {
        if (isCodeAlreadyExists(code)) {
            errorMessages.add("Investment Management is already taken with code: " + code);
        }
    }

    private static InvestmentManagementDTO mapToDTO(BillingMI investmentManagement) {
        return InvestmentManagementDTO.builder()
                .id(investmentManagement.getId())
                .code(investmentManagement.getCode())
                .name(investmentManagement.getName())
                .email(investmentManagement.getEmail())
                .address1(investmentManagement.getAlamat1())
                .address2(investmentManagement.getAlamat2())
                .address3(investmentManagement.getAlamat3())
                .address4(investmentManagement.getAlamat4())
                .build();
    }

    private static List<InvestmentManagementDTO> mapToDTOList(List<BillingMI> investmentManagementList) {
        return investmentManagementList.stream()
                .map(BillingMIServiceImpl::mapToDTO)
                .collect(Collectors.toList());
    }

    private void updateInvestmentManagement(BillingMI existingInvestment, InvestmentManagementDTO updatedDTO) {
        // Update only the fields that are present in the updated DTO
        if (!updatedDTO.getCode().isEmpty()) {
            existingInvestment.setCode(updatedDTO.getCode());
        }
        if (!updatedDTO.getName().isEmpty()) {
            existingInvestment.setName(updatedDTO.getName());
        }
        if (!updatedDTO.getEmail().isEmpty()) {
            existingInvestment.setEmail(updatedDTO.getEmail());
        }
        if (!updatedDTO.getAddress1().isEmpty()) {
            existingInvestment.setAlamat1(updatedDTO.getAddress1());
        }
        if (!updatedDTO.getAddress2().isEmpty()) {
            existingInvestment.setAlamat2(updatedDTO.getAddress2());
        }
        if (!updatedDTO.getAddress3().isEmpty()) {
            existingInvestment.setAlamat3(updatedDTO.getAddress3());
        }
        if (!updatedDTO.getAddress4().isEmpty()) {
            existingInvestment.setAlamat4(updatedDTO.getAddress4());
        }
    }

    private static void handleDataChangeException(DataChangeException e) {
        log.error("Data Change exception occurred: {}", e.getMessage());
        throw new DataChangeException("Data Change exception occurred: " + e.getMessage());
    }

    private static int getTotalDataFailedJsonProcessingException(JsonProcessingException e, List<ErrorMessageDTO> errorMessageList, int totalDataFailed) {
        List<String> errorMessages = new ArrayList<>();
        errorMessages.add("Error processing JSON during data change logging: " + e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(null, errorMessages));
        totalDataFailed++;
        return totalDataFailed;
    }

    private static int getTotalDataFailedDataNotFoundException(DataNotFoundException e, List<ErrorMessageDTO> errorMessageList, int totalDataFailed) {
        log.error("Investment Management not found: {}", e.getMessage(), e);
        errorMessageList.add(new ErrorMessageDTO(null, Collections.singletonList(e.getMessage())));
        totalDataFailed++;
        return totalDataFailed;
    }

    private static void handleGeneralError(Exception e) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        throw new DataChangeException("An unexpected error occurred: " + e.getMessage());
    }

    private Errors validateInvestmentManagementUsingValidator(InvestmentManagementDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "investmentManagementDTO");
        validator.validate(dto, errors);
        return errors;
    }

    private BillingMI createInvestmentManagement(InvestmentManagementDTO investmentManagementDTO, BillingDataChangeDTO dataChangeDTO) {
        return BillingMI.builder()
                .code(investmentManagementDTO.getCode())
                .name(investmentManagementDTO.getName())
                .email(investmentManagementDTO.getEmail())
                .alamat1(investmentManagementDTO.getAddress1())
                .alamat2(investmentManagementDTO.getAddress2())
                .alamat3(investmentManagementDTO.getAddress3())
                .alamat4(investmentManagementDTO.getAddress4())
                .approvalStatus(dataChangeDTO.getApprovalStatus())
                .inputerId(dataChangeDTO.getInputerId())
                .inputerIPAddress(dataChangeDTO.getInputerIPAddress())
                .inputDate(dataChangeDTO.getInputDate())
                .approverId(dataChangeDTO.getApproverId())
                .approverIPAddress(dataChangeDTO.getApproverIPAddress())
                .approveDate(dataChangeDTO.getApproveDate())
                .build();
    }

    private static void handleJsonProcessingException(JsonProcessingException e) {
        log.error("Error processing JSON during data change logging: {}", e.getMessage(), e);
        throw new DataChangeException("Error processing JSON during data change logging", e);
    }

    private boolean validateDataChangeIds(List<InvestmentManagementDTO> investmentManagementDTOList) {
        List<Long> idDataChangeList = investmentManagementDTOList.stream()
                .map(InvestmentManagementDTO::getDataChangeId)
                .collect(Collectors.toList());
        return dataChangeService.areAllIdsExistInDatabase(idDataChangeList);
    }

    private void handleDataNotFoundException(InvestmentManagementDTO investmentManagementDTO, DataNotFoundException e, List<ErrorMessageDTO> errorMessageDTOList) {
        log.error("Investment Management not found with id: {}", investmentManagementDTO != null ? investmentManagementDTO.getCode() : "unknown", e);

        List<String> validationErrors = new ArrayList<>();
        validationErrors.add("Investment Management not found with code: " + (investmentManagementDTO != null ? investmentManagementDTO.getCode() : "unknown"));

        errorMessageDTOList.add(new ErrorMessageDTO(investmentManagementDTO != null ? investmentManagementDTO.getCode() : "unknown", validationErrors));
    }

}
