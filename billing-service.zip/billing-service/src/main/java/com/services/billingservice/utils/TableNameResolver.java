package com.services.billingservice.utils;

import lombok.experimental.UtilityClass;

import javax.persistence.Table;
import java.util.Optional;

@UtilityClass
public class TableNameResolver {

    public static String getTableName(Class<?> entityClass) {
        Optional<Table> tableAnnotation = Optional.ofNullable(entityClass.getAnnotation(Table.class));
        return tableAnnotation.map(Table::name).orElse(entityClass.getSimpleName());
    }
}
