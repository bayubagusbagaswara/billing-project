package com.services.billingservice.repository;

import com.services.billingservice.dto.retail.BillingRetailListProcess;
import com.services.billingservice.model.BillingRetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillingRetailRepository extends JpaRepository<BillingRetail, Long> {

    @Query(value = "SELECT * FROM billing_retail " +
            "WHERE customer_code = :customerCode " +
            "AND currency = :currency " +
            "AND month = :month " +
            "AND year = :year", nativeQuery = true)
    Optional<BillingRetail> findByCustomerCodeAndCurrencyAndMonthAndYear(
            @Param("customerCode") String customerCode,
            @Param("currency") String currency,
            @Param("month") String monthName,
            @Param("year") Integer year
    );

    //TODO for payment
    @Query(value = "SELECT * FROM billing_retail " +
            "WHERE bill_category = :billingCategory " +
            "AND bill_type = :billingType " +
            "AND month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus", nativeQuery = true)
    List<BillingRetail> findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndApprovalStatus(
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("month") String month,
            @Param("year") Integer year,
            @Param("approvalStatus") String approvalStatus
    );

    //TODO for payment
    @Query(value = "SELECT * FROM billing_retail " +
            "WHERE customer_code = :custCode" +
            "AND month = :month " +
            "AND year = :year " +
            "AND approval_status = :approvalStatus", nativeQuery = true)
  BillingRetail findByCustomerCodeAndMonthAndYearAndApprovalStatus(
            @Param("custCode") String custCode,
            @Param("month") String month,
            @Param("year") Integer year,
            @Param("approvalStatus") String approvalStatus
    );


    @Query(value = "SELECT DISTINCT NEW com.services.billingservice.dto.retail.BillingRetailListProcess " +
            "(f.month, f.year, MAX(f.createdAt), f.approvalStatus, f.billingStatus) " +
            "FROM BillingRetail f " +
            "GROUP BY f.month, f.year, f.approvalStatus, f.billingStatus " +
            "ORDER BY f.year DESC, month DESC")
    List<BillingRetailListProcess> getAllListProcess();

    @Query(value = "SELECT DISTINCT NEW com.services.billingservice.dto.retail.BillingRetailListProcess " +
            "(f.month, f.year, MAX(f.createdAt), f.approvalStatus, f.billingStatus) " +
            "FROM BillingRetail f " +
            "WHERE upper(f.approvalStatus) = 'PENDING' " +
            "   AND upper(f.billingStatus) = 'REVIEWED' " +
            "GROUP BY f.month, f.year, f.approvalStatus, f.billingStatus " +
            "ORDER BY f.year DESC, month DESC")
    List<BillingRetailListProcess> getAllListPendingApprove();

    List<BillingRetail> findByMonthAndYearAndBillingCategoryAndBillingTypeAndCurrency(String month, Integer year, String category, String type, String currency);

    @Query(value = "SELECT * FROM billing_retail " +
            "WHERE bill_category = :billingCategory " +
            "AND bill_type = :billingType " +
            "AND month = :month " +
            "AND year = :year", nativeQuery = true)
    List<BillingRetail> findAllByBillingCategoryAndBillingTypeAndMonthAndYear(
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("month") String month,
            @Param("year") Integer year
    );
}
