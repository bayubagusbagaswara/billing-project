package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.exception.GeneratePDFBillingException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.CoreGeneratePDFService;
import com.services.billingservice.utils.BillingCoreGeneratePDFService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class CoreGeneratePDFServiceImpl implements CoreGeneratePDFService {

    @Value("${base.path.billing.core}")
    private String basePathBillingCore;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private final BillingCoreRepository billingCoreRepository;
    private final BillingCoreGeneratePDFService billingCoreGeneratePDFService;

    @Override
    public String generatePDF(CoreCalculateRequest request) {
        log.info("Start generate PDF Billing Core type: {}", request.getType());
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());
        String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            // TODO: Change Approval Status to Approved
            String approvalStatus = ApprovalStatus.Pending.getStatus();

            List<BillingCore> billingCoreList = billingCoreRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndApprovalStatus(
                    categoryUpperCase, typeUpperCase, monthName, year, approvalStatus
            );

            billingCoreGeneratePDFService.generateAndSavePdfStatements(billingCoreList);
            log.info("Finished generate PDF Billing Core type {}", categoryUpperCase);
            return "Successfully created a PDF file for Billing Core type: " + typeUpperCase;
        } catch (Exception e) {
            log.error("Error when generate PDF Billing Core type '" + typeUpperCase + "' : " + e.getMessage(), e);
            throw new GeneratePDFBillingException("Error when generate PDF Billing Core type '" + typeUpperCase + "' : " + e.getMessage());
        }
    }
}
