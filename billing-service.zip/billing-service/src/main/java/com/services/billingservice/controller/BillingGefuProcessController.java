package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.core.*;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.services.billingservice.enums.BillingCategory.CORE;
import static com.services.billingservice.enums.BillingType.*;

@Slf4j
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(path = "/api/billing/core")
@RequiredArgsConstructor
public class BillingGefuProcessController {

    private final BillingGefuGeneratorService gefuGeneratorService;


    @PostMapping(path = "/create-gefu")
    public ResponseEntity<ResponseDTO<String>> createBillingGefu(@RequestParam("type") String type,
                                                              @RequestParam("userid") String userid,
                                                              @RequestParam("year") Integer year) {

        String status = "";//gefuGeneratorService.createGefu(type, year, userid);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }
}
