package com.services.billingservice.controller;

import com.services.billingservice.dto.BillingFeeScheduleDTO;
import com.services.billingservice.dto.BillingSellingAgentDataDTO;
import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.request.BillingFeeScheduleRequest;
import com.services.billingservice.dto.request.BillingSellingAgentDataRequest;
import com.services.billingservice.service.BillingFeeScheduleService;
import com.services.billingservice.service.BillingSellingAgentDataService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/selling-agent")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class BillingSellingAgentDataController {

    private final BillingSellingAgentDataService billingSellingAgentDataService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<String>> create(@RequestBody BillingSellingAgentDataRequest request) {

        System.out.println("request" + request);
        BillingSellingAgentDataDTO billingSellingAgentDataDTO = billingSellingAgentDataService.create(request);

        ResponseDTO<String> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload("Successfully created Fee Schedule with id : " + billingSellingAgentDataDTO.getId());

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping(path = "/id")
    public ResponseEntity<ResponseDTO<BillingSellingAgentDataDTO>> getById(@RequestParam(name = "id") String id) {
        BillingSellingAgentDataDTO billingSellingAgentDataDTO = billingSellingAgentDataService.getByCode(id);

        ResponseDTO<BillingSellingAgentDataDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingSellingAgentDataDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BillingSellingAgentDataDTO>>> getAll() {
        List<BillingSellingAgentDataDTO> billingSellingAgentDataDTOList = billingSellingAgentDataService.getAll();

        ResponseDTO<List<BillingSellingAgentDataDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingSellingAgentDataDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(path = "/code")
    public ResponseEntity<ResponseDTO<BillingSellingAgentDataDTO>> updateById(@RequestParam("id") String id,
                                                                         @RequestBody BillingSellingAgentDataRequest request) {
        BillingSellingAgentDataDTO billingSellingAgentDataDTO = billingSellingAgentDataService.updateById(id, request);
        ResponseDTO<BillingSellingAgentDataDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingSellingAgentDataDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping(path = "/delete")
    public ResponseEntity<ResponseDTO<String>> deleteByCode(@RequestParam("id") String id) {
        String deleteById = billingSellingAgentDataService.delete(id);

        ResponseDTO<String> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(deleteById);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
