package com.services.billingservice.repository;

import com.services.billingservice.model.BillingSellingAgentData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillingSellingAgentDataRepository extends JpaRepository<BillingSellingAgentData, Long> {

    @Query(value = "SELECT * FROM bill_selling_agent_data WHERE id = :id", nativeQuery = true)
    Optional<BillingSellingAgentData> findById(@Param("id") String id);

    @Query(value = "SELECT * FROM bill_selling_agent_data", nativeQuery = true)
    List<BillingSellingAgentData> findAll();

    @Query(value = "SELECT * FROM bill_selling_agent_data WHERE bill_selling_agent_code = :sellingAgentCode", nativeQuery = true)
    Optional<BillingSellingAgentData> findByBillingSellingAgentCode(@Param("sellingAgentCode") String sellingAgentCode);

    Boolean existsByBillingSellingAgentCode(String sellingAgentCode);
}
