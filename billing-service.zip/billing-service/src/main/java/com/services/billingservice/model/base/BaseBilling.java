package com.services.billingservice.model.base;

import com.services.billingservice.enums.BillingStatus;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.MappedSuperclass;

@EqualsAndHashCode(callSuper = true)
@MappedSuperclass
@Data
@NoArgsConstructor
@SuperBuilder
public abstract class BaseBilling extends BaseAudit {

    @Enumerated(EnumType.STRING)
    private BillingStatus billingStatus;

    @Column(name = "customer_code")
    private String customerCode;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "month")
    private String month;

    @Column(name = "year")
    private Integer year;

    @Column(name = "bill_number")
    private String billingNumber;

    @Column(name = "bill_period")
    private String billingPeriod;

    @Column(name = "bill_statement_date")
    private String billingStatementDate;

    @Column(name = "bill_payment_due_date")
    private String billingPaymentDueDate;

    @Column(name = "bill_category")
    private String billingCategory;

    @Column(name = "bill_type")
    private String billingType;

    @Column(name = "bill_template")
    private String billingTemplate;

    @Column(name = "mi_name")
    private String investmentManagementName;

    @Column(name = "mi_address_1")
    private String investmentManagementAddress1;

    @Column(name = "mi_address_2")
    private String investmentManagementAddress2;

    @Column(name = "mi_address_3")
    private String investmentManagementAddress3;

    @Column(name = "mi_address_4")
    private String investmentManagementAddress4;

    @Column(name = "mi_email")
    private String investmentManagementEmail;

    // productName is deleted, because its same accountName (for billing fund)

    @Column(name = "account_name")
    private String accountName; // this is same with GL Name

    @Column(name = "account_number")
    private String accountNumber; // this is same with GL Number (account)

    @Column(name = "cost_center")
    private String costCenter;

    @Column(name = "account_bank")
    private String accountBank; // this is bank name

    @Column(name = "swift_code")
    private String swiftCode;

    @Column(name = "corr_bank")
    private String corrBank;

    @Column(name = "currency")
    private String currency;

}
