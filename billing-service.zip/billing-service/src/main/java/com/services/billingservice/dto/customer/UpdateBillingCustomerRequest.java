package com.services.billingservice.dto.customer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateBillingCustomerRequest {

    private String dataChangeId;

    private String approvalStatus;

    private String inputerIPAddress;

    private String inputerId;

    private String approverIPAddress;

    private String approverId;

    private List<UpdateBillingCustomerListRequest> dataListRequest;
}
