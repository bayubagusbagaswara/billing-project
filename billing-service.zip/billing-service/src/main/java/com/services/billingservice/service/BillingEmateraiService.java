package com.services.billingservice.service;

import com.services.billingservice.dto.BillingEmateraiDTO;
import com.services.billingservice.dto.BillingFeeParamDTO;
import com.services.billingservice.dto.request.BillingEmateraiRequest;
import com.services.billingservice.dto.request.BillingFeeParamRequest;
import com.services.billingservice.model.BillingEmaterai;

import java.util.List;

public interface BillingEmateraiService {


    List<BillingEmateraiDTO>getByCategory(String Category);


}
