package com.services.billingservice.controller;

import com.services.billingservice.dto.BillingSecurityDTO;
import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.request.BillingSecurityRequest;
import com.services.billingservice.service.BillingSecurityService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/security")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class BillingSecurityController {

    private final BillingSecurityService billingSecurityService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<String>>
    create(@RequestBody BillingSecurityRequest request) {

        BillingSecurityDTO billingSecurityDTO = billingSecurityService.create(request);

        ResponseDTO<String> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload("Successfully create billing security with id :"+billingSecurityDTO.getCode());

        return new ResponseEntity<>(response, HttpStatus.CREATED);

    }

    @PostMapping(path = "/upload")
    public ResponseEntity<ResponseDTO<List<BillingSecurityDTO>>> upload(
            @RequestBody List<BillingSecurityRequest> billingSecurityList) {
        List<BillingSecurityDTO> billingSecurityDTO = billingSecurityService.upload(billingSecurityList);

        ResponseDTO<List<BillingSecurityDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.getReasonPhrase());
        response.setPayload(billingSecurityDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);

    }

    @PutMapping(path = "/{code}")
    public ResponseEntity<ResponseDTO<BillingSecurityDTO>> updateByCode(@PathVariable("code") String code,
                                                                           @RequestBody BillingSecurityRequest request) {
        BillingSecurityDTO billingSecurityDTO = billingSecurityService.updateByCode(code, request);
        ResponseDTO<BillingSecurityDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingSecurityDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<List<BillingSecurityDTO>>> update(
            @RequestBody List<BillingSecurityRequest> billingSecurityList) {
        List<BillingSecurityDTO> billingSecurityDTO = billingSecurityService.updateUploadByCode(billingSecurityList );

        ResponseDTO<List<BillingSecurityDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.getReasonPhrase());
        response.setPayload(billingSecurityDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);

    }
}
