package com.services.billingservice.aop;

import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class DataChangeRejectAspect {

//    Logger logger = LoggerFactory.getLogger(DataChangeApproveAspect.class);
//    @Autowired
//    ApplicationContext applicationContext;
//    @Autowired
//    private DataChangeRepository dataChangeRepository;
//
//    @Pointcut("execution(* com.services.billingservice.service.DataChangeService.doReject(..)) && args(dataChangeId)")
//    public void dataChangeReject(Long dataChangeId) {
//    }
//    @AfterReturning(pointcut = "dataChangeReject(dataChangeId)", returning = "result")
//    public void copyApprovedDataToMaster(Long dataChangeId, ResponseEntity<ResponseDTO> result) {
//
//        String className = result.getBody().getPayload().getClass().getSimpleName();
//        String firstLetterLowercase = Character.toLowerCase(className.charAt(0)) + className.substring(1); // Ubah huruf pertama menjadi huruf kecil
//        String repositoryName = firstLetterLowercase + "Repository"; // Buat nama repository
//
//        // mencari repository berdasarkan nama
//        JpaRepository<Object, String> repository = (JpaRepository<Object, String>) applicationContext.getBean(repositoryName);
//
//        DataChange dataChange = dataChangeRepository.findById(dataChangeId).orElseThrow(()->new RuntimeException("No data!"));
//        Approvable approvable = (Approvable) SerializationUtils.deserialize(dataChange.getChangedObject());
//        approvable.setApprovalStatus(ApprovalStatus.Rejected);
//        approvable.setApproveDate(new Date());
//        approvable.setApproverId(UserIdUtil.getUser());
//        repository.save(approvable);
//        logger.info("Reject Data change");
//
//    }
}
