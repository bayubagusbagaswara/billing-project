package com.services.billingservice.utils;

import com.services.billingservice.dto.retail.BillingRetailDTO;
import com.services.billingservice.enums.ReportGeneratorStatus;
import com.services.billingservice.model.BillingReportGenerator;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.service.BillingReportGeneratorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.services.billingservice.constant.RetailConstant.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingRetailGeneratePDFService {

    @Value("${base.path.billing.retail}")
    private String basePathBillingRetail;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private final SpringTemplateEngine templateEngine;
    private final PdfGenerator pdfGenerator;
    private final BillingReportGeneratorService billingReportGeneratorService;

    public void generateAndSavePdfStatements(List<BillingRetail> billingRetailList) {
        log.info("Start generate and save PDF statements Billing Retail");

        List<BillingReportGenerator> billingReportGeneratorList = new ArrayList<>();
        BillingReportGenerator billingReportGenerator = new BillingReportGenerator();
        Instant dateNow = Instant.now();

        List<BillingRetailDTO> billingRetailDTOList = mapToDTOList(billingRetailList);

        for (BillingRetailDTO billingRetailDTO : billingRetailDTOList) {
            log.info("Start generate PDF Billing Retail type '{}' and currency '{}'", billingRetailDTO.getBillingType(), billingRetailDTO.getCurrency());

            String investmentManagementName = billingRetailDTO.getInvestmentManagementName();
            String investmentManagementEmail = billingRetailDTO.getInvestmentManagementEmail();
            String sellingAgent = billingRetailDTO.getSellingAgent();
            String customerName = billingRetailDTO.getCustomerName();
            String billingCategory = billingRetailDTO.getBillingCategory();
            String billingType = billingRetailDTO.getBillingType();
            String billingPeriod = billingRetailDTO.getBillingPeriod();
            String currency = billingRetailDTO.getCurrency();

            log.info("Start generate PDF Billing Retail type '{}', selling agent '{}', and currency '{}'", billingType, sellingAgent, currency);

            Map<String, String> monthYearMap;
            String yearMonthFormat;
            String htmlContent;
            byte[] pdfBytes;
            String fileName;
            String filePath;
            String folderPath;
            String outputPath;

            monthYearMap = ConvertDateUtil.extractMonthYearInformation(billingPeriod);
            yearMonthFormat = monthYearMap.get("year") + monthYearMap.get("monthValue");

            int year = Integer.parseInt(monthYearMap.get("year"));
            String monthName = monthYearMap.get("monthName");

            fileName = generateFileName(sellingAgent, billingCategory, currency, yearMonthFormat);

            folderPath = basePathBillingRetail + yearMonthFormat + "/" + investmentManagementName;

            filePath = folderPath + "/" + fileName;

            try {
                htmlContent = renderThymeleafTemplate(billingRetailDTO);
                pdfBytes = pdfGenerator.generatePdfFromHtml(htmlContent);

                Path folderPathObj = Paths.get(folderPath);
                Files.createDirectories(folderPathObj);

                Path outputPathObj = folderPathObj.resolve(fileName);
                outputPath = outputPathObj.toString();

                pdfGenerator.savePdfToFile(pdfBytes, outputPath);

                billingReportGenerator.setCreatedAt(dateNow);
                billingReportGenerator.setInvestmentManagementName(investmentManagementName);
                billingReportGenerator.setInvestmentManagementEmail(investmentManagementEmail);
                billingReportGenerator.setCustomerCode(sellingAgent);
                billingReportGenerator.setCustomerName(customerName);
                billingReportGenerator.setCategory(billingCategory);
                billingReportGenerator.setType(billingType);
                billingReportGenerator.setMonth(monthName);
                billingReportGenerator.setYear(year);
                billingReportGenerator.setCurrency(currency);
                billingReportGenerator.setPeriod(billingPeriod);
                billingReportGenerator.setFileName(fileName);
                billingReportGenerator.setFilePath(filePath);
                billingReportGenerator.setStatus(ReportGeneratorStatus.SUCCESS.getStatus());
                billingReportGenerator.setDesc("Success generate and save PDF statements");

                billingReportGeneratorList.add(billingReportGenerator);
            } catch (Exception e) {
                log.error("Error creating folder or saving PDF: " + e.getMessage(), e);

                billingReportGenerator.setCreatedAt(dateNow);
                billingReportGenerator.setInvestmentManagementName(investmentManagementName);
                billingReportGenerator.setInvestmentManagementEmail(investmentManagementEmail);
                billingReportGenerator.setCustomerCode(sellingAgent);
                billingReportGenerator.setCustomerName(customerName);
                billingReportGenerator.setCategory(billingCategory);
                billingReportGenerator.setType(billingType);
                billingReportGenerator.setMonth(monthName);
                billingReportGenerator.setYear(year);
                billingReportGenerator.setCurrency(currency);
                billingReportGenerator.setPeriod(billingPeriod);
                billingReportGenerator.setFileName(fileName);
                billingReportGenerator.setFilePath(filePath);
                billingReportGenerator.setStatus(ReportGeneratorStatus.FAILED.getStatus());
                billingReportGenerator.setDesc(e.getMessage());

                billingReportGeneratorList.add(billingReportGenerator);
            }

            List<BillingReportGenerator> billingReportGeneratorListSaved = billingReportGeneratorService.saveAll(billingReportGeneratorList);
            log.info("Save billing report generator list saved '{}'", billingReportGeneratorListSaved.size());
        }
    }

    private String renderThymeleafTemplate(BillingRetailDTO retailDTO) {
        Context context = new Context();

        context.setVariable(BILLING_NUMBER, retailDTO.getBillingNumber());
        context.setVariable(BILLING_PERIOD, retailDTO.getBillingPeriod());
        context.setVariable(BILLING_STATEMENT_DATE, retailDTO.getBillingStatementDate());
        context.setVariable(BILLING_PAYMENT_DUE_DATE, retailDTO.getBillingPaymentDueDate());
        context.setVariable(BILLING_CATEGORY, retailDTO.getBillingCategory());
        context.setVariable(BILLING_TYPE, retailDTO.getBillingType());
        context.setVariable(BILLING_TEMPLATE, retailDTO.getBillingTemplate());
        context.setVariable(INVESTMENT_MANAGEMENT_NAME, retailDTO.getInvestmentManagementName());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_1, retailDTO.getInvestmentManagementAddress1());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_2, retailDTO.getInvestmentManagementAddress2());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_3, retailDTO.getInvestmentManagementAddress3());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_4, retailDTO.getInvestmentManagementAddress4());

        context.setVariable(SAFEKEEPING_FR, retailDTO.getSafekeepingFR());
        context.setVariable(SAFEKEEPING_SR, retailDTO.getSafekeepingSR());
        context.setVariable(SAFEKEEPING_ST, retailDTO.getSafekeepingST());
        context.setVariable(SAFEKEEPING_ORI, retailDTO.getSafekeepingORI());
        context.setVariable(SAFEKEEPING_SBR, retailDTO.getSafekeepingSBR());
        context.setVariable(SAFEKEEPING_PBS, retailDTO.getSafekeepingPBS());
        context.setVariable(SAFEKEEPING_CORPORATE_BOND, retailDTO.getSafekeepingCorporateBond());

        context.setVariable(TOTAL_AMOUNT_DUE, retailDTO.getTotalAmountDue());

        context.setVariable(SAFEKEEPING_VALUE_FREQUENCY, retailDTO.getSafekeepingValueFrequency());
        context.setVariable(SAFEKEEPING_FEE, retailDTO.getSafekeepingFee());
        context.setVariable(SAFEKEEPING_AMOUNT_DUE, retailDTO.getSafekeepingAmountDue());

        context.setVariable(TRANSACTION_SETTLEMENT_VALUE_FREQUENCY, retailDTO.getTransactionSettlementValueFrequency());
        context.setVariable(TRANSACTION_SETTLEMENT_FEE, retailDTO.getTransactionSettlementFee());
        context.setVariable(TRANSACTION_SETTLEMENT_AMOUNT_DUE, retailDTO.getTransactionSettlementAmountDue());

        context.setVariable(AD_HOC_REPORT_VALUE_FREQUENCY, retailDTO.getAdHocReportValueFrequency());
        context.setVariable(AD_HOC_REPORT_FEE, retailDTO.getAdHocReportFee());
        context.setVariable(AD_HOC_REPORT_AMOUNT_DUE, retailDTO.getAdHocReportAmountDue());

        context.setVariable(THIRD_PARTY_VALUE_FREQUENCY, retailDTO.getThirdPartyValueFrequency());
        context.setVariable(THIRD_PARTY_FEE, retailDTO.getThirdPartyFee());
        context.setVariable(THIRD_PARTY_AMOUNT_DUE, retailDTO.getThirdPartyAmountDue());

        context.setVariable(VAT_FEE, retailDTO.getVatFee());
        context.setVariable(VAT_AMOUNT_DUE, retailDTO.getVatAmountDue());

        context.setVariable(SUB_TOTAL, retailDTO.getSubTotalAmountDue());

        context.setVariable(TRANSACTION_HANDLING_VALUE_FREQUENCY, retailDTO.getTransactionHandlingValueFrequency());
        context.setVariable(TRANSACTION_HANDLING_FEE, retailDTO.getTransactionHandlingFee());
        context.setVariable(TRANSACTION_HANDLING_AMOUNT_DUE, retailDTO.getTransactionHandlingAmountDue());

        context.setVariable(TRANSACTION_HANDLING_INTERNAL_VALUE_FREQUENCY, retailDTO.getTransactionHandlingInternalValueFrequency());
        context.setVariable(TRANSACTION_HANDLING_INTERNAL_FEE, retailDTO.getTransactionHandlingInternalFee());
        context.setVariable(TRANSACTION_HANDLING_INTERNAL_AMOUNT_DUE, retailDTO.getTransactionHandlingInternalAmountDue());

        context.setVariable(TRANSFER_VALUE_FREQUENCY, retailDTO.getTransferValueFrequency());
        context.setVariable(TRANSFER_FEE, retailDTO.getTransferFee());
        context.setVariable(TRANSFER_AMOUNT_DUE, retailDTO.getTransferAmountDue());

        String imageUrlHeader = "file:///" + folderPathImage + "/logo.png";
        String imageUrlFooter = "file:///" + folderPathImage + "/footer.png";
        context.setVariable("imageUrlHeader", imageUrlHeader);
        context.setVariable("imageUrlFooter", imageUrlFooter);

        String currency = retailDTO.getCurrency(); // IDR
        String billingCategory = retailDTO.getBillingCategory(); // RETAIL
        String billingType = retailDTO.getBillingType(); // TYPE_1

        // Format Template = RETAIL_TYPE_1_IDR
        String templateFormat = billingCategory + "_" + billingType + "_" + currency;

        return templateEngine.process(templateFormat, context);
    }

    private String generateFileName(String sellingAgent, String billingCategory, String currency, String yearMonthFormat) {
        // SELLING_AGENT + BILLING CATEGORY + CURRENCY + YEAR MONTH FORMAT
        return sellingAgent + "_" + billingCategory + "_" + currency + "_" + yearMonthFormat + ".pdf";
    }

    private BillingRetailDTO mapToDTO(BillingRetail billingRetail) {
        return BillingRetailDTO.builder()
                .createdAt(billingRetail.getCreatedAt())
                .updatedAt(billingRetail.getUpdatedAt())
                .approvalStatus(billingRetail.getApprovalStatus().getStatus())
                .billingStatus(billingRetail.getBillingStatus().getStatus())
                .customerCode(billingRetail.getCustomerCode())
                .customerName(billingRetail.getCustomerName())
                .month(billingRetail.getMonth())
                .year(String.valueOf(billingRetail.getYear()))
                .billingNumber(billingRetail.getBillingNumber())
                .billingPeriod(billingRetail.getBillingPeriod())
                .billingStatementDate(billingRetail.getBillingStatementDate())
                .billingPaymentDueDate(billingRetail.getBillingPaymentDueDate())
                .billingCategory(billingRetail.getBillingCategory())
                .billingType(billingRetail.getBillingType())
                .billingTemplate(billingRetail.getBillingTemplate())
                .investmentManagementName(billingRetail.getInvestmentManagementName())
                .investmentManagementAddress1(billingRetail.getInvestmentManagementAddress1())
                .investmentManagementAddress2(billingRetail.getInvestmentManagementAddress2())
                .investmentManagementAddress3(billingRetail.getInvestmentManagementAddress3())
                .investmentManagementAddress4(billingRetail.getInvestmentManagementAddress4())
                .investmentManagementEmail(billingRetail.getInvestmentManagementEmail())
                .accountName(billingRetail.getAccountName())
                .accountNumber(billingRetail.getAccountNumber())
                .accountBank(billingRetail.getAccountBank())
                .swiftCode(billingRetail.getSwiftCode())
                .corrBank(billingRetail.getCorrBank())
                .currency(billingRetail.getCurrency())

                .sellingAgent(billingRetail.getSellingAgent())
                .currency(billingRetail.getCurrency())
                .safekeepingFR(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingFR()))
                .safekeepingSR(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingSR()))
                .safekeepingST(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingST()))
                .safekeepingORI(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingORI()))
                .safekeepingSBR(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingSBR()))
                .safekeepingPBS(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingPBS()))
                .safekeepingCorporateBond(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingCorporateBond()))

                .subTotalAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSubTotalAmountDue()))
                .totalAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTotalAmountDue()))

                .safekeepingValueFrequency(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingValueFrequency()))
                .safekeepingFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingFee()))
                .safekeepingAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingAmountDue()))

                .transactionSettlementValueFrequency(String.valueOf(billingRetail.getTransactionSettlementValueFrequency()))
                .transactionSettlementFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransactionSettlementFee()))
                .transactionSettlementAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransactionSettlementAmountDue()))

                .adHocReportValueFrequency(String.valueOf(billingRetail.getAdHocReportValueFrequency()))
                .adHocReportFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getAdHocReportFee()))
                .adHocReportAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getAdHocReportAmountDue()))

                .thirdPartyValueFrequency(String.valueOf(billingRetail.getThirdPartyValueFrequency()))
                .thirdPartyFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getThirdPartyFee()))
                .thirdPartyAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getThirdPartyAmountDue()))

                .vatFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getVatFee()))
                .vatAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getVatAmountDue()))

                .transactionHandlingValueFrequency(String.valueOf(billingRetail.getTransactionHandlingValueFrequency()))
                .transactionHandlingFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransactionHandlingFee()))
                .transactionHandlingAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransactionHandlingAmountDue()))

                .transactionHandlingInternalValueFrequency(String.valueOf(billingRetail.getTransactionHandlingInternalValueFrequency()))
                .transactionHandlingInternalFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransactionHandlingInternalFee()))
                .transactionHandlingInternalAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransactionHandlingInternalAmountDue()))

                .transferValueFrequency(String.valueOf(billingRetail.getTransferValueFrequency()))
                .transferFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransferFee()))
                .transferAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransferAmountDue()))

                .build();
    }

    private List<BillingRetailDTO> mapToDTOList(List<BillingRetail> billingRetailList) {
        return billingRetailList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }
}
