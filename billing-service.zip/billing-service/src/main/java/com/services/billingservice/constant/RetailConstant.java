package com.services.billingservice.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class RetailConstant {

    public static final String BILLING_NUMBER = "billingNumber";
    public static final String BILLING_PERIOD = "billingPeriod";
    public static final String BILLING_STATEMENT_DATE = "billingStatementDate";
    public static final String BILLING_PAYMENT_DUE_DATE = "billingPaymentDueDate";
    public static final String BILLING_CATEGORY = "billingCategory";
    public static final String BILLING_TYPE = "billingType";
    public static final String BILLING_TEMPLATE = "billingTemplate";

    public static final String INVESTMENT_MANAGEMENT_NAME = "investmentManagementName";
    public static final String INVESTMENT_MANAGEMENT_ADDRESS_1 = "investmentManagementAddress1";
    public static final String INVESTMENT_MANAGEMENT_ADDRESS_2 = "investmentManagementAddress2";
    public static final String INVESTMENT_MANAGEMENT_ADDRESS_3 = "investmentManagementAddress3";
    public static final String INVESTMENT_MANAGEMENT_ADDRESS_4 = "investmentManagementAddress4";

    public static final String SAFEKEEPING_FR = "safekeepingFR";
    public static final String SAFEKEEPING_SR = "safekeepingSR";
    public static final String SAFEKEEPING_ST = "safekeepingST";
    public static final String SAFEKEEPING_ORI = "safekeepingORI";
    public static final String SAFEKEEPING_SBR = "safekeepingSBR";
    public static final String SAFEKEEPING_PBS = "safekeepingPBS";
    public static final String SAFEKEEPING_CORPORATE_BOND = "safekeepingCorporateBond";

    public static final String TOTAL_AMOUNT_DUE = "totalAmountDue";

    public static final String SAFEKEEPING_VALUE_FREQUENCY = "safekeepingValueFrequency";
    public static final String SAFEKEEPING_FEE = "safekeepingFee";
    public static final String SAFEKEEPING_AMOUNT_DUE = "safekeepingAmountDue";

    public static final String TRANSACTION_SETTLEMENT_VALUE_FREQUENCY = "transactionSettlementValueFrequency";
    public static final String TRANSACTION_SETTLEMENT_FEE = "transactionSettlementFee";
    public static final String TRANSACTION_SETTLEMENT_AMOUNT_DUE = "transactionSettlementAmountDue";

    public static final String AD_HOC_REPORT_VALUE_FREQUENCY = "adHocReportValueFrequency";
    public static final String AD_HOC_REPORT_FEE = "adHocReportFee";
    public static final String AD_HOC_REPORT_AMOUNT_DUE = "adHocReportAmountDue";

    public static final String THIRD_PARTY_VALUE_FREQUENCY = "thirdPartyValueFrequency";
    public static final String THIRD_PARTY_FEE = "thirdPartyFee";
    public static final String THIRD_PARTY_AMOUNT_DUE = "thirdPartyAmountDue";

    public static final String VAT_FEE = "vatFee";
    public static final String VAT_AMOUNT_DUE = "vatAmountDue";

    public static final String SUB_TOTAL = "subTotalAmountDue";

    public static final String TRANSACTION_HANDLING_VALUE_FREQUENCY = "transactionHandlingValueFrequency";
    public static final String TRANSACTION_HANDLING_FEE = "transactionHandlingFee";
    public static final String TRANSACTION_HANDLING_AMOUNT_DUE = "transactionHandlingAmountDue";

    public static final String TRANSACTION_HANDLING_INTERNAL_VALUE_FREQUENCY = "transactionHandlingInternalValueFrequency";
    public static final String TRANSACTION_HANDLING_INTERNAL_FEE = "transactionHandlingInternalFee";
    public static final String TRANSACTION_HANDLING_INTERNAL_AMOUNT_DUE = "transactionHandlingInternalAmountDue";

    public static final String TRANSFER_VALUE_FREQUENCY = "transferValueFrequency";
    public static final String TRANSFER_FEE = "transferFee";
    public static final String TRANSFER_AMOUNT_DUE = "transferAmountDue";
}
