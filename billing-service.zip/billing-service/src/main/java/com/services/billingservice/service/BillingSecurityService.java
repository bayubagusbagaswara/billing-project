package com.services.billingservice.service;


import com.services.billingservice.dto.BillingSecurityDTO;
import com.services.billingservice.dto.request.BillingSecurityRequest;

import java.util.List;

public interface BillingSecurityService {

    //single maintenance
    BillingSecurityDTO create(BillingSecurityRequest request);
    BillingSecurityDTO getByCode(String code);
    List<BillingSecurityDTO>getAll();
    BillingSecurityDTO updateByCode(String code, BillingSecurityRequest request);

    //upload
    List<BillingSecurityDTO> upload(List<BillingSecurityRequest> request);
    List<BillingSecurityDTO> updateUploadByCode(List<BillingSecurityRequest> request);

}
