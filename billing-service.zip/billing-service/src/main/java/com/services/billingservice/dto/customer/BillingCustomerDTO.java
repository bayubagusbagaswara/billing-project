package com.services.billingservice.dto.customer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillingCustomerDTO {

    private String id;

    private String customerCode;
    private String subCustomerCode;
    private String customerName;

    private BigDecimal customerMinimumFee;
    private BigDecimal customerSafekeepingFee;

    private String billingCategory;
    private String billingType;
    private String billingTemplate;

    private String miCode;
    private String miName;

    private String debitTransfer;

    private String accountName;
    private String account;
    private String costCenter;
    private String accountBank;
    private String swiftCode;

    private String glAccountHasil;

    private String npwpNumber;
    private String npwpName;
    private String npwpAddress;

    private String safekeepingKsei;
    private String kseiSafeCode;
    private String currency;
    private String sellingAgent;
    private String informationFee;

}
