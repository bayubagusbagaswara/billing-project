package com.services.billingservice.exception;

public class ExcelProcessingException extends RuntimeException {

    public ExcelProcessingException(String message, Throwable cause) {
        super(message, cause);
    }
}
