package com.services.billingservice.service;

import com.services.billingservice.dto.rgmonthly.CreateRGMonthlyRequest;
import com.services.billingservice.model.SfValRgMonthly;

import java.util.List;

public interface SfValRgMonthlyService {

    String readFileAndInsertToDB(String filePath);

    List<SfValRgMonthly> getAll();

    List<SfValRgMonthly> getAllByAid(String aid);

    List<SfValRgMonthly> findByAidAndMonthAndYearOrderByAidAscSecurityNameAscDateAsc(String aid, String month, Integer year);

    List<SfValRgMonthly> getAllByAidAndSecurityName(String aid, String securityName);

    List<SfValRgMonthly> getAllByAidAndMonthAndYear(String aid, String monthName, int year);

    List<SfValRgMonthly> createList(List<CreateRGMonthlyRequest> requestList);

    String deleteAll();
}
