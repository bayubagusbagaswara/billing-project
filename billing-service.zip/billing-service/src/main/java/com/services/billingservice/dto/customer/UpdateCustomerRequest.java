package com.services.billingservice.dto.customer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateCustomerRequest {

    private String dataChangeId;
    private String inputId;
    private String inputIPAddress;

    private Long id;

    private String customerCode;
    private String customerName;

    private BigDecimal customerSafekeepingFee;
    private BigDecimal customerMinimumFee;

    private String billingCategory;
    private String billingType;
    private String billingTemplate;

    private String investmentManagementCode;

    private String currency;

    // data enum
    private String sellingAgentCode; // BDI, INA, CTBC
}
