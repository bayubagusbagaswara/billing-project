package com.services.billingservice.service;

import com.services.billingservice.dto.core.CoreCalculateRequest;

public interface Core5And6CalculateService {

    String calculate(CoreCalculateRequest request);
}
