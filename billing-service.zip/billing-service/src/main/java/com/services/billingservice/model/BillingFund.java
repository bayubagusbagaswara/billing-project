package com.services.billingservice.model;

import com.services.billingservice.model.base.BaseBilling;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "billing_fund")
@Data
@SuperBuilder
@NoArgsConstructor
public class BillingFund extends BaseBilling {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_fee")
    private BigDecimal customerFee;

    @Column(name = "accrual_custodial_fee")
    private BigDecimal accrualCustodialFee;

    @Column(name = "bis4_transaction_value_frequency")
    private Integer bis4TransactionValueFrequency;

    @Column(name = "bis4_transaction_fee")
    private BigDecimal bis4TransactionFee;

    @Column(name = "bis4_transaction_amount_due")
    private BigDecimal bis4TransactionAmountDue;

    @Column(name = "sub_total")
    private BigDecimal subTotal;

    @Column(name = "vat_fee")
    private BigDecimal vatFee;

    @Column(name = "vat_amount_due")
    private BigDecimal vatAmountDue;

    @Column(name = "ksei_transaction_value_frequency")
    private Integer kseiTransactionValueFrequency;

    @Column(name = "ksei_transaction_fee")
    private BigDecimal kseiTransactionFee;

    @Column(name = "ksei_transaction_amount_due")
    private BigDecimal kseiTransactionAmountDue;

    @Column(name = "total_amount_due")
    private BigDecimal totalAmountDue;

}
