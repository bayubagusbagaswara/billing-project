package com.services.billingservice.dto.customer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateCustomerRequest {

    private String inputId;

    private String inputIPAddress;

    @NotBlank(message = "Customer Code cannot be empty")
    private String customerCode;

    @NotBlank(message = "Customer Name must not be blank")
    private String customerName;

    @NotNull(message = "Customer Safekeeping Fee cannot be empty")
    private BigDecimal customerSafekeepingFee;

    @NotNull(message = "Customer Minimum Fee cannot be empty")
    private BigDecimal customerMinimumFee;

    @NotBlank(message = "Billing Category cannot be empty")
    private String billingCategory;

    @NotBlank(message = "Billing Type must cannot be empty")
    private String billingType;

    @NotBlank(message = "Billing Template cannot be empty")
    private String billingTemplate;

    @NotBlank(message = "MI Code cannot be empty")
    private String miCode;

    @NotBlank(message = "Currency cannot be empty")
    private String currency;

    @NotBlank(message = "Selling Agent Code cannot be empty")
    private String sellingAgentCode;

    private String debitTransfer;

    private String accountName;

    private String account;

    private String costCenter;

    private String glAccountHasil;

    private String npwpNumber;

    private String npwpName;

    private String npwpAddress;

    private String kseiSafeCode;
}
