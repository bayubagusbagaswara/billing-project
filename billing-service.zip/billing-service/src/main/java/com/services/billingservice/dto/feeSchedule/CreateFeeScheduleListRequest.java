package com.services.billingservice.dto.feeSchedule;

import com.services.billingservice.dto.BillingFeeScheduleDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateFeeScheduleListRequest {

    private String approvalStatus;

    private String inputId;

    private String inputIPAddress;

    private String approveId;

    private String approveIPAddress;

    private List<BillingFeeScheduleDTO> billingFeeScheduleDTOList;
}
