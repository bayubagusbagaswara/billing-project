package com.services.billingservice.controller;

import com.services.billingservice.dto.BillingFeeScheduleDTO;
import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.exchangerate.CreateExchangeRateRequest;
import com.services.billingservice.dto.exchangerate.ExchangeRateDTO;
import com.services.billingservice.dto.request.BillingFeeScheduleRequest;
import com.services.billingservice.service.BillingFeeScheduleService;
import com.services.billingservice.service.ExchangeRateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/exchangerate")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class ExchangeRateController {

    private final ExchangeRateService exchangeRateService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<String>> create(@RequestBody CreateExchangeRateRequest request) {

        System.out.println("request" + request);
        ExchangeRateDTO exchangeRateDTO = exchangeRateService.create(request);

        ResponseDTO<String> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload("Successfully created Exchange Rate with id : " + exchangeRateDTO.getId());

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<ExchangeRateDTO>>> getAll() {
        List<ExchangeRateDTO> exchangeRateDTOS = exchangeRateService.getAll();

        ResponseDTO<List<ExchangeRateDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(exchangeRateDTOS);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<ExchangeRateDTO>> updateById(@RequestParam("id") String id,
                                                                         @RequestBody CreateExchangeRateRequest request) {
        ExchangeRateDTO exchangeRateDTO = exchangeRateService.updateById(id, request);
        ResponseDTO<ExchangeRateDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(exchangeRateDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/getById")
    public ResponseEntity<ResponseDTO<ExchangeRateDTO>> getById(@RequestParam(name = "id") String id) {
        ExchangeRateDTO exchangeRateDTO = exchangeRateService.getById(id);

        ResponseDTO<ExchangeRateDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(exchangeRateDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping(path = "/currency")
    public ResponseEntity<ResponseDTO<String>> deleteByCurrency(@RequestParam("currency") String currency) {
        String status = exchangeRateService.deleteByCurrency(currency);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

}
