package com.services.billingservice.service;

import com.services.billingservice.dto.BillingEmailProcessingDTO;
import com.services.billingservice.dto.BillingReportGeneratorDTO;

import java.util.List;

public interface BillingEmailProcessingService {

    List<BillingEmailProcessingDTO>generateFileFund(String period);

    List<BillingEmailProcessingDTO>generateFileCore(String period);

    List<BillingEmailProcessingDTO>generateFileRetail(String period);

}
