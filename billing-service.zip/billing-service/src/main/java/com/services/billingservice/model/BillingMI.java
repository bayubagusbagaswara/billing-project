package com.services.billingservice.model;

import com.services.billingservice.model.base.Approvable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "billing_mi")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingMI extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "mi_code")
    private String code;

    @Column(name = "mi_name")
    private String name;

    @Column(name = "mi_email")
    private String email;

    @Column(name = "mi_alamat1")
    private String alamat1;

    @Column(name = "mi_alamat2")
    private String alamat2;

    @Column(name = "mi_alamat3")
    private String alamat3;

    @Column(name = "mi_alamat4")
   private String alamat4;
}
