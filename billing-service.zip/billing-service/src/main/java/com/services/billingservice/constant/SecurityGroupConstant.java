package com.services.billingservice.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class SecurityGroupConstant {

    public static final String FR = "FR";
    public static final String SR = "SR";
    public static final String ST = "ST";
    public static final String ORI = "ORI";
    public static final String SBR = "SBR";
    public static final String PBS = "PBS";
    public static final String CORPORATE_BOND = "CORPORATE";
}
