package com.services.billingservice.service;

import com.services.billingservice.dto.retail.RetailCalculateRequest;

public interface Retail4CalculateService {

    String calculate(RetailCalculateRequest retailCalculateRequest);

}
