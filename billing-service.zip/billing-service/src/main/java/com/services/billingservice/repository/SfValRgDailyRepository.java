package com.services.billingservice.repository;

import com.services.billingservice.model.SfValRgDaily;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface SfValRgDailyRepository extends JpaRepository<SfValRgDaily, Long> {

    @Query(value = "SELECT * FROM bill_sfval_rg_daily WHERE aid = :aid", nativeQuery = true)
    List<SfValRgDaily> findAllByAid(@Param("aid") String aid);

    @Query(value = "SELECT * FROM bill_sfval_rg_daily WHERE aid = :aid AND security_name = :securityName", nativeQuery = true)
    List<SfValRgDaily> findAllByAidAndSecurityName(@Param("aid") String aid, @Param("securityName") String securityName);

    @Query(value = "SELECT * FROM bill_sfval_rg_daily WHERE aid = :aid AND date = :latestDate", nativeQuery = true)
    List<SfValRgDaily> findAllByAidAndDate(@Param("aid") String aid, @Param("latestDate") LocalDate latestDate);

    @Query(value = "SELECT * FROM bill_sfval_rg_daily " +
            "WHERE aid = :aid " +
            "AND month = :month " +
            "AND year = :year", nativeQuery = true)
    List<SfValRgDaily> findAllByAidAndMonthAndYear(@Param("aid") String aid, @Param("month") String monthName, @Param("year") Integer year);

    List<SfValRgDaily> findByMonthAndYear(String month, Integer year);

    @Query(value = "SELECT a.id, a.batch, a.date, a.year, a.month, a.aid, a.security_name, a.face_value, a.market_price, a.market_value, SUM(b.estimation_sk_fee) as estimation_sk_fee " +
            "FROM bill_sfval_rg_daily a " +
            "Join bill_sfval_rg_daily b " +
            "    ON a.month = b.month  " +
            "    AND a.year = b.year " +
            "    AND a.aid = b.aid " +
            "    AND a.security_name = b.security_name " +
            "WHERE a.[month] = :month " +
            "    AND a.[year] = :year " +
            "    AND a.date = :latestDate " +
            "GROUP BY a.id, a.batch, a.date, a.year, a.month, a.aid, a.security_name, a.face_value, a.market_price, a.market_value ", nativeQuery = true)
    List<SfValRgDaily> findRecapByMonthAndYear(@Param("month") String month, @Param("year") Integer year, @Param("latestDate") LocalDate latestDate);

    @Query(value = "SELECT a.id, a.batch, a.date, a.year, a.month, a.aid, a.security_name, a.face_value, a.market_price, a.market_value, SUM(b.estimation_sk_fee) as estimation_sk_fee " +
            "FROM bill_sfval_rg_daily a " +
            "Join bill_sfval_rg_daily b " +
            "    ON a.month = b.month  " +
            "    AND a.year = b.year " +
            "    AND a.aid = b.aid " +
            "    AND a.security_name = b.security_name " +
            "WHERE a.[month] = :month " +
            "    AND a.[year] = :year " +
            "    AND a.date = :latestDate " +
            "    AND a.aid = :aid " +
            "GROUP BY a.id, a.batch, a.date, a.year, a.month, a.aid, a.security_name, a.face_value, a.market_price, a.market_value ", nativeQuery = true)
    List<SfValRgDaily> findRecapByAidAndMonthAndYear(@Param("aid") String aid, @Param("month") String month, @Param("year") Integer year, @Param("latestDate") LocalDate latestDate);

    List<SfValRgDaily> findByAidAndMonthAndYearOrderByAidAscSecurityNameAscDateAsc(String aid, String month, Integer year);

    @Query(value = "EXEC sp_detail_account_balance :date, :aid ", nativeQuery = true)
    List<SfValRgDaily> getAllRetailByAidAndPeriod(@Param("aid") String aid, @Param("date") LocalDate date);

    List<SfValRgDaily> findByAidAndSecurityNameAndMonthAndYear(String aid, String securityName, String month, Integer year);
}
