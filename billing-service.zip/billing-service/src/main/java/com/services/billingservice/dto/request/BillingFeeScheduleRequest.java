package com.services.billingservice.dto.request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillingFeeScheduleRequest {


    private String inputId;

    private Long id;

    private String inputIpAddress;

    private Double feeMin;

    private Double feeMax;

    private Double feeAmount;
}
