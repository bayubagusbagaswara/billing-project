package com.services.billingservice.controller;


import com.services.billingservice.dto.BillingEmailProcessingDTO;
import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.service.BillingEmailProcessingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/report-email")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor

public class BillingEmailProcessingController {
    private final BillingEmailProcessingService billingEmailProcessingService;


    @GetMapping(path = "/generateTosFund")
    public ResponseEntity<ResponseDTO<List<BillingEmailProcessingDTO>>>getTosByCategory(@RequestParam(value = "period") String category){
        List<BillingEmailProcessingDTO>billingEmailProcessingDTOList = billingEmailProcessingService.generateFileFund(category);

        ResponseDTO<List<BillingEmailProcessingDTO>>response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingEmailProcessingDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/generateTosCore")
    public ResponseEntity<ResponseDTO<List<BillingEmailProcessingDTO>>>getTosByCategoryCore(@RequestParam(value = "period") String period){
        List<BillingEmailProcessingDTO>billingEmailProcessingDTOList = billingEmailProcessingService.generateFileCore(period);

        ResponseDTO<List<BillingEmailProcessingDTO>>response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingEmailProcessingDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/generateTosRetail")
    public ResponseEntity<ResponseDTO<List<BillingEmailProcessingDTO>>>getTosByCategoryRetail(@RequestParam(value = "period") String period){
        List<BillingEmailProcessingDTO>billingEmailProcessingDTOList = billingEmailProcessingService.generateFileRetail(period);

        ResponseDTO<List<BillingEmailProcessingDTO>>response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingEmailProcessingDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }


}