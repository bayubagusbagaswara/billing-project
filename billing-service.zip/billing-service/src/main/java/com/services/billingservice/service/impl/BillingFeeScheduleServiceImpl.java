package com.services.billingservice.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.BillingFeeScheduleDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeSchedule.*;
import com.services.billingservice.dto.request.BillingFeeScheduleRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.ChangeAction;
import com.services.billingservice.exception.DataChangeException;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.exception.DataProcessingException;
import com.services.billingservice.model.BillingDataChange;
import com.services.billingservice.model.BillingFeeSchedule;
import com.services.billingservice.repository.BillingDataChangeRepository;
import com.services.billingservice.repository.BillingFeeScheduleRepository;
import com.services.billingservice.service.BillingFeeScheduleService;
import com.services.billingservice.utils.StringUtil;
import com.services.billingservice.utils.TableNameResolver;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingFeeScheduleServiceImpl implements BillingFeeScheduleService {

    private final BillingFeeScheduleRepository billingFeeScheduleRepository;
    private final BillingDataChangeRepository dataChangeRepository;
    private final Validator validator;
    private final ObjectMapper objectMapper;

    @Override
    public CreateFeeScheduleListResponse create(BillingFeeScheduleRequest request, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create Fee Schedule with request: {}", request);
        String inputId = request.getInputId();
        String inputIPAddress = request.getInputIpAddress();
        int totalDataSuccess = 0;
        int totalDataFailed= 0;
        List<ErrorMessageFeeScheduleDTO> errorMessageFeeScheduleDTOList = new ArrayList<>();

        try {
            List<String> errorMessages = new ArrayList<>();
            BillingFeeScheduleDTO billingFeeScheduleDTO = BillingFeeScheduleDTO.builder()
                    .feeMin(request.getFeeMin())
                    .feeMax(request.getFeeMax())
                    .amount(request.getFeeAmount())
                    .build();

            Errors errors = validateFeeScheduleDTO(billingFeeScheduleDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> errorMessages.add(error.getDefaultMessage()));
            }

            if (errorMessages.isEmpty()) {
                BillingDataChange dataChange = getBillingDataChangeCreate(dataChangeDTO, billingFeeScheduleDTO, inputId, inputIPAddress);
                dataChangeRepository.save(dataChange);
                totalDataSuccess++;
            } else {
                totalDataFailed = getTotalDataFailed(totalDataFailed, errorMessageFeeScheduleDTOList, billingFeeScheduleDTO.getId(), errorMessages);
            }

            return new CreateFeeScheduleListResponse(totalDataSuccess, totalDataFailed, errorMessageFeeScheduleDTOList);
        } catch (Exception e) {
            log.error("An error occurred while saving data changes to create Fee Schedule data: {}", e.getMessage());
            throw new DataChangeException("An error occurred while saving data changes to create Fee Schedule data", e);
        }
    }

    @Override
    public CreateFeeScheduleListResponse createListApprove(CreateFeeScheduleListRequest billingFeeScheduleRequest) {
        log.info("Create billing fee schedule list approve with request: {}", billingFeeScheduleRequest);
        String approveId = billingFeeScheduleRequest.getApproveId();
        String approveIPAddress = billingFeeScheduleRequest.getApproveIPAddress();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageFeeScheduleDTO> errorMessageList = new ArrayList<>();

        try {
            List<Long> dataChangeIdList = billingFeeScheduleRequest.getBillingFeeScheduleDTOList().stream().map(BillingFeeScheduleDTO::getDataChangeId)
                    .collect(Collectors.toList());
            Integer totalDataChangeIdList = dataChangeIdList.size();
            Boolean existsByIdList = dataChangeRepository.existsByIdList(dataChangeIdList, totalDataChangeIdList);
            if (!existsByIdList) {
                throw new IllegalArgumentException("ID Data Change not found");
            }

            for (BillingFeeScheduleDTO billingFeeScheduleDTO : billingFeeScheduleRequest.getBillingFeeScheduleDTOList()) {
                List<String> errorMessages = new ArrayList<>();
                Errors errors = validateFeeScheduleDTO(billingFeeScheduleDTO);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> errorMessages.add(error.getDefaultMessage()));
                }

                BillingDataChange dataChange = getBillingDataChangeById(billingFeeScheduleDTO.getDataChangeId());

                if (errorMessages.isEmpty()) {
                    BillingFeeSchedule billingFeeSchedule = BillingFeeSchedule.builder()
                            .feeMin(billingFeeScheduleDTO.getFeeMin())
                            .feeMax(billingFeeScheduleDTO.getFeeMax())
                            .feeAmount(billingFeeScheduleDTO.getAmount())
                            .build();
                    billingFeeScheduleRepository.save(billingFeeSchedule);

                    String jsonDataAfter = objectMapper.writeValueAsString(billingFeeSchedule);
                    dataChange.setApprovalStatus(ApprovalStatus.Approved);
                    dataChange.setApproverId(approveId);
                    dataChange.setApproverIPAddress(approveIPAddress);
                    dataChange.setApproveDate(new Date());
                    dataChange.setEntityId(billingFeeSchedule.getId().toString());
                    dataChange.setJsonDataAfter(jsonDataAfter);
                    dataChange.setDescription("Successfully approve data change and save data entity");
                    dataChangeRepository.save(dataChange);
                    totalDataSuccess++;
                } else {
                    dataChange.setApprovalStatus(ApprovalStatus.Rejected);
                    dataChange.setApproverId(approveId);
                    dataChange.setApproverIPAddress(approveIPAddress);
                    dataChange.setApproveDate(new Date());
                    dataChange.setDescription(StringUtil.joinStrings(errorMessages));
                    dataChangeRepository.save(dataChange);
                    totalDataFailed++;
                }
            }
            return new CreateFeeScheduleListResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        } catch (Exception e) {
            log.error("An error occurred while saving entity data investment managements: {}", e.getMessage());
            throw new DataProcessingException("An error occurred while saving entity data investment managements", e);
        }
    }

    @Override
    public UpdateFeeScheduleListResponse updateById(BillingFeeScheduleRequest request, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update Fee Schedule by id with request: {}", request);
        String inputId = request.getInputId();
        String inputIPAddress = request.getInputIpAddress();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageFeeScheduleDTO> errorMessageFeeScheduleDTOList = new ArrayList<>();

        try {
            List<String> errorMessages = new ArrayList<>();
            BillingFeeScheduleDTO billingFeeScheduleDTO = BillingFeeScheduleDTO.builder()
                    .feeMin(request.getFeeMin())
                    .feeMax(request.getFeeMax())
                    .build();

            Errors errors = validateFeeScheduleDTO(billingFeeScheduleDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> errorMessages.add(error.getDefaultMessage()));
            }

            BillingFeeSchedule billingFeeSchedule = billingFeeScheduleRepository.findById(billingFeeScheduleDTO.getId()).orElse(null);
            if (billingFeeSchedule == null) {
                errorMessages.add("Code '" + billingFeeScheduleDTO.getId() + "' not found");
            }

            if (errorMessages.isEmpty() && billingFeeSchedule != null) {
                BillingDataChange billingDataChange = getBillingDataChangeUpdate(dataChangeDTO, billingFeeSchedule, billingFeeScheduleDTO, inputId, inputIPAddress);
                dataChangeRepository.save(billingDataChange);
                totalDataSuccess++;
            } else {
                totalDataFailed = getTotalDataFailed(totalDataFailed, errorMessageFeeScheduleDTOList, billingFeeSchedule.getId().toString(), errorMessages);
            }
            return new UpdateFeeScheduleListResponse(totalDataSuccess, totalDataFailed, errorMessageFeeScheduleDTOList);
        } catch (Exception e) {
            log.error("An error occurred while saving data changes to update Fee Schedule single data: {}", e.getMessage());
            throw new DataChangeException("An error occurred while saving data changes to create investment management data list", e);
        }
    }

    @Override
    public UpdateFeeScheduleListResponse updateListApprove(UpdateFeeScheduleListRequest feeScheduleListRequest) {
        log.info("Request data update approve: {}", feeScheduleListRequest);
        String approveId = feeScheduleListRequest.getApproveId();
        String approveIPAddress = feeScheduleListRequest.getApproveIPAddress();
        Date approveDate = new Date();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageFeeScheduleDTO> errorMessageList = new ArrayList<>();

        try {
            List<Long> dataChangeIdList = feeScheduleListRequest.getBillingFeeScheduleDTOList().stream().map(BillingFeeScheduleDTO::getDataChangeId)
                    .collect(Collectors.toList());
            Integer totalDataChangeIdList = dataChangeIdList.size();
            Boolean existsByIdList = dataChangeRepository.existsByIdList(dataChangeIdList, totalDataChangeIdList);
            if (!existsByIdList) {
                throw new IllegalArgumentException("ID Data Change not found");
            }

            for (BillingFeeScheduleDTO billingFeeScheduleDTO : feeScheduleListRequest.getBillingFeeScheduleDTOList()) {
                List<String> errorMessages = new ArrayList<>();
                Errors errors = validateFeeScheduleDTO(billingFeeScheduleDTO);

                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> errorMessages.add(error.getDefaultMessage()));
                }

                BillingDataChange dataChangeEntity = getBillingDataChangeById(billingFeeScheduleDTO.getDataChangeId());
                BillingFeeSchedule feeSchedule = billingFeeScheduleRepository.findById(billingFeeScheduleDTO.getId()).orElse(null);
                if (feeSchedule == null) {
                    errorMessages.add("Code '" + billingFeeScheduleDTO.getId() + "' is not found");
                }

                if (errorMessages.isEmpty() && feeSchedule != null) {
                    updateBillingFeeSchedule(feeSchedule, billingFeeScheduleDTO);
                    BillingFeeSchedule feeScheduleSaved = billingFeeScheduleRepository.save(feeSchedule);

                    String jsonDataAfter = objectMapper.writeValueAsString(feeScheduleSaved);
                    dataChangeEntity.setApprovalStatus(ApprovalStatus.Approved);
                    dataChangeEntity.setApproverId(approveId);
                    dataChangeEntity.setApproverIPAddress(approveIPAddress);
                    dataChangeEntity.setApproveDate(approveDate);
                    dataChangeEntity.setJsonDataAfter(jsonDataAfter);
                    dataChangeEntity.setDescription("Successfully approve data change and update data entity");

                    dataChangeRepository.save(dataChangeEntity);
                    totalDataSuccess++;
                } else {
                    String jsonDataAfter = objectMapper.writeValueAsString(billingFeeScheduleDTO);
                    dataChangeEntity.setApprovalStatus(ApprovalStatus.Rejected);
                    dataChangeEntity.setApproverId(approveId);
                    dataChangeEntity.setApproverIPAddress(approveIPAddress);
                    dataChangeEntity.setApproveDate(approveDate);
                    dataChangeEntity.setJsonDataAfter(jsonDataAfter);
                    dataChangeEntity.setDescription(StringUtil.joinStrings(errorMessages));

                    dataChangeRepository.save(dataChangeEntity);
                    totalDataFailed++;
                }
            }
            return new UpdateFeeScheduleListResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        } catch (Exception e) {
            log.error("An error occurred while updating entity data investment managements: {}", e.getMessage());
            throw new DataProcessingException("An error occurred while updating entity data Fee Schedule", e);
        }
    }

    @Override
    public DeleteFeeScheduleListResponse deleteById(DeleteFeeScheduleListRequest request, BillingDataChangeDTO dataChangeDTO) {
        log.info("Delete Fee Schedule by id with request: {}", request);
        String inputId = request.getInputId();
        String inputIPAddress = request.getInputIPAddress();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageFeeScheduleDTO> errorMessageFeeScheduleDTOList = new ArrayList<>();

        try {
            List<String> errorMessages = new ArrayList<>();
             BillingFeeSchedule billingFeeSchedule = billingFeeScheduleRepository.findById(request.getId()).orElse(null);

            if (billingFeeSchedule == null) {
                errorMessages.add("ID '" + request.getId() + "' not found");
            }

            if (errorMessages.isEmpty() && billingFeeSchedule != null) {
                String jsonDataBefore = objectMapper.writeValueAsString(billingFeeSchedule);
                BillingDataChange billingDataChange = BillingDataChange.builder()
                        .approvalStatus(ApprovalStatus.Pending)
                        .inputerId(inputId)
                        .inputDate(new Date())
                        .inputerIPAddress(inputIPAddress)
                        .approverId("")
                        .approveDate(null)
                        .approverIPAddress("")
                        .action(ChangeAction.Delete)
                        .entityId(billingFeeSchedule.getId().toString())
                        .entityClassName(BillingFeeSchedule.class.getName())
                        .tableName(TableNameResolver.getTableName(BillingFeeSchedule.class))
                        .jsonDataBefore(jsonDataBefore)
                        .jsonDataAfter("")
                        .description("")
                        .methodHttp(dataChangeDTO.getMethodHttp())
                        .endpoint(dataChangeDTO.getEndpoint())
                        .isRequestBody(dataChangeDTO.isRequestBody())
                        .isRequestParam(dataChangeDTO.isRequestParam())
                        .isPathVariable(dataChangeDTO.isPathVariable())
                        .menu(dataChangeDTO.getMenu())
                        .build();
                dataChangeRepository.save(billingDataChange);
                totalDataSuccess++;
            } else {
                totalDataFailed = getTotalDataFailed(totalDataFailed, errorMessageFeeScheduleDTOList, request.getId().toString(), errorMessages);
            }
            return new DeleteFeeScheduleListResponse(totalDataSuccess, totalDataFailed, errorMessageFeeScheduleDTOList);
        } catch (Exception e) {
            log.error("An error occurred while saving data changes to delete investment management single data: {}", e.getMessage());
            throw new DataChangeException("An error occurred while saving data changes to delete investment management single data", e);
        }
    }


    @Override
    public BillingFeeScheduleDTO getByCode(String id) {
        BillingFeeSchedule billingFeeSchedule = billingFeeScheduleRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Data Not Found"));
        return mapToDTO(billingFeeSchedule);
    }

    @Override
    public List<BillingFeeScheduleDTO> getAll() {
        List<BillingFeeSchedule> billingFeeSchedules = billingFeeScheduleRepository.findAll();

        return mapToDTOList(billingFeeSchedules);
    }

    @Override
    public BillingFeeScheduleDTO updateById(String id, BillingFeeScheduleRequest request) {
        BillingFeeSchedule billingFeeSchedule = billingFeeScheduleRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Data Not Found"));

        if (request.getFeeAmount() != null) {
            billingFeeSchedule.setFeeAmount(request.getFeeAmount());
        }

        if (request.getFeeMax() != null) {
            billingFeeSchedule.setFeeMax(request.getFeeMax());
        }

        if (request.getFeeMin() != null) {
            billingFeeSchedule.setFeeMin(request.getFeeMin());
        }


        BillingFeeSchedule dataSaved = billingFeeScheduleRepository.save(billingFeeSchedule);
        return mapToDTO(dataSaved);
    }

    @Override
    public String delete(String id) {
        BillingFeeSchedule billingFeeSchedule = billingFeeScheduleRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("data not found"));

        billingFeeScheduleRepository.deleteById(billingFeeSchedule.getId());

        return "Successfully delete nasabah transfer asset with id : " + billingFeeSchedule.getId();
    }


    private BillingFeeScheduleDTO mapToDTO(BillingFeeSchedule billingFeeSchedule) {
        return BillingFeeScheduleDTO.builder()
                .id(String.valueOf(billingFeeSchedule.getId()))
                .feeMin(billingFeeSchedule.getFeeMin())
                .feeMax(billingFeeSchedule.getFeeMax())
                .amount(billingFeeSchedule.getFeeAmount())
                .build();

    }

    private List<BillingFeeScheduleDTO> mapToDTOList(List<BillingFeeSchedule> billingFeeScheduleList) {
        return billingFeeScheduleList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    private Errors validateFeeScheduleDTO(BillingFeeScheduleDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "billingFeeScheduleDTO");
        validator.validate(dto, errors);
        return errors;
    }

    private BillingDataChange getBillingDataChangeCreate(BillingDataChangeDTO dataChangeDTO, BillingFeeScheduleDTO billingFeeScheduleDTO, String inputId, String inputIPAddress) throws JsonProcessingException {
        String jsonDataAfter = objectMapper.writeValueAsString(billingFeeScheduleDTO);
        return BillingDataChange.builder()
                .approvalStatus(ApprovalStatus.Pending)
                .inputerId(inputId)
                .inputDate(new Date())
                .inputerIPAddress(inputIPAddress)
                .approverId("")
                .approveDate(null)
                .approverIPAddress("")
                .action(ChangeAction.Add)
                .entityId("")
                .entityClassName(BillingFeeSchedule.class.getName())
                .tableName(TableNameResolver.getTableName(BillingFeeSchedule.class))
                .jsonDataBefore("")
                .jsonDataAfter(jsonDataAfter)
                .description("")
                .methodHttp(dataChangeDTO.getMethodHttp())
                .endpoint(dataChangeDTO.getEndpoint())
                .isRequestBody(dataChangeDTO.isRequestBody())
                .isRequestParam(dataChangeDTO.isRequestParam())
                .isPathVariable(dataChangeDTO.isPathVariable())
                .menu(dataChangeDTO.getMenu())
                .build();
    }

    private int getTotalDataFailed(int totalDataFailed, List<ErrorMessageFeeScheduleDTO> errorMessageFeeScheduleDTOList, String code, List<String> errorMessages) {
        ErrorMessageFeeScheduleDTO errorMessageDTO = new ErrorMessageFeeScheduleDTO();
        errorMessageDTO.setCode(code);
        errorMessageDTO.setErrorMessages(errorMessages);
        errorMessageFeeScheduleDTOList.add(errorMessageDTO);
        totalDataFailed++;
        return totalDataFailed;
    }

    private BillingDataChange getBillingDataChangeById(Long dataChangeId) {
        return dataChangeRepository.findById(dataChangeId).orElse(null);
    }

    private BillingDataChange getBillingDataChangeUpdate(BillingDataChangeDTO dataChangeDTO, BillingFeeSchedule billingFeeSchedule, BillingFeeScheduleDTO billingFeeScheduleDTO, String inputId, String inputIPAddress) throws JsonProcessingException {
        Long id = billingFeeSchedule.getId();
        String jsonDataBefore = objectMapper.writeValueAsString(billingFeeSchedule);
        String jsonDataAfter = objectMapper.writeValueAsString(billingFeeScheduleDTO);
        return BillingDataChange.builder()
                .approvalStatus(ApprovalStatus.Pending)
                .inputerId(inputId)
                .inputDate(new Date())
                .inputerIPAddress(inputIPAddress)
                .approverId("")
                .approveDate(null)
                .approverIPAddress("")
                .action(ChangeAction.Edit)
                .entityId(id.toString())
                .entityClassName(BillingFeeSchedule.class.getName())
                .tableName(TableNameResolver.getTableName(BillingFeeSchedule.class))
                .jsonDataBefore(jsonDataBefore)
                .jsonDataAfter(jsonDataAfter)
                .description("")
                .methodHttp(dataChangeDTO.getMethodHttp())
                .endpoint(dataChangeDTO.getEndpoint())
                .isRequestBody(dataChangeDTO.isRequestBody())
                .isRequestParam(dataChangeDTO.isRequestParam())
                .isPathVariable(dataChangeDTO.isPathVariable())
                .menu(dataChangeDTO.getMenu())
                .build();
    }

    private void updateBillingFeeSchedule(BillingFeeSchedule existingFeeSchedule, BillingFeeScheduleDTO updateDTO) {
        // Update only the fields that are present in the updated DTO
        if (updateDTO.getFeeMin() != 0) {
            existingFeeSchedule.setFeeMin(updateDTO.getFeeMin());
        }
        if (updateDTO.getFeeMax() != 0.0 ) {
            existingFeeSchedule.setFeeMin(updateDTO.getFeeMax());
        }
        if (updateDTO.getAmount() != 0.0) {
            existingFeeSchedule.setFeeAmount(updateDTO.getAmount());
        }
    }

}
