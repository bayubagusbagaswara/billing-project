package com.services.billingservice.repository;

import com.services.billingservice.model.BillingReportGenerator;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillingReportGeneratorRepository extends JpaRepository<BillingReportGenerator, Long> {
    @Query(value = "SELECT * FROM billing_report_generator WHERE id = :id", nativeQuery = true)
    Optional<BillingReportGenerator> findById(@Param("id") String id);

    @Query(value = "SELECT * FROM billing_report_generator", nativeQuery = true)
    List<BillingReportGenerator> findAll();

    @Query(value = "SELECT * FROM billing_report_generator " +
            "WHERE month = :month " +
            "AND year = :year", nativeQuery = true)
    List<BillingReportGenerator> findAllByMonthAndYear(@Param("month") String monthName,
                                                       @Param("year") Integer year);


    @Query(value = "SELECT * FROM billing_report_generator " +
            "WHERE bill_customer_code = :customerCode " +
            "AND bill_category = :category " +
            "AND bill_type = :type " +
            "AND currency = :currency " +
            "AND month = :month " +
            "AND year = :year", nativeQuery = true)
    List<BillingReportGenerator> findAllByCustomerCodeAndCategoryAndTypeAndCurrencyAndMonthAndYear(
            @Param("customerCode") String customerCode,
            @Param("category") String category,
            @Param("type") String type,
            @Param("currency") String currency,
            @Param("month") String month,
            @Param("year") Integer year
    );
}

