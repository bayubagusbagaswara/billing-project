package com.services.billingservice.enums;

import java.time.Month;

public enum IndonesianMonth {

    JANUARI(Month.JANUARY),
    FEBRUARI(Month.FEBRUARY),
    MARET(Month.MARCH),
    APRIL(Month.APRIL),
    MEI(Month.MAY),
    JUNI(Month.JUNE),
    JULI(Month.JULY),
    AGUSTUS(Month.AUGUST),
    SEPTEMBER(Month.SEPTEMBER),
    OKTOBER(Month.OCTOBER),
    NOVEMBER(Month.NOVEMBER),
    DESEMBER(Month.DECEMBER);

    private final Month month;

    IndonesianMonth(Month month) {
            this.month = month;
    }

    public Month getMonth() {
        return month;
    }


}
