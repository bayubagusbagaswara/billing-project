package com.services.billingservice.model;


import com.services.billingservice.model.base.Approvable;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "billing_fee_schedule")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingFeeSchedule extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "fee_schedule_min")
    private Double feeMin;

    @Column(name = "fee_schedule_max")
    private Double feeMax;

    @Column(name = "fee_amount")
    private Double feeAmount;

}