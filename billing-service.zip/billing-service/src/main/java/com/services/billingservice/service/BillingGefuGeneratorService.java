package com.services.billingservice.service;

import com.services.billingservice.dto.core.*;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingGefuProcessHistory;

import java.util.List;

public interface BillingGefuGeneratorService {

    void checkExistGefuFileName(String fileName);

    void deleteExistGefuFile(String fileName);

    String createGefu(String category, String month, int year, String customerCode, String userId);

    void approveAndSendGefu(long gefuProcessHistory, String approverId);

    void rejectGefu(long gefuProcessHistory, String approverId);

    void readGefuResponse(List<String> fileNames);

    String gefuCoreFileGeneratorDirect(BillingGefuProcessHistory gefuHistory, BillingCore billing);

    void gefuCoreGenerator(BillingGefuProcessHistory gefuHistory,String billTemplate);

    void gefuCoreGeneratorDirect(BillingGefuProcessHistory gefuHistory);

    void gefuCoreGeneratorCASA(BillingGefuProcessHistory gefuHistory);

    boolean sendGefu(BillingGefuProcessHistory gefuHistory);

}
